using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using EGroceryStore.Helpers;
using EGroceryStore.Models;
using EGroceryStore.ViewModels;

namespace EGroceryStore.Controllers
{
    public class AdminDashboardController : Controller
    {
        private EGroceryStoreDBEntities db = new EGroceryStoreDBEntities();

        // How many units of stock counts as "Low Stock" - a simple constant,
        // easy to change later if the business wants a different threshold.
        private const int LowStockThreshold = 10;

        // How many rows to show in each "Recent" list on the Dashboard.
        private const int RecentRowCount = 5;

        // GET: AdminDashboard/Index
        public ActionResult Index()
        {
            // Protect this page - only a logged-in Admin can see it.
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                TempData["ErrorMessage"] = "Your session has expired. Please login again.";
                return RedirectToAction("Login", "Account");
            }

            var model = new AdminDashboardViewModel();

            // ===== Summary Card Numbers =====
            // Count() with a condition = SQL: SELECT COUNT(*) FROM ... WHERE ...
            model.TotalCustomers = db.Users.Count(u => u.Role == "Customer");
            model.TotalProducts = db.Products.Count(p => p.IsActive == true);
            model.TotalCategories = db.Categories.Count(c => c.IsActive == true);
            model.TotalOrders = db.Orders.Count();
            model.PendingOrders = db.Orders.Count(o => o.OrderStatus == "Placed" || o.OrderStatus == "Pending");
            model.DeliveredOrders = db.Orders.Count(o => o.OrderStatus == "Delivered");
            model.ActiveCoupons = db.Coupons.Count(c => c.IsActive == true && c.ExpiryDate >= DateTime.Now);

            // Sum() adds up TotalAmount across every order. If there are zero
            // orders, a plain Sum() can throw an error - casting to decimal?
            // and using ?? 0 gives us a safe "0" instead of a crash.
            model.TotalRevenue = db.Orders.Sum(o => (decimal?)o.TotalAmount) ?? 0;

            // ===== Recent Orders (latest 5) =====
            // We can't just show db.Orders directly, because the Dashboard
            // table needs the Customer's name, which lives on the Users
            // table, not the Orders table. So for each recent order, we
            // look up its matching Customer manually - simple and explicit.
            var recentOrderRows = db.Orders
                .OrderByDescending(o => o.OrderDate)
                .Take(RecentRowCount)
                .ToList();

            model.RecentOrders = new List<RecentOrderViewModel>();
            foreach (var order in recentOrderRows)
            {
                var customer = db.Users.FirstOrDefault(u => u.UserId == order.UserId);

                model.RecentOrders.Add(new RecentOrderViewModel
                {
                    OrderId = order.OrderId,
                    OrderNumber = order.OrderNumber,
                    CustomerName = customer != null ? customer.FirstName + " " + customer.LastName : "Unknown",
                    OrderDate = order.OrderDate,
                    OrderStatus = order.OrderStatus,
                    PaymentStatus = order.PaymentStatus,
                    TotalAmount = order.TotalAmount
                });
            }

            // ===== Recent Customers (latest 5 registered) =====
            model.RecentCustomers = db.Users
                .Where(u => u.Role == "Customer")
                .OrderByDescending(u => u.CreatedDate)
                .Take(RecentRowCount)
                .Select(u => new RecentCustomerViewModel
                {
                    UserId = u.UserId,
                    FullName = u.FirstName + " " + u.LastName,
                    Email = u.Email,
                    RegisteredDate = u.CreatedDate,
                    IsActive = u.IsActive
                })
                .ToList();

            // ===== Low Stock Products =====
            var lowStockRows = db.Products
                .Where(p => p.IsActive == true && p.StockQuantity <= LowStockThreshold)
                .OrderBy(p => p.StockQuantity)
                .Take(RecentRowCount)
                .ToList();

            model.LowStockProducts = new List<LowStockProductViewModel>();
            foreach (var product in lowStockRows)
            {
                var category = db.Categories.FirstOrDefault(c => c.CategoryId == product.CategoryId);

                model.LowStockProducts.Add(new LowStockProductViewModel
                {
                    ProductId = product.ProductId,
                    ProductName = product.ProductName,
                    CategoryName = category != null ? category.CategoryName : "Uncategorized",
                    StockQuantity = product.StockQuantity
                });
            }

            // ===== Top Categories by Sales (feeds the simple bar "chart") =====
            // Step 1: total quantity sold, grouped by ProductId.
            var salesByProduct = db.OrderDetails
                .GroupBy(od => od.ProductId)
                .Select(g => new { ProductId = g.Key, TotalSold = g.Sum(x => x.Quantity) })
                .ToList();

            // Step 2: roll each product's sales up into its Category's running total.
            var salesByCategory = new Dictionary<string, int>();
            foreach (var row in salesByProduct)
            {
                var product = db.Products.FirstOrDefault(p => p.ProductId == row.ProductId);
                if (product == null) continue;

                var category = db.Categories.FirstOrDefault(c => c.CategoryId == product.CategoryId);
                string categoryName = category != null ? category.CategoryName : "Uncategorized";

                if (salesByCategory.ContainsKey(categoryName))
                {
                    salesByCategory[categoryName] += row.TotalSold;
                }
                else
                {
                    salesByCategory[categoryName] = row.TotalSold;
                }
            }

            int grandTotalUnitsSold = salesByCategory.Values.Sum();

            model.TopCategoriesBySales = new List<CategorySalesViewModel>();
            foreach (var pair in salesByCategory.OrderByDescending(kv => kv.Value).Take(5))
            {
                decimal percentage = grandTotalUnitsSold > 0
                    ? Math.Round((decimal)pair.Value / grandTotalUnitsSold * 100, 1)
                    : 0;

                model.TopCategoriesBySales.Add(new CategorySalesViewModel
                {
                    CategoryName = pair.Key,
                    PercentageOfTotalSales = percentage
                });
            }

            return View(model);
        }
    }
}
