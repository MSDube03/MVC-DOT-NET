using System;
using System.Web;

namespace EGroceryStore.Helpers
{
    /// <summary>
    /// Every Customer page (Wishlist, Cart, Address, Checkout, Orders, Profile) must
    /// check "is someone logged in?" before doing anything. Instead of repeating the
    /// same 3 lines of Session-checking code inside many different Controllers, we write
    /// it once here and call it everywhere. This is a plain static helper class -
    /// NOT Dependency Injection, NOT a Service Layer - just a reusable method.
    /// </summary>
    public static class SessionHelper
    {
        /// <summary>
        /// Returns true if a customer is currently logged in
        /// (i.e. AccountController's Login action has set Session["UserId"]).
        /// </summary>
        public static bool IsCustomerLoggedIn(HttpSessionStateBase session)
        {
            return session["UserId"] != null;
        }

        /// <summary>
        /// Returns the logged-in customer's UserId.
        /// IMPORTANT: only call this AFTER checking IsCustomerLoggedIn() is true,
        /// otherwise this will throw an error because Session["UserId"] would be empty.
        /// </summary>
        public static int GetCurrentUserId(HttpSessionStateBase session)
        {
            return Convert.ToInt32(session["UserId"]);
        }

        /// <summary>
        /// Returns the logged-in customer's display name (set during Login).
        /// </summary>
        public static string GetCurrentUserName(HttpSessionStateBase session)
        {
            return session["UserName"] as string;
        }

        /// <summary>
        /// Returns true only if someone is logged in AND their Role is
        /// specifically "Admin". A regular Customer who is logged in will
        /// still get "false" here - this is what keeps Admin pages locked
        /// away from Customers, even if a Customer tries to type an Admin
        /// URL directly into the browser.
        /// </summary>
        public static bool IsAdminLoggedIn(HttpSessionStateBase session)
        {
            if (session["UserId"] == null)
            {
                return false;
            }

            string role = session["Role"] as string;
            return role == "Admin";
        }
    }
}
