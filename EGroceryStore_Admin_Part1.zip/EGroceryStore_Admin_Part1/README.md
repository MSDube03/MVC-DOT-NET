# E-Grocery Store — Admin Module, Part 1: Login + Dashboard

Admin Login already exists (built in Stage 1's `AccountController`). This
package adds the Admin Dashboard it redirects to, plus a separate Admin
Layout/Sidebar that every future Admin module (Categories, Products,
Customers, Orders, Coupons, Reports, Profile) will plug into.

**This package uses your project's REAL confirmed names directly** —
`EGroceryStoreDBEntities`, namespace `EGroceryStore.Models`, singular
entity classes (`User`, `Product`, `Category`, `Order`, `Coupon`), plural
DbSet names (`db.Users`, `db.Products`, `db.Categories`, `db.Orders`,
`db.Coupons`) — confirmed from your actual `Designer.cs`. There should be
little to no renaming needed this time.

---

## 0. Exact order of steps

1. Confirm the Customer Module still runs (Login, Home, Cart, etc.) before
   touching anything here.
2. Update `Helpers/SessionHelper.cs` — see `ExistingFileChanges/SessionHelper.cs.CHANGES.txt`.
   This is the only existing file that changes.
3. Copy in the new folders: `ViewModels/` (4 new files), `Controllers/AdminDashboardController.cs`,
   `Views/Shared/_AdminSidebar.cshtml`, `Views/Shared/_AdminLayout.cshtml`,
   `Content/CSS/Admin.css`, `Views/AdminDashboard/Index.cshtml`.
4. **Double-check the namespace.** This package assumes your project's
   namespace is exactly `EGroceryStore` and your context class is exactly
   `EGroceryStoreDBEntities` (both confirmed from your screenshot). If
   either is different, Find & Replace `EGroceryStore` across every new
   file, same as before.
5. Build (Ctrl+Shift+B). Fix anything red — see Common Errors below.
6. Run the project. Log in with your default Admin account (the one you
   created via SQL INSERT back in Stage 1, `Role = 'Admin'`).
7. You should land on `/AdminDashboard/Index` automatically — that's the
   `AccountController.Login()` redirect from Stage 1 doing its job.

---

## 1. What's in this folder

```
EGroceryStore_Admin_Part1/
├── Helpers/
│   └── SessionHelper.cs              full file, existing 3 methods + 1 new: IsAdminLoggedIn
├── ViewModels/
│   ├── AdminDashboardViewModel.cs    also contains CategorySalesViewModel
│   ├── RecentOrderViewModel.cs
│   ├── RecentCustomerViewModel.cs
│   └── LowStockProductViewModel.cs
├── Controllers/
│   └── AdminDashboardController.cs
├── Views/
│   ├── Shared/
│   │   ├── _AdminLayout.cshtml       separate from the Customer _Layout.cshtml
│   │   └── _AdminSidebar.cshtml      reusable partial - built once, used by every future Admin page
│   └── AdminDashboard/
│       └── Index.cshtml
├── Content/CSS/
│   └── Admin.css                     separate design system from Customer.css
├── ExistingFileChanges/
│   └── SessionHelper.cs.CHANGES.txt
└── README.md
```

## 2. Design decisions explained

**Why Admin gets its own `_AdminLayout.cshtml` instead of reusing the Customer one:**
The spec explicitly requires it — an Admin Panel looks and behaves nothing
like a shopping site (sidebar navigation vs. top navbar, different color
theme, no cart/wishlist icons). Keeping them separate also means editing
one never risks breaking the other.

**Why the "chart" is just Bootstrap progress bars, not a JavaScript library:**
See the note in our last conversation — this avoids adding Chart.js as a
new dependency and a new file type (JS) for a trainee-level project.
`AdminDashboardController` calculates each category's percentage of total
units sold in plain C#, and the View just draws a `<div>` whose `width` is
set to that percentage. It's a genuine, real-data chart — just rendered
with CSS instead of JavaScript.

**Why `RecentOrderViewModel.OrderDate` and `RecentCustomerViewModel.RegisteredDate`
are `DateTime?` (nullable) instead of plain `DateTime`:**
We hit exactly this class of error multiple times in the Customer Module —
some of your date columns turned out to allow NULL in SQL Server. Making
these ViewModel properties nullable means this file compiles correctly
either way, without needing to know your exact column settings in advance.
The View formats them safely with `.GetValueOrDefault()`.

**Why `IsAdminLoggedIn` lives in the same `SessionHelper.cs` instead of a
new `AdminSessionHelper.cs`:**
It's the same kind of check (read Session, return true/false) just with
one extra condition (Role == "Admin"). Splitting it into a second helper
class would be an unnecessary extra file for one extra `if` check.

**Why the sidebar has "dead" links (`href="#"`) for Categories, Products,
Customers, Orders, Coupons, Reports, Profile:**
Those Controllers don't exist yet — they're built in the next Parts. The
sidebar is written once, here, so that when we build
`AdminCategoryController` in Part 2, we only need to change one `href="#"`
to `@Url.Action("Index", "AdminCategory")` — the rest of the sidebar
structure, styling, and active-highlighting logic is already done.

## 3. Testing checklist

1. Log in with your Admin account (`Role = 'Admin'` in the `Users` table) →
   should land on `/AdminDashboard/Index`, not the Customer Home page.
2. Try logging in as a regular Customer, then manually type
   `localhost:XXXXX/AdminDashboard/Index` in the browser → should redirect
   you to Login with "Your session has expired" (this proves `IsAdminLoggedIn`
   is actually blocking Customers, not just hiding a link).
3. Summary cards should show real numbers matching what's actually in your
   database (spot-check `Total Customers` against `SELECT COUNT(*) FROM
   Users WHERE Role = 'Customer'` in SSMS).
4. If you have zero Orders/Customers/Products so far, confirm the page
   shows "No Orders Found" / "No Customers Registered" / etc. instead of
   crashing — this is intentional, not a bug.
5. Sidebar: click "Dashboard" — should stay highlighted since you're on it.
   The other links won't do anything yet (expected — see note above).

## 4. Common errors

| Error | Cause | Fix |
|---|---|---|
| `The type or namespace name 'EGroceryStoreDBEntities' could not be found` | Your context class is actually named differently, or namespace differs | Re-check your `.Designer.cs` file's exact class name and namespace, Find & Replace accordingly |
| `'EGroceryStoreDBEntities' does not contain a definition for 'Users'` (or similar) | Your DbSet property name differs from what's assumed here | Open `.Designer.cs`, confirm the exact DbSet property names, adjust the Controller |
| Dashboard loads but every summary card shows 0 | Your tables are genuinely empty, or `Role` values in `Users` aren't exactly `"Customer"`/`"Admin"` (case-sensitive) | Check actual values in SSMS: `SELECT DISTINCT Role FROM Users` |
| Redirected to Login immediately even as Admin | `Session["Role"]` wasn't set to exactly `"Admin"` during login, or session expired | Re-check your Admin user's `Role` column value in SQL, re-login |
| Sidebar overlaps the page content oddly on a narrow browser window | Expected on very small windows below the responsive breakpoint | This is handled by `Responsive.css`-style rules already in `Admin.css` — resize test on an actual phone-width browser, not just a slightly narrower desktop window |

---

**Next (Part 2):** Category Management — full CRUD, search, sort, pagination, image upload. Say the word when you're ready, and I'll do the same architecture-first, one-file-at-a-time approach before generating anything.
