using System.Collections.Generic;

namespace EGroceryStore.ViewModels
{
    // Carries every number and list the Dashboard page needs, all in one object.
    public class AdminDashboardViewModel
    {
        public int TotalCustomers { get; set; }
        public int TotalProducts { get; set; }
        public int TotalCategories { get; set; }
        public int TotalOrders { get; set; }
        public int PendingOrders { get; set; }
        public int DeliveredOrders { get; set; }
        public int ActiveCoupons { get; set; }
        public decimal TotalRevenue { get; set; }

        public List<RecentOrderViewModel> RecentOrders { get; set; }
        public List<RecentCustomerViewModel> RecentCustomers { get; set; }
        public List<LowStockProductViewModel> LowStockProducts { get; set; }

        // For the simple server-rendered "chart" bars - Category name + how wide its bar should be.
        public List<CategorySalesViewModel> TopCategoriesBySales { get; set; }
    }

    // Small helper shape used only for the "Top Categories" bar chart.
    public class CategorySalesViewModel
    {
        public string CategoryName { get; set; }
        public decimal PercentageOfTotalSales { get; set; }
    }
}
