namespace EGroceryStore.ViewModels
{
    // One row for the Dashboard's "Low Stock Products" table.
    // Needs CategoryName, which comes from a join with Categories.
    public class LowStockProductViewModel
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string CategoryName { get; set; }
        public int StockQuantity { get; set; }
    }
}
