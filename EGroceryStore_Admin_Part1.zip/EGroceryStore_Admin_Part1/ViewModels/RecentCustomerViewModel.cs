using System;

namespace EGroceryStore.ViewModels
{
    // One row for the Dashboard's "Recent Customers" table.
    public class RecentCustomerViewModel
    {
        public int UserId { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public DateTime? RegisteredDate { get; set; }
        public bool IsActive { get; set; }
    }
}
