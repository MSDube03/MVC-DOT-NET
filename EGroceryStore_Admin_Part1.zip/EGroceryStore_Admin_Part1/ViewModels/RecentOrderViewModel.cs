using System;

namespace EGroceryStore.ViewModels
{
    // One row for the Dashboard's "Recent Orders" table.
    // Needs CustomerName, which isn't a column on the Order table itself -
    // it comes from a join with Users - so a plain Order entity isn't enough.
    //
    // OrderDate is nullable (DateTime?) here on purpose - some SQL Server
    // date columns allow NULL, and making this property nullable means this
    // file compiles correctly no matter which way your OrderDate column was
    // set up. Format it safely in the View with .GetValueOrDefault().
    public class RecentOrderViewModel
    {
        public int OrderId { get; set; }
        public string OrderNumber { get; set; }
        public string CustomerName { get; set; }
        public DateTime? OrderDate { get; set; }
        public string OrderStatus { get; set; }
        public string PaymentStatus { get; set; }
        public decimal TotalAmount { get; set; }
    }
}
