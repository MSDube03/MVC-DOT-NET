using System;
using System.Linq;
using System.Web.Mvc;
using EGroceryStore.Helpers;
using EGroceryStore.Models;
using EGroceryStore.ViewModels;

namespace EGroceryStore.Controllers
{
    public class AdminCategoryController : Controller
    {
        private EGroceryStoreDBEntities db = new EGroceryStoreDBEntities();

        // How many categories to show per page.
        private const int PageSize = 10;

        // GET: AdminCategory/Index
        // Manage Categories page - search, sort, pagination, and the action buttons.
        public ActionResult Index(string searchTerm, string sortBy, int page = 1)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                TempData["ErrorMessage"] = "Your session has expired. Please login again.";
                return RedirectToAction("Login", "Account");
            }

            var query = db.Categories.AsQueryable();

            // Search: ToLower() on both sides makes this case-insensitive,
            // so searching "fruit" also matches "Fruits" or "FRUITS".
            // SQL equivalent: WHERE LOWER(CategoryName) LIKE '%searchterm%'
            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                query = query.Where(c => c.CategoryName.ToLower().Contains(searchTerm.ToLower()));
            }

            var categories = query.ToList();

            // Build each row with its live Product Count - this needs a lookup
            // into Products for every category, since Product Count isn't a
            // stored column anywhere.
            var rows = categories.Select(c => new AdminCategoryRowViewModel
            {
                CategoryId = c.CategoryId,
                CategoryName = c.CategoryName,
                Description = c.Description,
                ImagePath = c.ImagePath,
                IsActive = c.IsActive,
                ProductCount = db.Products.Count(p => p.CategoryId == c.CategoryId)
            }).ToList();

            // Sorting - done in memory since it's based on our combined ViewModel
            // rows (which include ProductCount), not a raw database column alone.
            switch (sortBy)
            {
                case "NameDesc":
                    rows = rows.OrderByDescending(r => r.CategoryName).ToList();
                    break;
                case "Status":
                    rows = rows.OrderByDescending(r => r.IsActive).ToList();
                    break;
                case "ProductCount":
                    rows = rows.OrderByDescending(r => r.ProductCount).ToList();
                    break;
                default:
                    rows = rows.OrderBy(r => r.CategoryName).ToList();
                    break;
            }

            // Pagination - Skip() jumps over earlier pages' rows, Take() grabs
            // only this page's worth. Same pattern as the Customer Product List.
            int totalPages = (int)Math.Ceiling((double)rows.Count / PageSize);
            if (page < 1) page = 1;
            var pagedRows = rows.Skip((page - 1) * PageSize).Take(PageSize).ToList();

            var model = new AdminCategoryListViewModel
            {
                Categories = pagedRows,
                SearchTerm = searchTerm,
                SortBy = sortBy,
                CurrentPage = page,
                TotalPages = totalPages
            };

            return View(model);
        }

        // GET: AdminCategory/Add
        public ActionResult Add()
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            return View(new CategoryFormViewModel { IsActive = true });
        }

        // POST: AdminCategory/Add
        [HttpPost]
        public ActionResult Add(CategoryFormViewModel model)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // Duplicate check - case-insensitive, same rule as Search above.
            bool duplicateExists = db.Categories.Any(c => c.CategoryName.ToLower() == model.CategoryName.ToLower());
            if (duplicateExists)
            {
                ModelState.AddModelError("CategoryName", "A category with this name already exists.");
                return View(model);
            }

            try
            {
                string savedFileName = ImageUploadHelper.SaveImage(model.CategoryImage, "Categories", Server);

                var newCategory = new Category
                {
                    CategoryName = model.CategoryName,
                    Description = model.Description,
                    ImagePath = savedFileName, // null if no image uploaded - that's fine, image is optional
                    IsActive = model.IsActive
                };

                db.Categories.Add(newCategory);
                db.SaveChanges();

                TempData["SuccessMessage"] = "Category added successfully.";
                return RedirectToAction("Index");
            }
            catch (ApplicationException ex)
            {
                // Thrown by ImageUploadHelper for an invalid file type or size.
                ModelState.AddModelError("CategoryImage", ex.Message);
                return View(model);
            }
            catch (Exception)
            {
                ModelState.AddModelError("", "Something went wrong while saving the category. Please try again.");
                return View(model);
            }
        }

        // GET: AdminCategory/Edit/5
        public ActionResult Edit(int id)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            var category = db.Categories.FirstOrDefault(c => c.CategoryId == id);
            if (category == null)
            {
                TempData["ErrorMessage"] = "Category not found.";
                return RedirectToAction("Index");
            }

            var model = new CategoryFormViewModel
            {
                CategoryId = category.CategoryId,
                CategoryName = category.CategoryName,
                Description = category.Description,
                IsActive = category.IsActive,
                ExistingImagePath = category.ImagePath
            };

            return View(model);
        }

        // POST: AdminCategory/Edit/5
        [HttpPost]
        public ActionResult Edit(CategoryFormViewModel model)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var category = db.Categories.FirstOrDefault(c => c.CategoryId == model.CategoryId);
            if (category == null)
            {
                TempData["ErrorMessage"] = "Category not found.";
                return RedirectToAction("Index");
            }

            // Duplicate check - excludes the category being edited itself,
            // otherwise it would always flag a "duplicate" of its own name.
            bool duplicateExists = db.Categories.Any(c =>
                c.CategoryName.ToLower() == model.CategoryName.ToLower() && c.CategoryId != model.CategoryId);
            if (duplicateExists)
            {
                ModelState.AddModelError("CategoryName", "A category with this name already exists.");
                model.ExistingImagePath = category.ImagePath;
                return View(model);
            }

            try
            {
                string savedFileName = ImageUploadHelper.SaveImage(model.CategoryImage, "Categories", Server);

                category.CategoryName = model.CategoryName;
                category.Description = model.Description;
                category.IsActive = model.IsActive;

                // If a new image was uploaded, replace the path.
                // If not (savedFileName is null), keep whatever was already there -
                // this is the "retain the previous image" business rule.
                if (savedFileName != null)
                {
                    category.ImagePath = savedFileName;
                }

                db.SaveChanges();

                TempData["SuccessMessage"] = "Category updated successfully.";
                return RedirectToAction("Index");
            }
            catch (ApplicationException ex)
            {
                ModelState.AddModelError("CategoryImage", ex.Message);
                model.ExistingImagePath = category.ImagePath;
                return View(model);
            }
            catch (Exception)
            {
                ModelState.AddModelError("", "Something went wrong while updating the category. Please try again.");
                model.ExistingImagePath = category.ImagePath;
                return View(model);
            }
        }

        // POST: AdminCategory/Delete
        [HttpPost]
        public ActionResult Delete(int id)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            var category = db.Categories.FirstOrDefault(c => c.CategoryId == id);
            if (category == null)
            {
                TempData["ErrorMessage"] = "Category not found.";
                return RedirectToAction("Index");
            }

            // BUSINESS RULE: never delete a Category that still has Products
            // in it. Deleting it anyway would either fail with a foreign key
            // error, or worse, silently leave those Products pointing at a
            // Category that no longer exists (orphaned data).
            bool hasProducts = db.Products.Any(p => p.CategoryId == id);
            if (hasProducts)
            {
                TempData["ErrorMessage"] = "This category contains products and cannot be deleted. Deactivate it instead, or move its products to another category first.";
                return RedirectToAction("Index");
            }

            db.Categories.Remove(category);
            db.SaveChanges();

            TempData["SuccessMessage"] = "Category deleted successfully.";
            return RedirectToAction("Index");
        }

        // POST: AdminCategory/ToggleStatus
        // Handles BOTH Activate and Deactivate - flips whatever the current status is.
        [HttpPost]
        public ActionResult ToggleStatus(int id)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            var category = db.Categories.FirstOrDefault(c => c.CategoryId == id);
            if (category == null)
            {
                TempData["ErrorMessage"] = "Category not found.";
                return RedirectToAction("Index");
            }

            category.IsActive = !category.IsActive;
            db.SaveChanges();

            TempData["SuccessMessage"] = category.IsActive
                ? "Category activated. It is now visible to customers."
                : "Category deactivated. It is now hidden from customers, along with its products.";

            return RedirectToAction("Index");
        }

        // GET: AdminCategory/Details/5
        public ActionResult Details(int id)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            var category = db.Categories.FirstOrDefault(c => c.CategoryId == id);
            if (category == null)
            {
                TempData["ErrorMessage"] = "Category not found.";
                return RedirectToAction("Index");
            }

            var products = db.Products.Where(p => p.CategoryId == id).ToList();

            var model = new CategoryDetailsViewModel
            {
                CategoryId = category.CategoryId,
                CategoryName = category.CategoryName,
                Description = category.Description,
                ImagePath = category.ImagePath,
                IsActive = category.IsActive,
                TotalProducts = products.Count,
                ProductNames = products.Select(p => p.ProductName).ToList()
            };

            return View(model);
        }
    }
}
