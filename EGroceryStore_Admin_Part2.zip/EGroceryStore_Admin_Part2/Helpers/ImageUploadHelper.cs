using System;
using System.IO;
using System.Web;

namespace EGroceryStore.Helpers
{
    /// <summary>
    /// Handles saving an uploaded image file to disk, under Content/Images/{folderName}/.
    /// Built as a shared Helper (not copy-pasted per Controller) because this exact
    /// same logic will be needed again for Products, and possibly other modules later.
    /// One place to fix a bug or change the rules, instead of several.
    /// </summary>
    public static class ImageUploadHelper
    {
        // Only these file types are accepted - anything else is rejected with
        // a friendly error instead of silently saving a broken/unsafe file.
        private static readonly string[] AllowedExtensions = { ".jpg", ".jpeg", ".png", ".gif" };

        // Maximum allowed file size, in bytes. 2 MB is generous for a product/category photo.
        private const int MaxFileSizeBytes = 2 * 1024 * 1024;

        /// <summary>
        /// Saves an uploaded image into Content/Images/{folderName}/ and returns
        /// the generated filename - this is what gets stored in the database's
        /// ImagePath column (just the filename, not the full path).
        /// Returns null if no file was uploaded - the caller decides what that
        /// means (Add: leave ImagePath empty; Edit: keep the old image).
        /// </summary>
        /// <param name="file">The uploaded file from the form (HttpPostedFileBase)</param>
        /// <param name="folderName">Sub-folder under Content/Images/, e.g. "Categories" or "Products"</param>
        /// <param name="server">Pass in the Controller's Server object (HttpServerUtilityBase), so this Helper can resolve the physical folder path</param>
        public static string SaveImage(HttpPostedFileBase file, string folderName, HttpServerUtilityBase server)
        {
            if (file == null || file.ContentLength == 0)
            {
                return null;
            }

            string extension = Path.GetExtension(file.FileName).ToLower();
            if (Array.IndexOf(AllowedExtensions, extension) == -1)
            {
                throw new ApplicationException("Only image files (.jpg, .jpeg, .png, .gif) are allowed.");
            }

            if (file.ContentLength > MaxFileSizeBytes)
            {
                throw new ApplicationException("Image file size must be under 2 MB.");
            }

            // A unique, generated filename means a new upload can never
            // accidentally overwrite an existing image that happens to share
            // the same original filename (e.g. two people both uploading "photo.jpg").
            string uniqueFileName = Guid.NewGuid().ToString("N") + extension;

            string folderPath = server.MapPath("~/Content/Images/" + folderName + "/");
            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(folderPath);
            }

            string fullPath = Path.Combine(folderPath, uniqueFileName);
            file.SaveAs(fullPath);

            return uniqueFileName;
        }
    }
}
