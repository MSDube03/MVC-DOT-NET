# E-Grocery Store — Admin Module, Part 2: Category Management

Full CRUD for Categories: view, search, sort, paginate, add, edit, delete
(with a safety check), activate/deactivate, image upload, and a details page.

**Business context, briefly:** every Product must belong to exactly one
Category. Without solid Category management, products can't be organized,
search/filter become unreliable, and customers can't browse properly — so
this is one of the more important Admin modules, and the rules here (no
duplicate names, no deleting a Category that still has products, inactive
= hidden from customers) all exist to protect that foundation.

---

## 0. Exact order of steps

1. Confirm Part 1 (Admin Login + Dashboard) still works before starting.
2. Copy in: `Helpers/ImageUploadHelper.cs`, `ViewModels/` (3 new files),
   `Controllers/AdminCategoryController.cs`, `Views/AdminCategory/` (4 views),
   `Content/CSS/Category.css`.
3. Update `Views/Shared/_AdminSidebar.cshtml` — see
   `ExistingFileChanges/_AdminSidebar.cshtml.CHANGES.txt` (one link, one line).
4. Update `Controllers/ProductController.cs` **in your Customer Module** —
   see `ExistingFileChanges/ProductController.cs.CHANGES.txt`. This is the
   only change that touches Customer-side code; it's what makes
   "deactivate a category → its products disappear for customers" actually
   true, per the spec's business rule.
5. Add the new CSS link to `_AdminLayout.cshtml`'s `<head>` — see step 6 below.
6. Build (Ctrl+Shift+B), fix anything red, run, test.

**One small addition to `_AdminLayout.cshtml`:** add this line inside the
`<head>`, right after the existing `Admin.css` link:
```html
<link href="~/Content/CSS/Category.css" rel="stylesheet" />
```

---

## 1. What's in this folder

```
EGroceryStore_Admin_Part2/
├── Helpers/
│   └── ImageUploadHelper.cs          shared, reusable - Products (Part 3) will use this too
├── ViewModels/
│   ├── CategoryFormViewModel.cs      used by both Add and Edit forms
│   ├── AdminCategoryListViewModel.cs also contains AdminCategoryRowViewModel
│   └── CategoryDetailsViewModel.cs
├── Controllers/
│   └── AdminCategoryController.cs
├── Views/AdminCategory/
│   ├── Index.cshtml                  Manage Categories - search, sort, table, pagination
│   ├── Add.cshtml
│   ├── Edit.cshtml
│   └── Details.cshtml
├── Content/CSS/
│   └── Category.css
├── ExistingFileChanges/
│   ├── _AdminSidebar.cshtml.CHANGES.txt
│   └── ProductController.cs.CHANGES.txt   (Customer Module fix)
└── README.md
```

## 2. Design decisions explained

**Why `ImageUploadHelper` is a shared Helper, not inline code in the Controller:**
The exact same "validate file type/size, save with a unique name, return
the filename" logic will be needed again in Part 3 for Product images.
Building it once here means Part 3 just calls it — no copy-pasted upload
code to maintain in two places.

**Why uploaded images get a randomly generated filename instead of keeping
the original name:** if two different uploads both happen to be named
`photo.jpg`, keeping the original name would let the second upload silently
overwrite the first. A generated unique name (`a1b2c3...jpg`) makes that
impossible.

**Why Delete checks for existing Products first, instead of just deleting:**
If Products still reference a deleted Category, you'd either get a database
foreign-key error, or — if the database allowed it — a orphaned Product
pointing at a Category that no longer exists, which would likely crash the
Customer Product Details page. Blocking the delete with a clear message is
far safer, and points the Admin toward Deactivate as the correct alternative.

**Why Deactivate/Activate is one action (`ToggleStatus`) instead of two:**
Both do the exact same thing — flip the current value — so one action with
one `if` is simpler than two nearly-identical actions.

**Why the Customer-side `ProductController.cs` needs a change here:**
This is the one place in Part 2 where an "Admin" change has a real,
required effect on the Customer Module — deactivating a Category is
supposed to hide its products from customers too, and that logic has to
live in the Customer-facing Controller, since that's what customers
actually browse through. See the exact diff in `ExistingFileChanges/`.

## 3. Testing checklist

1. **Add** a category with a name, description, and an image → appears in
   the list with 0 products, image thumbnail shows correctly.
2. **Add** a second category with the exact same name (different casing,
   e.g. `FRUITS` vs `fruits`) → should be blocked with "already exists".
3. **Search** for part of a category name in different casing → should
   still find it.
4. **Sort** by each of the 4 options → list order changes correctly.
5. **Edit** a category, change only the description, leave the image field
   empty → confirm the original image is still there afterward (not blanked out).
6. **Edit** a category and upload a new image → confirm it replaces the old one.
7. **Deactivate** a category that has real Products under it (if you've got
   some in your DB) → then browse to that category as a Customer (or via
   Product search) → confirm those products no longer appear, and visiting
   a specific product's Details URL directly also 404s instead of showing it.
8. **Reactivate** the same category → confirm products reappear for customers.
9. **Try to Delete** a category that has Products → should be blocked with
   the friendly message, not a crash.
10. **Delete** a category with zero Products → should succeed and disappear
    from the list.
11. **Pagination** — if you add 11+ categories, confirm page 2 shows the
    rest and the search/sort you had selected stays applied across pages.
12. Try uploading a non-image file (e.g. a `.txt` renamed to `.jpg` won't
    trigger this — try an actual `.pdf` or `.docx`) → should show the
    friendly "Only image files..." error, not a crash.

## 4. Common errors

| Error | Cause | Fix |
|---|---|---|
| `The type or namespace name 'Category' could not be found` | Namespace mismatch, same class of issue as before | Confirm `EGroceryStore.Models` matches your real namespace |
| Uploaded image doesn't show on the page afterward | `Content/Images/Categories/` folder doesn't exist yet | `ImageUploadHelper` creates it automatically on first upload — if it still fails, manually create `Content/Images/Categories/` in Solution Explorer once |
| `Maximum request length exceeded` when uploading an image | Very rare with a 2MB limit, but IIS/ASP.NET has its own default upload cap | Only relevant for unusually large files — not expected with the 2MB check already in place |
| Delete button does nothing, no error shown | The `onsubmit="return confirm(...)"` JavaScript may have been stripped by a copy-paste issue | Re-check the Delete `@using (Html.BeginForm(...))` block in `Index.cshtml` still has the `onsubmit` attribute intact |
| Deactivating a Category doesn't actually hide its products from customers | The `ProductController.cs` change wasn't applied yet | Go back and apply `ExistingFileChanges/ProductController.cs.CHANGES.txt` — this is a required step, not optional |

---

**Next (Part 3):** Product Management — this will reuse `ImageUploadHelper`
directly, so it should be noticeably faster to build and test than this
round. Say the word when you're ready.
