using System.Collections.Generic;

namespace EGroceryStore.ViewModels
{
    // One row in the Manage Categories table.
    // ProductCount isn't a column on the Categories table - it comes from
    // counting matching rows in Products - so a plain Category entity can't
    // carry it on its own.
    public class AdminCategoryRowViewModel
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public string Description { get; set; }
        public string ImagePath { get; set; }
        public bool IsActive { get; set; }
        public int ProductCount { get; set; }
    }

    // Carries the category list AND the current search/sort/page values
    // together, so the Manage Categories view can re-display exactly what
    // the Admin selected - same pattern used for the Customer Product List page.
    public class AdminCategoryListViewModel
    {
        public List<AdminCategoryRowViewModel> Categories { get; set; }
        public string SearchTerm { get; set; }
        public string SortBy { get; set; }
        public int CurrentPage { get; set; }
        public int TotalPages { get; set; }
    }
}
