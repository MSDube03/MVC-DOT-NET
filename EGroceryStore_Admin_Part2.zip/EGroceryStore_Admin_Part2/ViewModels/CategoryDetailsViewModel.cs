using System.Collections.Generic;

namespace EGroceryStore.ViewModels
{
    // Everything the Category Details page needs to display - the category's
    // own fields, plus a product count and product name list, both of which
    // come from a join with the Products table.
    public class CategoryDetailsViewModel
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public string Description { get; set; }
        public string ImagePath { get; set; }
        public bool IsActive { get; set; }
        public int TotalProducts { get; set; }
        public List<string> ProductNames { get; set; }
    }
}
