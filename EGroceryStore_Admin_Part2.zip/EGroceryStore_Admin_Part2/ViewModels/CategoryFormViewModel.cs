using System.ComponentModel.DataAnnotations;
using System.Web;

namespace EGroceryStore.ViewModels
{
    // Used by BOTH Add Category and Edit Category forms.
    //
    // WHY THIS VIEWMODEL IS NEEDED instead of binding directly to the
    // Category EF entity:
    // 1. The form needs to accept an uploaded FILE (CategoryImage), but the
    //    Category entity's ImagePath column only stores a filename string -
    //    there's no way to bind an <input type="file"> directly to a string.
    // 2. The EF entity has no [Required]/[StringLength] validation attributes
    //    (those live in your SQL Server column definitions, not in C#), so a
    //    form bound directly to it would show no red validation messages at all.
    public class CategoryFormViewModel
    {
        // 0 when adding a new category. Set to the real CategoryId when editing.
        public int CategoryId { get; set; }

        [Required(ErrorMessage = "Category name is required")]
        [StringLength(100, ErrorMessage = "Category name cannot exceed 100 characters")]
        public string CategoryName { get; set; }

        [StringLength(500, ErrorMessage = "Description cannot exceed 500 characters")]
        public string Description { get; set; }

        // Defaults to true (Active) for new categories, per the business rule
        // "Status - Default Active".
        public bool IsActive { get; set; } = true;

        // The file the Admin is uploading right now (optional - may be null).
        public HttpPostedFileBase CategoryImage { get; set; }

        // Only used on the Edit form - shows the CURRENT image so the Admin
        // can see what's already saved, and so we know what to keep if no
        // new file is uploaded.
        public string ExistingImagePath { get; set; }
    }
}
