using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using EGroceryStore.Helpers;
using EGroceryStore.Models;
using EGroceryStore.ViewModels;

namespace EGroceryStore.Controllers
{
    public class AdminProductController : Controller
    {
        private EGroceryStoreDBEntities db = new EGroceryStoreDBEntities();

        private const int PageSize = 10;
        private const int LowStockThreshold = 10;

        // GET: AdminProduct/Index
        public ActionResult Index(string searchTerm, int? categoryId, decimal? minPrice, decimal? maxPrice,
            string stockStatus, string productStatus, int? minRating, string sortBy, int page = 1)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                TempData["ErrorMessage"] = "Your session has expired. Please login again.";
                return RedirectToAction("Login", "Account");
            }

            var query = db.Products.AsQueryable();

            // ----- Search (Product Name OR Category Name), case-insensitive -----
            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                var matchingCategoryIds = db.Categories
                    .Where(c => c.CategoryName.ToLower().Contains(searchTerm.ToLower()))
                    .Select(c => c.CategoryId)
                    .ToList();

                query = query.Where(p =>
                    p.ProductName.ToLower().Contains(searchTerm.ToLower()) ||
                    matchingCategoryIds.Contains(p.CategoryId));
            }

            // ----- Filters -----
            if (categoryId.HasValue) query = query.Where(p => p.CategoryId == categoryId.Value);
            if (minPrice.HasValue) query = query.Where(p => p.Price >= minPrice.Value);
            if (maxPrice.HasValue) query = query.Where(p => p.Price <= maxPrice.Value);

            if (stockStatus == "InStock") query = query.Where(p => p.StockQuantity > LowStockThreshold);
            else if (stockStatus == "LowStock") query = query.Where(p => p.StockQuantity > 0 && p.StockQuantity <= LowStockThreshold);
            else if (stockStatus == "OutOfStock") query = query.Where(p => p.StockQuantity == 0);

            if (productStatus == "Active") query = query.Where(p => p.IsActive == true);
            else if (productStatus == "Inactive") query = query.Where(p => p.IsActive == false);

            if (minRating.HasValue) query = query.Where(p => p.AverageRating >= minRating.Value);

            // ----- Sorting -----
            switch (sortBy)
            {
                case "PriceDesc": query = query.OrderByDescending(p => p.Price); break;
                case "PriceAsc": query = query.OrderBy(p => p.Price); break;
                case "StockAsc": query = query.OrderBy(p => p.StockQuantity); break;
                case "StockDesc": query = query.OrderByDescending(p => p.StockQuantity); break;
                case "RatingDesc": query = query.OrderByDescending(p => p.AverageRating); break;
                case "Newest": query = query.OrderByDescending(p => p.CreatedDate); break;
                default: query = query.OrderBy(p => p.ProductName); break;
            }

            var allMatching = query.ToList();
            int totalPages = (int)Math.Ceiling((double)allMatching.Count / PageSize);
            if (page < 1) page = 1;
            var pagedProducts = allMatching.Skip((page - 1) * PageSize).Take(PageSize).ToList();

            // Build display rows, looking up each product's Category name manually.
            var rows = new List<AdminProductRowViewModel>();
            foreach (var product in pagedProducts)
            {
                var category = db.Categories.FirstOrDefault(c => c.CategoryId == product.CategoryId);

                rows.Add(new AdminProductRowViewModel
                {
                    ProductId = product.ProductId,
                    ProductName = product.ProductName,
                    CategoryName = category != null ? category.CategoryName : "Uncategorized",
                    ImagePath = product.ImagePath,
                    Price = product.Price,
                    StockQuantity = product.StockQuantity,
                    Units = product.Units,
                    AverageRating = product.AverageRating,
                    IsActive = product.IsActive == true,
                    CreatedDate = product.CreatedDate
                });
            }

            var model = new AdminProductListViewModel
            {
                Products = rows,
                Categories = db.Categories.OrderBy(c => c.CategoryName).ToList(),
                SearchTerm = searchTerm,
                SelectedCategoryId = categoryId,
                MinPrice = minPrice,
                MaxPrice = maxPrice,
                StockStatus = stockStatus,
                ProductStatus = productStatus,
                MinRating = minRating,
                SortBy = sortBy,
                CurrentPage = page,
                TotalPages = totalPages
            };

            return View(model);
        }

        // GET: AdminProduct/Add
        public ActionResult Add()
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            ViewBag.Categories = db.Categories.OrderBy(c => c.CategoryName).ToList();
            return View(new ProductFormViewModel { IsActive = true });
        }

        // POST: AdminProduct/Add
        [HttpPost]
        public ActionResult Add(ProductFormViewModel model)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            if (!ModelState.IsValid)
            {
                ViewBag.Categories = db.Categories.OrderBy(c => c.CategoryName).ToList();
                return View(model);
            }

            bool duplicateExists = db.Products.Any(p => p.ProductName.ToLower() == model.ProductName.ToLower());
            if (duplicateExists)
            {
                ModelState.AddModelError("ProductName", "A product with this name already exists.");
                ViewBag.Categories = db.Categories.OrderBy(c => c.CategoryName).ToList();
                return View(model);
            }

            try
            {
                string savedFileName = ImageUploadHelper.SaveImage(model.ProductImage, "Products", Server);

                var newProduct = new Product
                {
                    CategoryId = model.CategoryId,
                    ProductName = model.ProductName,
                    Description = model.Description,
                    Price = model.Price,
                    StockQuantity = model.StockQuantity,
                    Units = model.Units,
                    ImagePath = savedFileName,
                    AverageRating = null,
                    IsActive = model.IsActive,
                    CreatedDate = DateTime.Now
                };

                db.Products.Add(newProduct);
                db.SaveChanges();

                TempData["SuccessMessage"] = "Product added successfully.";
                return RedirectToAction("Index");
            }
            catch (ApplicationException ex)
            {
                ModelState.AddModelError("ProductImage", ex.Message);
                ViewBag.Categories = db.Categories.OrderBy(c => c.CategoryName).ToList();
                return View(model);
            }
            catch (Exception)
            {
                ModelState.AddModelError("", "Something went wrong while saving the product. Please try again.");
                ViewBag.Categories = db.Categories.OrderBy(c => c.CategoryName).ToList();
                return View(model);
            }
        }

        // GET: AdminProduct/Edit/5
        public ActionResult Edit(int id)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            var product = db.Products.FirstOrDefault(p => p.ProductId == id);
            if (product == null)
            {
                TempData["ErrorMessage"] = "Product not found.";
                return RedirectToAction("Index");
            }

            ViewBag.Categories = db.Categories.OrderBy(c => c.CategoryName).ToList();

            var model = new ProductFormViewModel
            {
                ProductId = product.ProductId,
                CategoryId = product.CategoryId,
                ProductName = product.ProductName,
                Description = product.Description,
                Price = product.Price,
                StockQuantity = product.StockQuantity,
                Units = product.Units,
                IsActive = product.IsActive == true,
                ExistingImagePath = product.ImagePath
            };

            return View(model);
        }

        // POST: AdminProduct/Edit/5
        [HttpPost]
        public ActionResult Edit(ProductFormViewModel model)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            if (!ModelState.IsValid)
            {
                ViewBag.Categories = db.Categories.OrderBy(c => c.CategoryName).ToList();
                return View(model);
            }

            var product = db.Products.FirstOrDefault(p => p.ProductId == model.ProductId);
            if (product == null)
            {
                TempData["ErrorMessage"] = "Product not found.";
                return RedirectToAction("Index");
            }

            bool duplicateExists = db.Products.Any(p =>
                p.ProductName.ToLower() == model.ProductName.ToLower() && p.ProductId != model.ProductId);
            if (duplicateExists)
            {
                ModelState.AddModelError("ProductName", "A product with this name already exists.");
                model.ExistingImagePath = product.ImagePath;
                ViewBag.Categories = db.Categories.OrderBy(c => c.CategoryName).ToList();
                return View(model);
            }

            try
            {
                string savedFileName = ImageUploadHelper.SaveImage(model.ProductImage, "Products", Server);

                product.CategoryId = model.CategoryId;
                product.ProductName = model.ProductName;
                product.Description = model.Description;
                product.Price = model.Price;
                product.StockQuantity = model.StockQuantity;
                product.Units = model.Units;
                product.IsActive = model.IsActive;

                // Only touch the image if a new one was uploaded. If so, also
                // delete the OLD image file from disk - otherwise every edit
                // that changes a photo leaves the previous file behind forever,
                // slowly filling up the server with unused images.
                if (savedFileName != null)
                {
                    string oldImagePath = product.ImagePath;
                    product.ImagePath = savedFileName;

                    if (!string.IsNullOrEmpty(oldImagePath))
                    {
                        string oldFullPath = Server.MapPath("~/Content/Images/Products/" + oldImagePath);
                        if (System.IO.File.Exists(oldFullPath))
                        {
                            System.IO.File.Delete(oldFullPath);
                        }
                    }
                }

                db.SaveChanges();

                TempData["SuccessMessage"] = "Product updated successfully.";
                return RedirectToAction("Index");
            }
            catch (ApplicationException ex)
            {
                ModelState.AddModelError("ProductImage", ex.Message);
                model.ExistingImagePath = product.ImagePath;
                ViewBag.Categories = db.Categories.OrderBy(c => c.CategoryName).ToList();
                return View(model);
            }
            catch (Exception)
            {
                ModelState.AddModelError("", "Something went wrong while updating the product. Please try again.");
                model.ExistingImagePath = product.ImagePath;
                ViewBag.Categories = db.Categories.OrderBy(c => c.CategoryName).ToList();
                return View(model);
            }
        }

        // POST: AdminProduct/Delete
        [HttpPost]
        public ActionResult Delete(int id)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            var product = db.Products.FirstOrDefault(p => p.ProductId == id);
            if (product == null)
            {
                TempData["ErrorMessage"] = "Product not found.";
                return RedirectToAction("Index");
            }

            // BUSINESS RULE: never delete a product that customers have
            // already interacted with in a way that matters - if it's sitting
            // in someone's Cart or Wishlist right now, or if it's part of a
            // REAL past Order, deleting it would break that data (an order
            // history row pointing at a product that no longer exists).
            bool inCart = db.Carts.Any(c => c.ProductId == id);
            bool inWishlist = db.Wishlists.Any(w => w.ProductId == id);
            bool inOrders = db.OrderDetails.Any(od => od.ProductId == id);

            if (inCart || inWishlist || inOrders)
            {
                TempData["ErrorMessage"] = "This product cannot be deleted because it exists in a customer's Cart, Wishlist, or a past Order. Deactivate it instead.";
                return RedirectToAction("Index");
            }

            // Safe to physically delete the image file too, since nothing
            // depends on this product anymore.
            if (!string.IsNullOrEmpty(product.ImagePath))
            {
                string fullPath = Server.MapPath("~/Content/Images/Products/" + product.ImagePath);
                if (System.IO.File.Exists(fullPath))
                {
                    System.IO.File.Delete(fullPath);
                }
            }

            db.Products.Remove(product);
            db.SaveChanges();

            TempData["SuccessMessage"] = "Product deleted successfully.";
            return RedirectToAction("Index");
        }

        // POST: AdminProduct/ToggleStatus
        [HttpPost]
        public ActionResult ToggleStatus(int id)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            var product = db.Products.FirstOrDefault(p => p.ProductId == id);
            if (product == null)
            {
                TempData["ErrorMessage"] = "Product not found.";
                return RedirectToAction("Index");
            }

            product.IsActive = !(product.IsActive == true);
            db.SaveChanges();

            TempData["SuccessMessage"] = (product.IsActive == true)
                ? "Product activated. It is now visible to customers."
                : "Product deactivated. It is now hidden from customers everywhere - Home, Search, Category pages, Wishlist and Cart.";

            return RedirectToAction("Index");
        }

        // GET: AdminProduct/Details/5
        public ActionResult Details(int id)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            var product = db.Products.FirstOrDefault(p => p.ProductId == id);
            if (product == null)
            {
                TempData["ErrorMessage"] = "Product not found.";
                return RedirectToAction("Index");
            }

            var category = db.Categories.FirstOrDefault(c => c.CategoryId == product.CategoryId);

            // Simple statistics, pulled from real data - never hardcoded.
            // Sum() with (int?) + ?? 0 avoids a crash if this product has
            // never been ordered at all.
            int totalUnitsSold = db.OrderDetails
                .Where(od => od.ProductId == id)
                .Sum(od => (int?)od.Quantity) ?? 0;

            int timesWishlisted = db.Wishlists.Count(w => w.ProductId == id);
            int timesInCarts = db.Carts.Count(c => c.ProductId == id);

            var model = new ProductDetailsViewModel
            {
                ProductId = product.ProductId,
                ProductName = product.ProductName,
                CategoryName = category != null ? category.CategoryName : "Uncategorized",
                Description = product.Description,
                Price = product.Price,
                Units = product.Units,
                StockQuantity = product.StockQuantity,
                AverageRating = product.AverageRating,
                IsActive = product.IsActive == true,
                CreatedDate = product.CreatedDate,
                ImagePath = product.ImagePath,
                TotalUnitsSold = totalUnitsSold,
                TimesWishlisted = timesWishlisted,
                TimesInCarts = timesInCarts
            };

            return View(model);
        }
    }
}
