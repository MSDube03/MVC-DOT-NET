# E-Grocery Store — Admin Module, Part 3: Product Management

Full CRUD for Products: search, filter (category/price/stock/status/rating),
sort, paginate, add, edit, delete (with a purchase-history safety check),
activate/deactivate, image upload/replace, and a details page with live
statistics.

**Business context, briefly:** Products are what everything else in the
store depends on — without them, customers can't browse, search, wishlist,
cart, or buy anything, and no revenue exists to report on. That's why the
rules here are stricter than Categories: never let a product be deleted if
it's touched a real customer's cart, wishlist, or order history.

**This module reuses `ImageUploadHelper` from Part 2 directly** — no new
upload code needed, just calling the same Helper with `"Products"` as the
folder name instead of `"Categories"`.

---

## 0. Exact order of steps

1. Confirm Part 1 and Part 2 both still work before starting.
2. Copy in: `ViewModels/` (3 new files), `Controllers/AdminProductController.cs`,
   `Views/AdminProduct/` (4 views), `Content/CSS/AdminProduct.css`.
3. Update `Views/Shared/_AdminSidebar.cshtml` — wire the Products link.
   See `ExistingFileChanges/_AdminSidebar.cshtml.CHANGES.txt`.
4. Update `Views/Shared/_AdminLayout.cshtml` — add the new CSS link.
   See `ExistingFileChanges/_AdminLayout.cshtml.CHANGES.txt`.
5. Update `Views/AdminDashboard/Index.cshtml` — wire up two placeholder
   buttons from Part 1. See `ExistingFileChanges/AdminDashboardIndex.cshtml.CHANGES.txt`.
6. **Two required Customer Module fixes** — without these, deactivating a
   product from the Admin panel won't actually hide it from customers who
   already have it in their Cart or Wishlist:
   - `Controllers/WishlistController.cs` — see `ExistingFileChanges/WishlistController.cs.CHANGES.txt`
   - `Controllers/CartController.cs` — see `ExistingFileChanges/CartController.cs.CHANGES.txt`
7. Build (Ctrl+Shift+B), fix anything red, run, test.

---

## 1. What's in this folder

```
EGroceryStore_Admin_Part3/
├── ViewModels/
│   ├── ProductFormViewModel.cs        used by both Add and Edit forms
│   ├── AdminProductListViewModel.cs   also contains AdminProductRowViewModel
│   └── ProductDetailsViewModel.cs
├── Controllers/
│   └── AdminProductController.cs
├── Views/AdminProduct/
│   ├── Index.cshtml     Manage Products - search, filters, sort, table, pagination
│   ├── Add.cshtml
│   ├── Edit.cshtml
│   └── Details.cshtml   includes live "Product Statistics"
├── Content/CSS/
│   └── AdminProduct.css   NOT named "Product.css" - see note below
├── ExistingFileChanges/
│   ├── _AdminSidebar.cshtml.CHANGES.txt
│   ├── _AdminLayout.cshtml.CHANGES.txt
│   ├── AdminDashboardIndex.cshtml.CHANGES.txt
│   ├── WishlistController.cs.CHANGES.txt   (Customer Module fix)
│   └── CartController.cs.CHANGES.txt       (Customer Module fix)
└── README.md
```

## 2. Design decisions explained

**Why the CSS file is named `AdminProduct.css`, not `Product.css`:**
Your Customer Module already has `Content/CSS/Product.css` from Stage 2.
Since Admin and Customer share the same physical `Content/CSS/` folder,
a second file also called `Product.css` would either fail to copy in, or
silently overwrite your working Customer styling. Different name, zero
collision risk.

**Why the Category dropdown only ever stores a `CategoryId`, never lets
the Admin type one manually:**
If a typo or a made-up ID got saved (e.g. `CategoryId = 999` when no such
category exists), that product would become invisible in every
Category-based Customer page (since none of them would match it), and its
"Category" column would show blank or crash the page. A dropdown populated
directly from the real `Categories` table makes an invalid CategoryId
structurally impossible.

**Why Delete checks Cart, Wishlist, AND OrderDetails (three tables, not
just one):** any of the three represents a real customer touchpoint you
don't want to silently break. A product sitting in someone's cart right
now, someone's saved wishlist, or especially inside a **real past order** —
deleting it in any of those cases either crashes that customer's page or
corrupts historical order data. Deactivate is always the safe alternative.

**Why deleting a product also deletes its image file from disk, but
deactivating does NOT:** Delete is permanent and only allowed when nothing
depends on the product anymore, so cleaning up its image file is safe and
prevents orphaned files piling up on the server. Deactivate is reversible
by design — the Admin might turn it back on next week — so the image stays
exactly where it is.

**Why Edit deletes the OLD image file when a new one is uploaded:**
Otherwise every single photo change leaves the previous file sitting on
disk forever, doing nothing, slowly wasting space. Since the old filename
is a randomly generated one no one else references, it's always safe to
remove once replaced.

**Why the two Customer Module fixes (Wishlist/Cart) only filter what's
*displayed*, not delete the underlying row:** if the Admin reactivates a
product later, it should reappear automatically in customers' carts and
wishlists exactly as it was — deleting the row would lose that data
permanently for no reason.

## 3. Testing checklist

1. **Add** a product: pick a category from the dropdown, fill in all
   fields, upload an image → appears correctly in the list.
2. **Add** a product with a duplicate name → blocked with the right message.
3. **Search** by product name, then by category name → both work,
   case-insensitive.
4. **Filter** by category, price range, stock status, and product status,
   individually and combined → results narrow correctly each time.
5. **Sort** by each of the 6 options → order changes correctly.
6. **Edit** a product, change only the price, leave the image field empty
   → confirm the original image is still there.
7. **Edit** a product and upload a new image → confirm the old image file
   is gone from `Content/Images/Products/` on disk (not just replaced in
   the database).
8. **Try to Delete** a product that's in a customer's cart or wishlist (or
   has a past order) → blocked with the friendly message.
9. **Delete** a brand-new product with none of the above → succeeds.
10. **Deactivate** a product that's currently in a test customer's Cart
    and Wishlist → log in as that customer → confirm it's gone from both
    Cart and Wishlist pages, and Cart's Grand Total recalculates without it.
11. **Reactivate** the same product → confirm it reappears in that
    customer's Cart and Wishlist automatically.
12. **View Details** on a product that's actually been ordered before →
    confirm "Units Sold" shows a real number matching your `OrderDetails` data.
13. From the **Dashboard**, click "+ Add Product" and a Low Stock row's
    "Update Stock" button → both should take you to the right page now.

## 4. Common errors

| Error | Cause | Fix |
|---|---|---|
| Category dropdown is empty on the Add page | No categories exist yet, or `ViewBag.Categories` wasn't set | Add at least one Category first (Part 2); confirm the Controller sets `ViewBag.Categories` before returning the view |
| `Cannot convert type 'object' to 'IEnumerable'` around the dropdown | Rare - only if `ViewBag.Categories` wasn't set at all | Re-check the Controller's `Add()`/`Edit()` GET actions both set `ViewBag.Categories` |
| Deactivating a product doesn't remove it from a customer's cart | The WishlistController/CartController fixes weren't applied yet | Go back and apply both `ExistingFileChanges/...Controller.cs.CHANGES.txt` files - required, not optional |
| Old product image still sits in `Content/Images/Products/` after replacing it | Edit's image-delete logic didn't run - check `Server.MapPath` resolved correctly | Confirm the file actually exists at that exact path before troubleshooting further; this is cosmetic (wasted disk space), not a functional bug |
| "This product cannot be deleted..." appears even for a product you're sure isn't used anywhere | Check all three tables directly in SSMS: `SELECT * FROM Cart WHERE ProductId = X`, same for `Wishlist` and `OrderDetails` | If truly empty everywhere, this points to a ProductId mismatch - double check you're testing the right product |

---

**Next (Part 4):** based on your uploaded file's structure, this is likely
Customer Management or Order Management. Say the word when you're ready,
and I'll read that section and build the same way.
