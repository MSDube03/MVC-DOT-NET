using System;
using System.Collections.Generic;
using EGroceryStore.Models;

namespace EGroceryStore.ViewModels
{
    // One row in the Manage Products table. CategoryName isn't a column on
    // Products - it comes from a join with Categories.
    public class AdminProductRowViewModel
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string CategoryName { get; set; }
        public string ImagePath { get; set; }
        public decimal Price { get; set; }
        public int StockQuantity { get; set; }
        public string Units { get; set; }
        public decimal? AverageRating { get; set; }
        public bool IsActive { get; set; }
        public DateTime? CreatedDate { get; set; }
    }

    // Carries the product list AND every current search/filter/sort/page
    // value together - same pattern as the Customer Product List page.
    public class AdminProductListViewModel
    {
        public List<AdminProductRowViewModel> Products { get; set; }
        public List<Category> Categories { get; set; } // populates the filter dropdown

        public string SearchTerm { get; set; }
        public int? SelectedCategoryId { get; set; }
        public decimal? MinPrice { get; set; }
        public decimal? MaxPrice { get; set; }
        public string StockStatus { get; set; }   // "", "InStock", "LowStock", "OutOfStock"
        public string ProductStatus { get; set; } // "", "Active", "Inactive"
        public int? MinRating { get; set; }
        public string SortBy { get; set; }

        public int CurrentPage { get; set; }
        public int TotalPages { get; set; }
    }
}
