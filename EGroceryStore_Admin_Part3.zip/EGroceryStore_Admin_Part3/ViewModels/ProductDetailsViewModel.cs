using System;

namespace EGroceryStore.ViewModels
{
    // Everything the Product Details page needs - the product's own fields,
    // its Category name (joined from Categories), and three simple
    // statistics pulled from real order/wishlist/cart data.
    public class ProductDetailsViewModel
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string CategoryName { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public string Units { get; set; }
        public int StockQuantity { get; set; }
        public decimal? AverageRating { get; set; }
        public bool IsActive { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string ImagePath { get; set; }

        public int TotalUnitsSold { get; set; }
        public int TimesWishlisted { get; set; }
        public int TimesInCarts { get; set; }
    }
}
