using System.ComponentModel.DataAnnotations;
using System.Web;

namespace EGroceryStore.ViewModels
{
    // Used by both Add Product and Edit Product forms.
    // Same reasoning as CategoryFormViewModel (Part 2): the EF entity has no
    // validation attributes, and a form field can't bind an uploaded FILE
    // directly to the ImagePath string column.
    public class ProductFormViewModel
    {
        // 0 when adding a new product. Set to the real ProductId when editing.
        public int ProductId { get; set; }

        // The dropdown binds to this. Only real CategoryIds from the
        // Categories table can ever end up here - the Admin picks a name
        // from a list, never types a raw ID (see README for why this matters).
        [Required(ErrorMessage = "Please select a category")]
        public int CategoryId { get; set; }

        [Required(ErrorMessage = "Product name is required")]
        [StringLength(150, ErrorMessage = "Product name cannot exceed 150 characters")]
        public string ProductName { get; set; }

        [StringLength(1000, ErrorMessage = "Description cannot exceed 1000 characters")]
        public string Description { get; set; }

        [Required(ErrorMessage = "Price is required")]
        [Range(0.01, 100000, ErrorMessage = "Price must be greater than 0")]
        public decimal Price { get; set; }

        [Required(ErrorMessage = "Stock quantity is required")]
        [Range(0, int.MaxValue, ErrorMessage = "Stock cannot be negative")]
        public int StockQuantity { get; set; }

        [Required(ErrorMessage = "Units is required")]
        [StringLength(20, ErrorMessage = "Units cannot exceed 20 characters")]
        public string Units { get; set; }

        // Defaults to true (Active), per the same "default Active" rule as Categories.
        public bool IsActive { get; set; } = true;

        public HttpPostedFileBase ProductImage { get; set; }

        // Edit form only - shows the current image, and tells the Controller
        // what to keep if no new file is uploaded.
        public string ExistingImagePath { get; set; }
    }
}
