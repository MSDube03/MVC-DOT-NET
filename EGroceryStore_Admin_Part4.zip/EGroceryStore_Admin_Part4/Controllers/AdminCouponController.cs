using System;
using System.Linq;
using System.Web.Mvc;
using EGroceryStore.Helpers;
using EGroceryStore.Models;
using EGroceryStore.ViewModels;

namespace EGroceryStore.Controllers
{
    public class AdminCouponController : Controller
    {
        private EGroceryStoreDBEntities db = new EGroceryStoreDBEntities();
        private const int PageSize = 10;

        // GET: AdminCoupon/Index
        public ActionResult Index(string searchTerm, string statusFilter, string discountTypeFilter, string sortBy, int page = 1)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                TempData["ErrorMessage"] = "Your session has expired. Please login again.";
                return RedirectToAction("Login", "Account");
            }

            var query = db.Coupons.AsQueryable();

            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                query = query.Where(c => c.CouponCode.ToLower().Contains(searchTerm.ToLower()));
            }

            if (!string.IsNullOrEmpty(discountTypeFilter))
            {
                query = query.Where(c => c.DiscountType == discountTypeFilter);
            }

            if (statusFilter == "Active") query = query.Where(c => c.IsActive == true);
            else if (statusFilter == "Inactive") query = query.Where(c => c.IsActive != true);
            else if (statusFilter == "Expired") query = query.Where(c => c.ExpiryDate < DateTime.Now);

            var coupons = query.ToList();

            var rows = coupons.Select(c => new AdminCouponRowViewModel
            {
                CouponId = c.CouponId,
                CouponCode = c.CouponCode,
                DiscountType = c.DiscountType,
                DiscountValue = c.DiscountValue,
                ExpiryDate = c.ExpiryDate,
                IsActive = c.IsActive == true,
                IsExpired = c.ExpiryDate < DateTime.Now
            }).ToList();

            switch (sortBy)
            {
                case "ExpiryAsc": rows = rows.OrderBy(r => r.ExpiryDate).ToList(); break;
                case "ExpiryDesc": rows = rows.OrderByDescending(r => r.ExpiryDate).ToList(); break;
                case "ValueDesc": rows = rows.OrderByDescending(r => r.DiscountValue).ToList(); break;
                default: rows = rows.OrderBy(r => r.CouponCode).ToList(); break;
            }

            int totalPages = (int)Math.Ceiling((double)rows.Count / PageSize);
            if (page < 1) page = 1;
            var pagedRows = rows.Skip((page - 1) * PageSize).Take(PageSize).ToList();

            var model = new AdminCouponListViewModel
            {
                Coupons = pagedRows,
                SearchTerm = searchTerm,
                StatusFilter = statusFilter,
                DiscountTypeFilter = discountTypeFilter,
                SortBy = sortBy,
                CurrentPage = page,
                TotalPages = totalPages
            };

            return View(model);
        }

        // GET: AdminCoupon/Add
        public ActionResult Add()
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            return View(new CouponFormViewModel { IsActive = true, ExpiryDate = DateTime.Now.AddMonths(1) });
        }

        // POST: AdminCoupon/Add
        [HttpPost]
        public ActionResult Add(CouponFormViewModel model)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // Business rule: a brand new coupon's expiry must be in the future -
            // a coupon that's already expired the moment it's created makes no sense.
            if (model.ExpiryDate.Date < DateTime.Now.Date)
            {
                ModelState.AddModelError("ExpiryDate", "Expiry date must be in the future.");
                return View(model);
            }

            bool duplicateExists = db.Coupons.Any(c => c.CouponCode.ToLower() == model.CouponCode.ToLower());
            if (duplicateExists)
            {
                ModelState.AddModelError("CouponCode", "This coupon code already exists.");
                return View(model);
            }

            try
            {
                var newCoupon = new Coupon
                {
                    CouponCode = model.CouponCode.ToUpper(),
                    DiscountType = model.DiscountType,
                    DiscountValue = model.DiscountValue,
                    ExpiryDate = model.ExpiryDate,
                    IsActive = model.IsActive
                };

                db.Coupons.Add(newCoupon);
                db.SaveChanges();

                TempData["SuccessMessage"] = "Coupon created successfully.";
                return RedirectToAction("Index");
            }
            catch (Exception)
            {
                ModelState.AddModelError("", "Something went wrong while saving the coupon. Please try again.");
                return View(model);
            }
        }

        // GET: AdminCoupon/Edit/5
        public ActionResult Edit(int id)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            var coupon = db.Coupons.FirstOrDefault(c => c.CouponId == id);
            if (coupon == null)
            {
                TempData["ErrorMessage"] = "Coupon not found.";
                return RedirectToAction("Index");
            }

            var model = new CouponFormViewModel
            {
                CouponId = coupon.CouponId,
                CouponCode = coupon.CouponCode,
                DiscountType = coupon.DiscountType,
                DiscountValue = coupon.DiscountValue,
                ExpiryDate = coupon.ExpiryDate.GetValueOrDefault(),
                IsActive = coupon.IsActive == true
            };

            return View(model);
        }

        // POST: AdminCoupon/Edit/5
        [HttpPost]
        public ActionResult Edit(CouponFormViewModel model)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var coupon = db.Coupons.FirstOrDefault(c => c.CouponId == model.CouponId);
            if (coupon == null)
            {
                TempData["ErrorMessage"] = "Coupon not found.";
                return RedirectToAction("Index");
            }

            bool duplicateExists = db.Coupons.Any(c =>
                c.CouponCode.ToLower() == model.CouponCode.ToLower() && c.CouponId != model.CouponId);
            if (duplicateExists)
            {
                ModelState.AddModelError("CouponCode", "This coupon code already exists.");
                return View(model);
            }

            // Note: unlike Add, we do NOT force ExpiryDate to be in the future
            // here - an Admin might legitimately want to edit an already-expired
            // coupon's other details (e.g. fix a typo in the code) without being
            // forced to also extend its expiry.
            coupon.CouponCode = model.CouponCode.ToUpper();
            coupon.DiscountType = model.DiscountType;
            coupon.DiscountValue = model.DiscountValue;
            coupon.ExpiryDate = model.ExpiryDate;
            coupon.IsActive = model.IsActive;

            db.SaveChanges();

            TempData["SuccessMessage"] = "Coupon updated successfully.";
            return RedirectToAction("Index");
        }

        // POST: AdminCoupon/Delete
        // No "is this coupon in use" check here, unlike Category/Product -
        // see README for why: the Orders table has no CouponId column, so
        // there's no historical record linking a placed Order back to a
        // specific Coupon that could be broken by deleting it.
        [HttpPost]
        public ActionResult Delete(int id)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            var coupon = db.Coupons.FirstOrDefault(c => c.CouponId == id);
            if (coupon == null)
            {
                TempData["ErrorMessage"] = "Coupon not found.";
                return RedirectToAction("Index");
            }

            db.Coupons.Remove(coupon);
            db.SaveChanges();

            TempData["SuccessMessage"] = "Coupon deleted successfully.";
            return RedirectToAction("Index");
        }

        // POST: AdminCoupon/ToggleStatus
        [HttpPost]
        public ActionResult ToggleStatus(int id)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            var coupon = db.Coupons.FirstOrDefault(c => c.CouponId == id);
            if (coupon == null)
            {
                TempData["ErrorMessage"] = "Coupon not found.";
                return RedirectToAction("Index");
            }

            coupon.IsActive = !(coupon.IsActive == true);
            db.SaveChanges();

            TempData["SuccessMessage"] = (coupon.IsActive == true)
                ? "Coupon activated."
                : "Coupon deactivated. Customers can no longer apply it.";

            return RedirectToAction("Index");
        }
    }
}
