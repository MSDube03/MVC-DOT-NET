using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using EGroceryStore.Helpers;
using EGroceryStore.Models;
using EGroceryStore.ViewModels;

namespace EGroceryStore.Controllers
{
    public class AdminCustomerController : Controller
    {
        private EGroceryStoreDBEntities db = new EGroceryStoreDBEntities();
        private const int PageSize = 10;

        // GET: AdminCustomer/Index
        public ActionResult Index(string searchTerm, string statusFilter, string sortBy, int page = 1)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                TempData["ErrorMessage"] = "Your session has expired. Please login again.";
                return RedirectToAction("Login", "Account");
            }

            // Only ever show Customer accounts here - this page is not for
            // managing other Admin accounts.
            var query = db.Users.Where(u => u.Role == "Customer").AsQueryable();

            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                string term = searchTerm.ToLower();
                query = query.Where(u =>
                    u.FirstName.ToLower().Contains(term) ||
                    u.LastName.ToLower().Contains(term) ||
                    u.Email.ToLower().Contains(term) ||
                    u.MobileNumber.Contains(term));
            }

            if (statusFilter == "Active") query = query.Where(u => u.IsActive == true);
            else if (statusFilter == "Inactive") query = query.Where(u => u.IsActive != true);

            var customers = query.ToList();

            // Build each row with live Order stats - these aren't stored
            // columns on Users, they come from that customer's rows in Orders.
            var rows = new List<AdminCustomerRowViewModel>();
            foreach (var u in customers)
            {
                var orders = db.Orders.Where(o => o.UserId == u.UserId).ToList();

                rows.Add(new AdminCustomerRowViewModel
                {
                    UserId = u.UserId,
                    FullName = u.FirstName + " " + u.LastName,
                    Email = u.Email,
                    MobileNumber = u.MobileNumber,
                    Role = u.Role,
                    RegisteredDate = u.CreatedDate,
                    IsActive = u.IsActive == true,
                    TotalOrders = orders.Count,
                    TotalPurchaseAmount = orders.Sum(o => o.TotalAmount)
                });
            }

            switch (sortBy)
            {
                case "NameDesc": rows = rows.OrderByDescending(r => r.FullName).ToList(); break;
                case "Newest": rows = rows.OrderByDescending(r => r.RegisteredDate).ToList(); break;
                case "MostOrders": rows = rows.OrderByDescending(r => r.TotalOrders).ToList(); break;
                case "HighestSpend": rows = rows.OrderByDescending(r => r.TotalPurchaseAmount).ToList(); break;
                default: rows = rows.OrderBy(r => r.FullName).ToList(); break;
            }

            int totalPages = (int)Math.Ceiling((double)rows.Count / PageSize);
            if (page < 1) page = 1;
            var pagedRows = rows.Skip((page - 1) * PageSize).Take(PageSize).ToList();

            var model = new AdminCustomerListViewModel
            {
                Customers = pagedRows,
                SearchTerm = searchTerm,
                StatusFilter = statusFilter,
                SortBy = sortBy,
                CurrentPage = page,
                TotalPages = totalPages
            };

            return View(model);
        }

        // GET: AdminCustomer/Details/5
        public ActionResult Details(int id)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            var user = db.Users.FirstOrDefault(u => u.UserId == id && u.Role == "Customer");
            if (user == null)
            {
                TempData["ErrorMessage"] = "Customer not found.";
                return RedirectToAction("Index");
            }

            var addresses = db.Adresses.Where(a => a.UserId == id).ToList();

            var orders = db.Orders.Where(o => o.UserId == id).OrderByDescending(o => o.OrderDate).ToList();
            var orderRows = orders.Select(o => new AdminOrderSummaryViewModel
            {
                OrderId = o.OrderId,
                OrderNumber = o.OrderNumber,
                OrderDate = o.OrderDate,
                TotalAmount = o.TotalAmount,
                OrderStatus = o.OrderStatus
            }).ToList();

            int wishlistCount = db.Wishlists.Count(w => w.UserId == id);

            var model = new CustomerDetailsViewModel
            {
                UserId = user.UserId,
                FullName = user.FirstName + " " + user.LastName,
                Email = user.Email,
                MobileNumber = user.MobileNumber,
                RegisteredDate = user.CreatedDate,
                IsActive = user.IsActive == true,
                Addresses = addresses,
                Orders = orderRows,
                WishlistCount = wishlistCount,
                TotalOrders = orders.Count,
                TotalPurchaseAmount = orders.Sum(o => o.TotalAmount)
            };

            return View(model);
        }

        // POST: AdminCustomer/ToggleStatus
        // Deactivating here means the customer can no longer log in - see the
        // required AccountController.cs change in ExistingFileChanges for why.
        [HttpPost]
        public ActionResult ToggleStatus(int id)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            var user = db.Users.FirstOrDefault(u => u.UserId == id && u.Role == "Customer");
            if (user == null)
            {
                TempData["ErrorMessage"] = "Customer not found.";
                return RedirectToAction("Index");
            }

            user.IsActive = !(user.IsActive == true);
            db.SaveChanges();

            TempData["SuccessMessage"] = (user.IsActive == true)
                ? "Customer account activated. They can log in again."
                : "Customer account deactivated. They will not be able to log in.";

            return RedirectToAction("Index");
        }
    }
}
