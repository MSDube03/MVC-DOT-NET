using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using EGroceryStore.Helpers;
using EGroceryStore.Models;
using EGroceryStore.ViewModels;

namespace EGroceryStore.Controllers
{
    public class AdminOrderController : Controller
    {
        private EGroceryStoreDBEntities db = new EGroceryStoreDBEntities();
        private const int PageSize = 10;

        // The order lifecycle, in strict forward sequence. Used to validate
        // status changes - see IsValidTransition() below.
        private static readonly List<string> StatusSequence =
            new List<string> { "Pending", "Confirmed", "Packed", "Shipped", "Delivered" };

        // GET: AdminOrder/Index
        public ActionResult Index(string searchTerm, string orderStatus, string paymentStatus,
            DateTime? startDate, DateTime? endDate, string sortBy, int page = 1)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                TempData["ErrorMessage"] = "Your session has expired. Please login again.";
                return RedirectToAction("Login", "Account");
            }

            var query = db.Orders.AsQueryable();

            // Search by Order Number, or by the Customer's name/email - needs
            // a lookup into Users first, since Orders itself has no name/email column.
            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                string term = searchTerm.ToLower();
                var matchingUserIds = db.Users
                    .Where(u => (u.FirstName + " " + u.LastName).ToLower().Contains(term) || u.Email.ToLower().Contains(term))
                    .Select(u => u.UserId)
                    .ToList();

                query = query.Where(o => o.OrderNumber.ToLower().Contains(term) || matchingUserIds.Contains(o.UserId));
            }

            if (!string.IsNullOrEmpty(orderStatus)) query = query.Where(o => o.OrderStatus == orderStatus);
            if (!string.IsNullOrEmpty(paymentStatus)) query = query.Where(o => o.PaymentStatus == paymentStatus);
            if (startDate.HasValue) query = query.Where(o => o.OrderDate >= startDate.Value);
            if (endDate.HasValue) query = query.Where(o => o.OrderDate <= endDate.Value.AddDays(1));

            switch (sortBy)
            {
                case "AmountDesc": query = query.OrderByDescending(o => o.TotalAmount); break;
                case "AmountAsc": query = query.OrderBy(o => o.TotalAmount); break;
                case "Oldest": query = query.OrderBy(o => o.OrderDate); break;
                default: query = query.OrderByDescending(o => o.OrderDate); break;
            }

            var allOrders = query.ToList();
            int totalPages = (int)Math.Ceiling((double)allOrders.Count / PageSize);
            if (page < 1) page = 1;
            var pagedOrders = allOrders.Skip((page - 1) * PageSize).Take(PageSize).ToList();

            var rows = new List<AdminOrderRowViewModel>();
            foreach (var order in pagedOrders)
            {
                var customer = db.Users.FirstOrDefault(u => u.UserId == order.UserId);
                rows.Add(new AdminOrderRowViewModel
                {
                    OrderId = order.OrderId,
                    OrderNumber = order.OrderNumber,
                    CustomerName = customer != null ? customer.FirstName + " " + customer.LastName : "Unknown",
                    OrderDate = order.OrderDate,
                    TotalAmount = order.TotalAmount,
                    PaymentMethod = order.PaymentMethod,
                    PaymentStatus = order.PaymentStatus,
                    OrderStatus = order.OrderStatus
                });
            }

            var model = new AdminOrderListViewModel
            {
                Orders = rows,
                SearchTerm = searchTerm,
                OrderStatus = orderStatus,
                PaymentStatus = paymentStatus,
                StartDate = startDate,
                EndDate = endDate,
                SortBy = sortBy,
                CurrentPage = page,
                TotalPages = totalPages
            };

            return View(model);
        }

        // GET: AdminOrder/Details/5
        public ActionResult Details(int id)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            var order = db.Orders.FirstOrDefault(o => o.OrderId == id);
            if (order == null)
            {
                TempData["ErrorMessage"] = "Order not found.";
                return RedirectToAction("Index");
            }

            var customer = db.Users.FirstOrDefault(u => u.UserId == order.UserId);
            var lines = db.OrderDetails.Where(od => od.OrderId == id).ToList();

            var lineViewModels = new List<AdminOrderLineViewModel>();
            foreach (var line in lines)
            {
                var product = db.Products.FirstOrDefault(p => p.ProductId == line.ProductId);
                lineViewModels.Add(new AdminOrderLineViewModel
                {
                    ProductName = product != null ? product.ProductName : "Product",
                    Quantity = line.Quantity,
                    Price = line.Price,
                    SubTotal = line.SubTotal
                });
            }

            var model = new AdminOrderDetailsViewModel
            {
                OrderId = order.OrderId,
                OrderNumber = order.OrderNumber,
                CustomerName = customer != null ? customer.FirstName + " " + customer.LastName : "Unknown",
                CustomerEmail = customer != null ? customer.Email : "",
                OrderDate = order.OrderDate,
                DeliveryAdress = order.DeliveryAdress,
                PaymentMethod = order.PaymentMethod,
                PaymentStatus = order.PaymentStatus,
                OrderStatus = order.OrderStatus,
                TotalAmount = order.TotalAmount,
                Lines = lineViewModels
            };

            return View(model);
        }

        // Checks whether moving from one Order Status to another is allowed.
        // Business rules (from the spec):
        //   - Delivered and Cancelled are terminal - no further changes allowed.
        //   - Cancelled is only allowed if the order hasn't been Shipped yet.
        //   - Otherwise, only FORWARD movement through the sequence is allowed
        //     (an Admin correcting/catching up statuses can skip ahead, e.g.
        //     Pending straight to Packed if that's genuinely what happened -
        //     but can never move backward).
        private bool IsValidTransition(string currentStatus, string newStatus)
        {
            if (currentStatus == newStatus) return true; // no actual change

            if (currentStatus == "Delivered" || currentStatus == "Cancelled")
            {
                return false;
            }

            if (newStatus == "Cancelled")
            {
                int currentIndex = StatusSequence.IndexOf(currentStatus);
                int shippedIndex = StatusSequence.IndexOf("Shipped");
                return currentIndex >= 0 && currentIndex < shippedIndex;
            }

            int fromIndex = StatusSequence.IndexOf(currentStatus);
            int toIndex = StatusSequence.IndexOf(newStatus);
            return fromIndex >= 0 && toIndex >= 0 && toIndex > fromIndex;
        }

        // POST: AdminOrder/UpdateStatus
        [HttpPost]
        public ActionResult UpdateStatus(int id, string newOrderStatus, string newPaymentStatus)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            var order = db.Orders.FirstOrDefault(o => o.OrderId == id);
            if (order == null)
            {
                TempData["ErrorMessage"] = "Order not found.";
                return RedirectToAction("Index");
            }

            if (!string.IsNullOrEmpty(newOrderStatus) && newOrderStatus != order.OrderStatus)
            {
                if (!IsValidTransition(order.OrderStatus, newOrderStatus))
                {
                    TempData["ErrorMessage"] = "Invalid status change: cannot move from '" + order.OrderStatus + "' to '" + newOrderStatus + "'.";
                    return RedirectToAction("Details", new { id = id });
                }

                // If the order is being Cancelled, restore stock for every
                // product in it - the units reserved for this order are now
                // available again for other customers to buy.
                if (newOrderStatus == "Cancelled")
                {
                    var orderDetails = db.OrderDetails.Where(od => od.OrderId == id).ToList();
                    foreach (var line in orderDetails)
                    {
                        var product = db.Products.FirstOrDefault(p => p.ProductId == line.ProductId);
                        if (product != null)
                        {
                            product.StockQuantity += line.Quantity;
                        }
                    }
                }

                order.OrderStatus = newOrderStatus;
            }

            if (!string.IsNullOrEmpty(newPaymentStatus))
            {
                order.PaymentStatus = newPaymentStatus;
            }

            db.SaveChanges();

            TempData["SuccessMessage"] = "Order updated successfully.";
            return RedirectToAction("Details", new { id = id });
        }
    }
}
