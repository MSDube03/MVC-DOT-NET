# E-Grocery Store — Admin Module, Part 4: Customer + Order + Coupon Management

Three modules in one Part, because they're genuinely interlinked: customers
place orders, orders generate revenue, coupons drive more of both. Full
CRUD for Coupons, full status-lifecycle management for Orders, and
monitoring (search/filter/sort/activate/deactivate) for Customers.

---

## 0. Exact order of steps

1. Confirm Parts 1-3 all still work before starting.
2. Copy in: `ViewModels/` (6 new files), `Controllers/` (3 new controllers),
   `Views/AdminCustomer/`, `Views/AdminOrder/`, `Views/AdminCoupon/` (7 views total).
3. Update `Views/Shared/_AdminSidebar.cshtml` — wire 3 links.
   See `ExistingFileChanges/_AdminSidebar.cshtml.CHANGES.txt`.
4. Update `Views/AdminDashboard/Index.cshtml` — wire 2 more Quick Action buttons.
   See `ExistingFileChanges/AdminDashboardIndex.cshtml.CHANGES.txt`.
5. **Two important Customer Module changes:**
   - `Controllers/AccountController.cs` — makes Deactivate Customer actually
     block login. See `ExistingFileChanges/AccountController.cs.CHANGES.txt`.
   - `Controllers/OrderController.cs` — aligns new orders' starting status
     with this Part's lifecycle. See `ExistingFileChanges/OrderController.cs.CHANGES.txt`.
6. **No new CSS files this round** — every view reuses classes already
   defined in `Admin.css`/`Category.css` (`adm-section-card`, `adm-cat-table`,
   `adm-action-buttons`, `adm-form-card`, `adm-summary-card`, etc.), plus
   Bootstrap's built-in `.well` class for address cards. Nothing new to link.
7. Build, fix anything red, run, test.

**One data note before testing Order Management:** if you already placed
test orders through the Customer site before this Part, they'll have
`OrderStatus = 'Placed'` (the old value) rather than `'Pending'`. The new
Admin status-update logic won't recognize `'Placed'` as a valid starting
point in the lifecycle, so those specific old test orders won't be movable
through the Admin UI. This is a one-time SQL fix if you want to clean it up:
```sql
UPDATE Orders SET OrderStatus = 'Pending' WHERE OrderStatus = 'Placed';
```
Run this once in SSMS if needed — brand new orders placed after this Part
will already say `'Pending'` correctly, no fix needed for those.

---

## 1. What's in this folder

```
EGroceryStore_Admin_Part4/
├── ViewModels/
│   ├── AdminCustomerListViewModel.cs   also contains AdminCustomerRowViewModel
│   ├── CustomerDetailsViewModel.cs     also contains AdminOrderSummaryViewModel
│   ├── AdminOrderListViewModel.cs      also contains AdminOrderRowViewModel
│   ├── AdminOrderDetailsViewModel.cs   also contains AdminOrderLineViewModel
│   ├── CouponFormViewModel.cs
│   └── AdminCouponListViewModel.cs     also contains AdminCouponRowViewModel
├── Controllers/
│   ├── AdminCustomerController.cs
│   ├── AdminOrderController.cs
│   └── AdminCouponController.cs
├── Views/
│   ├── AdminCustomer/Index.cshtml, Details.cshtml
│   ├── AdminOrder/Index.cshtml, Details.cshtml
│   └── AdminCoupon/Index.cshtml, Add.cshtml, Edit.cshtml
├── ExistingFileChanges/
│   ├── _AdminSidebar.cshtml.CHANGES.txt
│   ├── AdminDashboardIndex.cshtml.CHANGES.txt
│   ├── AccountController.cs.CHANGES.txt      (Customer Module)
│   └── OrderController.cs.CHANGES.txt        (Customer Module)
└── README.md
```

## 2. Design decisions explained

**Why Customer Management can only Activate/Deactivate, never Delete:**
The spec is explicit about this, and it matters — a customer's account is
tied to real Orders (financial records) and Addresses. Deleting a customer
would either break that history or require deleting their orders too, which
you never want. Deactivate blocks login while keeping every record intact.

**Why the Admin can never see or touch a customer's password or security
answer:** both are stored as one-way hashes (Stage 1) — there's no "real"
password to show even if we wanted to. Letting an Admin *set* a new
password directly (bypassing the hash-and-verify flow) would also be a
security hole — it's not something this trainee-level project implements,
matching the spec's explicit restriction.

**Why Order Status transitions are validated in code (`IsValidTransition`),
not just left as a free dropdown:** without this, an Admin could
accidentally mark a `Cancelled` order as `Delivered`, or move a `Delivered`
order back to `Pending` — both would corrupt real business data (e.g. stock
would already have been sold and shipped, but the system would think it's
still awaiting confirmation). The code allows moving *forward* through the
sequence (including skipping stages, for an Admin catching up on a delayed
status update), blocks any backward movement, and treats `Delivered` and
`Cancelled` as permanently locked once reached.

**Why cancelling an order restores stock automatically:** if a customer's
order is cancelled, the units that were reserved for them are no longer
being sold — they should become available for other customers again. This
happens inside `AdminOrderController.UpdateStatus`, looping through that
order's `OrderDetails` and adding each quantity back to `Products.StockQuantity`.

**Why Coupon Delete has no "is this coupon in use" safety check, unlike
Category/Product Delete:** look at your `Orders` table schema — there's no
`CouponId` column. This was a known simplification from Stage 2 (the
discount was calculated and applied at checkout, but never permanently
linked back to a specific Order record). Since there's no historical
relationship in the database to protect, there's nothing to check before
deleting a Coupon.

**Why Coupon Edit doesn't force the Expiry Date to be in the future (but
Add does):** an Admin might want to fix a typo in an already-expired
coupon's code or discount value without being forced to also extend its
expiry just to save the edit. The "must be in the future" rule only makes
sense for a coupon being newly created.

## 3. Testing checklist

1. **Customer search** — by first name, last name, email, and mobile number,
   case-insensitive.
2. **Customer filter** — Active/Inactive, confirms correctly.
3. **Deactivate a test customer**, then try logging in as that customer on
   the Customer site → should be blocked with "Your account has been
   deactivated."
4. **Reactivate** that same customer → login works again.
5. **Customer Details page** — confirm Total Orders, Total Purchase Amount,
   Wishlist count, addresses, and order history all show real numbers
   matching that customer's actual data.
6. **Order search** — by order number, by customer name, by email.
7. **Order filters** — status, payment status, date range, individually and combined.
8. **Order status update — valid path**: Pending → Confirmed → Packed →
   Shipped → Delivered, one step at a time, confirm each succeeds.
9. **Order status update — invalid paths**: try Delivered → Pending (should
   be blocked), try Cancelled on a Shipped order (should be blocked), try
   Delivered → Cancelled (should be blocked).
10. **Cancel a Pending or Confirmed order** → check the Products table
    afterward — StockQuantity for each item in that order should have
    increased by the cancelled quantity.
11. **Add a Coupon** with a past expiry date → blocked with the right message.
12. **Add a Coupon** with a duplicate code → blocked.
13. **Edit a Coupon**, change only the discount value → confirm no forced
    expiry-date validation blocks the save.
14. **Deactivate a Coupon**, then try applying it at Customer checkout →
    should be rejected (this uses logic already built in Stage 2's
    `OrderController.ApplyCoupon`, unchanged — just confirming the two
    modules agree with each other).
15. **Delete a Coupon** with no usage history → succeeds immediately, no
    blocking check (as explained above).
16. Pagination and sorting on all three list pages.

## 4. Common errors

| Error | Cause | Fix |
|---|---|---|
| `CS0266: Cannot implicitly convert bool? to bool` anywhere in these 3 controllers | A nullable column assignment was missed somewhere | Every direct `IsActive = x.IsActive` assignment and every `x.IsActive ? ... : ...` ternary in this package was already written with the safe `== true` pattern — if you hit this, check whether you're looking at a genuinely new line, not one of these three files |
| Old test orders won't accept a status update | They still say `OrderStatus = 'Placed'` from before this Part | Run the one-time SQL fix shown in Section 0 above |
| Customer's "Total Orders" shows 0 even though they've ordered before | Check that `Orders.UserId` for that order actually matches the customer's `UserId` — a mismatch here usually points to a test data issue, not a code bug | Verify in SSMS: `SELECT UserId FROM Orders WHERE OrderId = X` |
| Deactivating a customer doesn't block their login | The `AccountController.cs` change wasn't applied | Go back and apply `ExistingFileChanges/AccountController.cs.CHANGES.txt` |

---

**Next (Part 5):** Reports + Profile + Project Structure + Integration.
Say the word when you're ready.
