using System;
using System.Collections.Generic;

namespace EGroceryStore.ViewModels
{
    public class AdminCouponRowViewModel
    {
        public int CouponId { get; set; }
        public string CouponCode { get; set; }
        public string DiscountType { get; set; }
        public decimal DiscountValue { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public bool IsActive { get; set; }
        public bool IsExpired { get; set; }
    }

    public class AdminCouponListViewModel
    {
        public List<AdminCouponRowViewModel> Coupons { get; set; }
        public string SearchTerm { get; set; }
        public string StatusFilter { get; set; }        // "", "Active", "Inactive", "Expired"
        public string DiscountTypeFilter { get; set; }
        public string SortBy { get; set; }
        public int CurrentPage { get; set; }
        public int TotalPages { get; set; }
    }
}
