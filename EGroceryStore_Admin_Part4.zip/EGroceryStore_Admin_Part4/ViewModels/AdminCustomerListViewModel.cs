using System;
using System.Collections.Generic;

namespace EGroceryStore.ViewModels
{
    // One row in the Manage Customers table. TotalOrders and
    // TotalPurchaseAmount aren't columns on Users - they come from
    // counting/summing that customer's rows in Orders.
    public class AdminCustomerRowViewModel
    {
        public int UserId { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public string MobileNumber { get; set; }
        public string Role { get; set; }
        public DateTime? RegisteredDate { get; set; }
        public bool IsActive { get; set; }
        public int TotalOrders { get; set; }
        public decimal TotalPurchaseAmount { get; set; }
    }

    public class AdminCustomerListViewModel
    {
        public List<AdminCustomerRowViewModel> Customers { get; set; }
        public string SearchTerm { get; set; }
        public string StatusFilter { get; set; }
        public string SortBy { get; set; }
        public int CurrentPage { get; set; }
        public int TotalPages { get; set; }
    }
}
