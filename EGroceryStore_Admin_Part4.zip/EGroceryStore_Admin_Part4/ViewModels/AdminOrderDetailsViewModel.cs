using System;
using System.Collections.Generic;

namespace EGroceryStore.ViewModels
{
    // One product line inside the Order Details page.
    public class AdminOrderLineViewModel
    {
        public string ProductName { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
        public decimal SubTotal { get; set; }
    }

    public class AdminOrderDetailsViewModel
    {
        public int OrderId { get; set; }
        public string OrderNumber { get; set; }
        public string CustomerName { get; set; }
        public string CustomerEmail { get; set; }
        public DateTime? OrderDate { get; set; }
        public string DeliveryAdress { get; set; }
        public string PaymentMethod { get; set; }
        public string PaymentStatus { get; set; }
        public string OrderStatus { get; set; }
        public decimal TotalAmount { get; set; }
        public List<AdminOrderLineViewModel> Lines { get; set; }
    }
}
