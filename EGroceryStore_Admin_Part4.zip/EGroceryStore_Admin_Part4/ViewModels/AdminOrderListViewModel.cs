using System;
using System.Collections.Generic;

namespace EGroceryStore.ViewModels
{
    // One row in the Manage Orders table. CustomerName isn't a column on
    // Orders - it comes from a join with Users.
    public class AdminOrderRowViewModel
    {
        public int OrderId { get; set; }
        public string OrderNumber { get; set; }
        public string CustomerName { get; set; }
        public DateTime? OrderDate { get; set; }
        public decimal TotalAmount { get; set; }
        public string PaymentMethod { get; set; }
        public string PaymentStatus { get; set; }
        public string OrderStatus { get; set; }
    }

    public class AdminOrderListViewModel
    {
        public List<AdminOrderRowViewModel> Orders { get; set; }
        public string SearchTerm { get; set; }
        public string OrderStatus { get; set; }
        public string PaymentStatus { get; set; }
        public string PaymentMethod { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string SortBy { get; set; }
        public int CurrentPage { get; set; }
        public int TotalPages { get; set; }
    }
}
