using System;
using System.ComponentModel.DataAnnotations;

namespace EGroceryStore.ViewModels
{
    // Used by both Add Coupon and Edit Coupon forms.
    public class CouponFormViewModel
    {
        public int CouponId { get; set; }

        [Required(ErrorMessage = "Coupon code is required")]
        [StringLength(30, ErrorMessage = "Coupon code cannot exceed 30 characters")]
        public string CouponCode { get; set; }

        [Required(ErrorMessage = "Please select a discount type")]
        public string DiscountType { get; set; } // "Percentage" or "Flat"

        [Required(ErrorMessage = "Discount value is required")]
        [Range(0.01, 100000, ErrorMessage = "Discount value must be greater than 0")]
        public decimal DiscountValue { get; set; }

        [Required(ErrorMessage = "Expiry date is required")]
        [DataType(DataType.Date)]
        public DateTime ExpiryDate { get; set; }

        public bool IsActive { get; set; } = true;
    }
}
