using System;
using System.Collections.Generic;
using EGroceryStore.Models;

namespace EGroceryStore.ViewModels
{
    // One row inside a Customer's order history list on their Details page.
    // Deliberately separate from the Customer-facing order ViewModels and
    // from AdminOrderRowViewModel (Order Management's own list) - different
    // pages, different purposes, kept distinct so a future change to one
    // never accidentally breaks the other.
    public class AdminOrderSummaryViewModel
    {
        public int OrderId { get; set; }
        public string OrderNumber { get; set; }
        public DateTime? OrderDate { get; set; }
        public decimal TotalAmount { get; set; }
        public string OrderStatus { get; set; }
    }

    public class CustomerDetailsViewModel
    {
        public int UserId { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public string MobileNumber { get; set; }
        public DateTime? RegisteredDate { get; set; }
        public bool IsActive { get; set; }

        // Addresses uses the real EF entity directly (List<Adress>) rather than
        // a separate ViewModel - this page only ever displays them, never
        // edits them, so there's no form/validation reason to wrap them.
        public List<Adress> Addresses { get; set; }

        public List<AdminOrderSummaryViewModel> Orders { get; set; }
        public int WishlistCount { get; set; }
        public int TotalOrders { get; set; }
        public decimal TotalPurchaseAmount { get; set; }
    }
}
