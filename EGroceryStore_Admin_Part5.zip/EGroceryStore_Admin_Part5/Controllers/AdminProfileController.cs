using System.Linq;
using System.Web.Mvc;
using EGroceryStore.Helpers;
using EGroceryStore.Models;
using EGroceryStore.ViewModels;

namespace EGroceryStore.Controllers
{
    // NOTE: This Controller deliberately reuses EditProfileViewModel and
    // ChangePasswordViewModel from the Customer Module (Stage 2) instead of
    // creating new, duplicate ViewModels - both forms need exactly the same
    // shape (FirstName/LastName/MobileNumber, and CurrentPassword/NewPassword/
    // ConfirmPassword). Same reusable-code idea this Part's spec asks for.
    public class AdminProfileController : Controller
    {
        private EGroceryStoreDBEntities db = new EGroceryStoreDBEntities();

        // GET: AdminProfile/Index
        public ActionResult Index()
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            int adminId = SessionHelper.GetCurrentUserId(Session);
            var admin = db.Users.FirstOrDefault(u => u.UserId == adminId && u.Role == "Admin");
            if (admin == null)
            {
                return RedirectToAction("Login", "Account");
            }

            return View(admin);
        }

        // GET: AdminProfile/Edit
        public ActionResult Edit()
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            int adminId = SessionHelper.GetCurrentUserId(Session);
            var admin = db.Users.FirstOrDefault(u => u.UserId == adminId && u.Role == "Admin");
            if (admin == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var model = new EditProfileViewModel
            {
                FirstName = admin.FirstName,
                LastName = admin.LastName,
                MobileNumber = admin.MobileNumber
            };

            return View(model);
        }

        // POST: AdminProfile/Edit
        [HttpPost]
        public ActionResult Edit(EditProfileViewModel model)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            int adminId = SessionHelper.GetCurrentUserId(Session);
            var admin = db.Users.FirstOrDefault(u => u.UserId == adminId && u.Role == "Admin");
            if (admin == null)
            {
                return RedirectToAction("Login", "Account");
            }

            // Email is intentionally never touched here - Admin cannot change it,
            // same rule as Customer Profile.
            admin.FirstName = model.FirstName;
            admin.LastName = model.LastName;
            admin.MobileNumber = model.MobileNumber;

            db.SaveChanges();

            // Keep the navbar's displayed name in sync with the new name.
            Session["UserName"] = admin.FirstName + " " + admin.LastName;

            TempData["SuccessMessage"] = "Profile updated successfully.";
            return RedirectToAction("Index");
        }

        // GET: AdminProfile/ChangePassword
        public ActionResult ChangePassword()
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }
            return View();
        }

        // POST: AdminProfile/ChangePassword
        // Flow: verify the current password's hash matches -> hash the new
        // password -> save. The old password is never stored or displayed
        // anywhere, and is never compared as plain text.
        [HttpPost]
        public ActionResult ChangePassword(ChangePasswordViewModel model)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            int adminId = SessionHelper.GetCurrentUserId(Session);
            var admin = db.Users.FirstOrDefault(u => u.UserId == adminId && u.Role == "Admin");
            if (admin == null)
            {
                return RedirectToAction("Login", "Account");
            }

            if (!PasswordHasher.VerifyText(model.CurrentPassword, admin.PasswordHash))
            {
                ModelState.AddModelError("CurrentPassword", "Current password is incorrect.");
                return View(model);
            }

            admin.PasswordHash = PasswordHasher.HashText(model.NewPassword);
            db.SaveChanges();

            TempData["SuccessMessage"] = "Password changed successfully. Please login again.";
            Session.Abandon();
            return RedirectToAction("Login", "Account");
        }
    }
}
