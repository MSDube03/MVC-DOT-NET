using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using EGroceryStore.Helpers;
using EGroceryStore.Models;
using EGroceryStore.ViewModels;

namespace EGroceryStore.Controllers
{
    public class AdminReportController : Controller
    {
        private EGroceryStoreDBEntities db = new EGroceryStoreDBEntities();

        // How many units of stock counts as "Low Stock" - same threshold used
        // on the Dashboard and Product Management, kept consistent here too.
        private const int LowStockThreshold = 10;

        // GET: AdminReport/Index
        // One page holding every report - Sales, Product, Category, Customer,
        // and Order. Every number is calculated live from the database here;
        // nothing on this page is ever hardcoded.
        public ActionResult Index()
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                TempData["ErrorMessage"] = "Your session has expired. Please login again.";
                return RedirectToAction("Login", "Account");
            }

            var model = new AdminReportViewModel();
            var allOrders = db.Orders.ToList();
            DateTime today = DateTime.Now.Date;

            // ===================== SALES REPORT =====================
            // Sum() with (decimal?) + ?? 0 avoids a crash if there are zero
            // orders at all - a genuinely possible state for a fresh project.
            model.TotalRevenue = allOrders.Sum(o => (decimal?)o.TotalAmount) ?? 0;
            model.TotalOrdersCount = allOrders.Count;
            model.AverageOrderValue = allOrders.Count > 0 ? model.TotalRevenue / allOrders.Count : 0;

            model.TodayRevenue = allOrders
                .Where(o => o.OrderDate.HasValue && o.OrderDate.Value.Date == today)
                .Sum(o => (decimal?)o.TotalAmount) ?? 0;

            model.MonthlyRevenue = allOrders
                .Where(o => o.OrderDate.HasValue && o.OrderDate.Value.Month == today.Month && o.OrderDate.Value.Year == today.Year)
                .Sum(o => (decimal?)o.TotalAmount) ?? 0;

            model.YearlyRevenue = allOrders
                .Where(o => o.OrderDate.HasValue && o.OrderDate.Value.Year == today.Year)
                .Sum(o => (decimal?)o.TotalAmount) ?? 0;

            // ===================== PRODUCT REPORT =====================
            // Step 1: total units sold per product, grouped from OrderDetails.
            var salesByProduct = db.OrderDetails
                .GroupBy(od => od.ProductId)
                .Select(g => new { ProductId = g.Key, TotalSold = g.Sum(x => x.Quantity) })
                .ToList();

            var allProducts = db.Products.ToList();

            model.TopSellingProducts = salesByProduct
                .OrderByDescending(s => s.TotalSold)
                .Take(5)
                .Select(s =>
                {
                    var product = allProducts.FirstOrDefault(p => p.ProductId == s.ProductId);
                    return new ReportProductRowViewModel
                    {
                        ProductName = product != null ? product.ProductName : "Unknown",
                        UnitsSold = s.TotalSold
                    };
                })
                .ToList();

            model.LowestSellingProducts = salesByProduct
                .OrderBy(s => s.TotalSold)
                .Take(5)
                .Select(s =>
                {
                    var product = allProducts.FirstOrDefault(p => p.ProductId == s.ProductId);
                    return new ReportProductRowViewModel
                    {
                        ProductName = product != null ? product.ProductName : "Unknown",
                        UnitsSold = s.TotalSold
                    };
                })
                .ToList();

            model.OutOfStockCount = allProducts.Count(p => p.StockQuantity == 0);
            model.LowStockCount = allProducts.Count(p => p.StockQuantity > 0 && p.StockQuantity <= LowStockThreshold);
            model.InactiveProductCount = allProducts.Count(p => p.IsActive != true);

            // ===================== CATEGORY REPORT =====================
            var categories = db.Categories.ToList();
            model.Categories = categories.Select(c => new ReportCategoryRowViewModel
            {
                CategoryName = c.CategoryName,
                TotalProducts = allProducts.Count(p => p.CategoryId == c.CategoryId),
                ProductsAvailable = allProducts.Count(p => p.CategoryId == c.CategoryId && p.StockQuantity > 0),
                ProductsOutOfStock = allProducts.Count(p => p.CategoryId == c.CategoryId && p.StockQuantity == 0)
            }).ToList();

            // ===================== CUSTOMER REPORT =====================
            var customers = db.Users.Where(u => u.Role == "Customer").ToList();
            model.TotalCustomers = customers.Count;
            model.ActiveCustomers = customers.Count(c => c.IsActive == true);
            model.InactiveCustomers = customers.Count(c => c.IsActive != true);

            model.LatestCustomers = customers
                .OrderByDescending(c => c.CreatedDate)
                .Take(5)
                .Select(c => new ReportCustomerRowViewModel
                {
                    FullName = c.FirstName + " " + c.LastName,
                    Email = c.Email,
                    RegisteredDate = c.CreatedDate,
                    TotalPurchase = allOrders.Where(o => o.UserId == c.UserId).Sum(o => (decimal?)o.TotalAmount) ?? 0
                })
                .ToList();

            model.TopCustomersByPurchase = customers
                .Select(c => new ReportCustomerRowViewModel
                {
                    FullName = c.FirstName + " " + c.LastName,
                    Email = c.Email,
                    RegisteredDate = c.CreatedDate,
                    TotalPurchase = allOrders.Where(o => o.UserId == c.UserId).Sum(o => (decimal?)o.TotalAmount) ?? 0
                })
                .OrderByDescending(c => c.TotalPurchase)
                .Take(5)
                .ToList();

            // ===================== ORDER REPORT =====================
            // "Placed" is included alongside "Pending" here for the same
            // backward-compatibility reason as the Dashboard - any orders
            // placed before Part 4's status-naming fix still count correctly.
            model.PendingCount = allOrders.Count(o => o.OrderStatus == "Pending" || o.OrderStatus == "Placed");
            model.ConfirmedCount = allOrders.Count(o => o.OrderStatus == "Confirmed");
            model.PackedCount = allOrders.Count(o => o.OrderStatus == "Packed");
            model.ShippedCount = allOrders.Count(o => o.OrderStatus == "Shipped");
            model.DeliveredCount = allOrders.Count(o => o.OrderStatus == "Delivered");
            model.CancelledCount = allOrders.Count(o => o.OrderStatus == "Cancelled");

            // Last 6 months, including months with zero orders - so the chart
            // never silently skips a quiet month.
            var monthCounts = new List<int>();
            for (int i = 5; i >= 0; i--)
            {
                DateTime monthDate = today.AddMonths(-i);
                int count = allOrders.Count(o => o.OrderDate.HasValue &&
                    o.OrderDate.Value.Month == monthDate.Month && o.OrderDate.Value.Year == monthDate.Year);
                monthCounts.Add(count);
            }
            int maxCount = monthCounts.Count > 0 ? monthCounts.Max() : 0;

            var monthlyData = new List<MonthlyOrderCountViewModel>();
            for (int i = 5; i >= 0; i--)
            {
                DateTime monthDate = today.AddMonths(-i);
                int count = monthCounts[5 - i];
                decimal barPercent = maxCount > 0 ? Math.Round((decimal)count / maxCount * 100, 1) : 0;

                monthlyData.Add(new MonthlyOrderCountViewModel
                {
                    MonthLabel = monthDate.ToString("MMM yyyy"),
                    OrderCount = count,
                    BarPercentage = barPercent
                });
            }
            model.MonthlyOrders = monthlyData;

            return View(model);
        }
    }
}
