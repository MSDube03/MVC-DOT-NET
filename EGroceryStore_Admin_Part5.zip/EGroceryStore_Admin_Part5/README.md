# E-Grocery Store — Admin Module, Part 5: Reports + Profile + Integration

Reports (Sales, Product, Category, Customer, Order), Admin's own Profile
management, and — since this Part is explicitly about tying the whole Admin
Panel together — a proper explanation of how every piece connects.

After this Part, **every single sidebar link and every Quick Action button
across the whole Admin Panel points to a real page.** Nothing left as `#`.

---

## 0. Exact order of steps

1. Confirm Parts 1-4 all still work before starting.
2. Copy in: `ViewModels/AdminReportViewModel.cs`, `Controllers/AdminReportController.cs`,
   `Controllers/AdminProfileController.cs`, `Views/AdminReport/`, `Views/AdminProfile/`,
   `Views/Shared/_AdminAlerts.cshtml`, `Content/CSS/Reports.css`.
3. Update `Views/Shared/_AdminSidebar.cshtml` — wire the last 2 links.
   See `ExistingFileChanges/_AdminSidebar.cshtml.CHANGES.txt`.
4. Update `Views/Shared/_AdminLayout.cshtml` — 3 changes (navbar link, alert
   partial, new CSS link). See `ExistingFileChanges/_AdminLayout.cshtml.CHANGES.txt`.
5. Update `Views/AdminDashboard/Index.cshtml` — last Quick Action button.
   See `ExistingFileChanges/AdminDashboardIndex.cshtml.CHANGES.txt`.
6. Build, fix anything red, run, test.

**No Customer Module changes this time** — this Part is entirely
self-contained within the Admin Panel.

---

## 1. What's in this folder

```
EGroceryStore_Admin_Part5/
├── ViewModels/
│   └── AdminReportViewModel.cs   also contains 4 small row/bar ViewModels
├── Controllers/
│   ├── AdminReportController.cs
│   └── AdminProfileController.cs  (reuses Customer Module's ViewModels - see below)
├── Views/
│   ├── AdminReport/Index.cshtml    one page, every report section
│   ├── AdminProfile/Index.cshtml, Edit.cshtml, ChangePassword.cshtml
│   └── Shared/_AdminAlerts.cshtml  new reusable partial
├── Content/CSS/
│   └── Reports.css
├── ExistingFileChanges/
│   ├── _AdminSidebar.cshtml.CHANGES.txt
│   ├── _AdminLayout.cshtml.CHANGES.txt
│   └── AdminDashboardIndex.cshtml.CHANGES.txt
└── README.md
```

## 2. Design decisions explained

**Why `AdminProfileController` reuses `EditProfileViewModel` and
`ChangePasswordViewModel` from the Customer Module instead of new ones:**
Both forms need exactly the same shape — a name/mobile edit form, and a
current/new/confirm password form. Writing two more nearly-identical
ViewModel files would be pure duplication with zero benefit. This is a
direct example of the "reusable, maintainable" code this Part's spec asks for.

**Why Reports is one page with many sections, not five separate pages:**
An Admin checking business health wants the full picture at a glance —
Sales, Products, Categories, Customers, and Orders all relate to each
other (e.g. seeing Low Stock right next to Top Selling makes the connection
obvious). Splitting into five separate pages would mean five page loads to
get one mental picture. One controller action, one query pass, one page.

**Why `_AdminAlerts.cshtml` is a partial now, but Navbar/Footer are not:**
This is the spec's own escape hatch in action — "if Partial Views are
unnecessary for any section, explicitly mention 'No Partial View Required.'"
Alerts genuinely benefit: the same 12 lines of markup would otherwise need
to be pasted into every single Admin View that shows a success/error
message. Navbar and Footer, by contrast, are each used in exactly **one**
place — inside `_AdminLayout.cshtml` itself. Extracting something used
only once into its own file doesn't reduce any duplication; it just adds
an extra file to open. **No Partial View Required for Navbar or Footer.**
(Sidebar remains a partial, unchanged since Part 1 — that one genuinely is
reused, conceptually, across every Admin page via the Layout.)

**Why only one new CSS file (`Reports.css`), not the seven separate files
(`Dashboard.css`, `Customer.css`, `Order.css`, `Coupon.css`...) the original
spec lists:** This has been a deliberate choice since Part 2, for a
concrete reason you've felt directly — every new CSS file is another
opportunity for a broken link, a naming collision (remember `Product.css`
vs `AdminProduct.css`?), or a missed `<link>` tag during setup. The shared
classes in `Admin.css`/`Category.css` (`adm-section-card`, `adm-summary-card`,
`adm-cat-table`, `adm-form-card`, `adm-bar-row/track/fill`, etc.) already
cover everything every Admin page needs, consistently. Reports.css exists
only because two very minor, genuinely report-specific tweaks didn't fit
anywhere else. This trades strict spec-literalism for fewer moving parts —
worth explaining plainly if asked during evaluation.

**Why there are no new JavaScript files (`Dashboard.js`, `Category.js`,
etc.):** Every interactive behavior in the whole Admin Panel so far has
been handled with two tiny inline snippets — `onchange="this.form.submit()"`
for sort dropdowns, and `onsubmit="return confirm(...)"` for delete
confirmations. Neither needs a separate file or jQuery; both are plain
HTML attributes. **No JavaScript files required** for this project, matching
the spec's own instruction to avoid unnecessary jQuery.

**Why Reports' Monthly Orders chart is the same simple CSS-bar technique
as the Dashboard's Top Categories chart (Part 1):** Consistency, and the
same reasoning as before — a real chart library (Chart.js) would add a new
dependency and a new syntax for one visual feature. Server-calculated bar
widths give a genuine, real-data chart with zero extra files.

## 3. Project Integration & Structure (as the spec asks for)

**How every module connects — the real navigation path:**
```
Login (Account/Login)
  → role = Admin →  AdminDashboard/Index
        ├─ Sidebar: Categories  → AdminCategory/Index    (Part 2)
        ├─ Sidebar: Products    → AdminProduct/Index     (Part 3)
        ├─ Sidebar: Customers   → AdminCustomer/Index    (Part 4)
        ├─ Sidebar: Orders      → AdminOrder/Index       (Part 4)
        ├─ Sidebar: Coupons     → AdminCoupon/Index      (Part 4)
        ├─ Sidebar: Reports     → AdminReport/Index      (Part 5, this one)
        ├─ Sidebar: Profile     → AdminProfile/Index     (Part 5, this one)
        └─ Sidebar: Logout      → Account/Logout
```
Every one of those pages shares the exact same `_AdminLayout.cshtml` and
`_AdminSidebar.cshtml` — so the sidebar, top navbar, and footer look and
behave identically everywhere, and the currently-open page always
highlights correctly (via each Controller's `ViewBag.ActiveMenu`, or in
the Sidebar's case, `ViewContext.RouteData.Values["controller"]`).

**Folder structure, and why each folder exists:**
- `Controllers/` — one file per resource (`AdminCategoryController`,
  `AdminProductController`, ...). Keeps each page's logic isolated —
  editing how Coupons work can never accidentally break Products.
- `ViewModels/` — the "safe shapes" of data that flow between Controller
  and View, used whenever the raw EF entity either lacks validation
  attributes or exposes fields a form shouldn't directly bind to (see
  Stage 1's `RegisterViewModel` for the original example of this).
- `Views/AdminX/` — one folder per Controller (MVC's own convention, not
  a style choice) holding that Controller's `.cshtml` files.
- `Views/Shared/` — anything used by more than one page: `_AdminLayout.cshtml`,
  `_AdminSidebar.cshtml`, `_AdminAlerts.cshtml`.
- `Helpers/` — small, static, reusable logic that isn't tied to any one
  Controller: `SessionHelper` (login/role checks), `ImageUploadHelper`
  (Category and Product images both use it), `PasswordHasher` (Stage 1,
  reused by every password-related action since).
- `Content/CSS/` — stylesheets, kept modular per major area (Customer vs
  Admin) rather than one giant file, but consolidated within Admin itself
  for the reasons above.
- `Content/Images/` — uploaded Category and Product photos, organized into
  their own subfolders.

**Execution flow — one concrete example (Add Product), to show how every
piece fits together end to end:**
```
Admin clicks "+ Add Product"
  → GET AdminProduct/Add → Controller checks SessionHelper.IsAdminLoggedIn
  → loads Categories for the dropdown → returns the empty form
Admin fills the form, submits
  → POST AdminProduct/Add → ModelState validation (Required/Range attributes)
  → duplicate name check (LINQ .Any())
  → ImageUploadHelper.SaveImage() validates + saves the file, returns a filename
  → new Product entity built from the ViewModel
  → db.Products.Add() stages it → db.SaveChanges() writes it to SQL Server
  → TempData["SuccessMessage"] set → RedirectToAction("Index")
  → Manage Products page reloads, shows the new product, success banner shows
```
Every Add/Edit/Delete action anywhere in the Admin Panel follows this exact
same shape — once you understand this one, you understand all of them.

**Responsive design:** every Admin page uses Bootstrap's grid classes
(`col-sm-*`, `col-md-*`) exactly like the Customer Module does. `Admin.css`
also includes a `@media (max-width: 767px)` block (written back in Part 1)
that collapses the fixed sidebar into a normal top-to-bottom stacked layout
on phone-width screens.

**NuGet packages:** none required for this Part. No additional NuGet
Package required for anything built across the entire Admin Module —
every feature (image upload, reports, charts) uses only what ships with a
default ASP.NET MVC 5 project.

## 4. Testing checklist

1. **Sales Report numbers** — spot check Total Revenue against
   `SELECT SUM(TotalAmount) FROM Orders` in SSMS; confirm Today/Month/Year
   figures narrow down correctly if you have orders spanning different dates.
2. **Product Report** — Top/Lowest Selling lists match your actual
   `OrderDetails` data; Out of Stock / Low Stock / Inactive counts match
   what you see on the Manage Products page.
3. **Category Report** — Total Products per category matches Manage Categories' counts.
4. **Customer Report** — Active/Inactive counts match Manage Customers;
   Top Customers By Purchase ordering matches what you'd expect from
   Customer Details pages you've already checked.
5. **Order Report** — every status count matches what you see filtering
   Manage Orders by that status; Monthly chart shows the right number of
   orders per month (spot check one month manually).
6. **Empty-data test** — if you have zero Orders so far, confirm every
   Sales/Order number shows `0` or `Rs. 0`, not a crash.
7. **View Profile** — shows your real Admin name, email, mobile.
8. **Edit Profile** — change name/mobile, confirm navbar's displayed name
   updates immediately.
9. **Change Password** — wrong current password is rejected with a clear
   message; correct flow logs you out and the new password works on next login.
10. **Full navigation sweep** — click every single Sidebar link and every
    Dashboard Quick Action button once each; confirm none of them are dead
    `#` links anymore.
11. **Resize the browser** to phone width on a few different Admin pages —
    confirm the sidebar collapses and tables remain usable (may need
    horizontal scroll on tables, which is expected Bootstrap behavior, not a bug).

## 5. Common errors

| Error | Cause | Fix |
|---|---|---|
| Reports page loads but every number is 0 | Genuinely empty tables (no Orders/Products/Customers yet) | Expected behavior, not a bug — add some test data via the Customer site and Admin panel to see real numbers |
| `CS0266` anywhere in `AdminReportController.cs` | A nullable-column assignment slipped through | Every `IsActive`/comparison in this file already follows the safe pattern from Parts 2-4 — if you hit this, double-check you're not looking at a different file |
| Admin Profile page shows blank/errors | `Session["UserId"]` doesn't match a row where `Role = 'Admin'` | Confirm you're logged in as the actual Admin account, not a Customer who somehow reached this URL |
| Navbar "My Profile" link still does nothing | The `_AdminLayout.cshtml` Change 1 wasn't applied | Re-check `ExistingFileChanges/_AdminLayout.cshtml.CHANGES.txt` |

---

**Next (Part 6):** the final part — Admin Role Management, professional
standards, security hardening, and final cross-cutting business rules
(stock restoration edge cases, product rating rules, etc. — some of which
we've actually already implemented along the way). Say the word when ready.
