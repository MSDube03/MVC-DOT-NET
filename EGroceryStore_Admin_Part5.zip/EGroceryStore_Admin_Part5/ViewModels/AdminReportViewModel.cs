using System;
using System.Collections.Generic;

namespace EGroceryStore.ViewModels
{
    // One row inside "Top Selling" / "Lowest Selling" Products.
    public class ReportProductRowViewModel
    {
        public string ProductName { get; set; }
        public int UnitsSold { get; set; }
    }

    // One row in the Category Report table.
    public class ReportCategoryRowViewModel
    {
        public string CategoryName { get; set; }
        public int TotalProducts { get; set; }
        public int ProductsAvailable { get; set; }
        public int ProductsOutOfStock { get; set; }
    }

    // One row inside "Latest Registered" / "Top Customers By Purchase".
    public class ReportCustomerRowViewModel
    {
        public string FullName { get; set; }
        public string Email { get; set; }
        public DateTime? RegisteredDate { get; set; }
        public decimal TotalPurchase { get; set; }
    }

    // One bar in the "Orders - Last 6 Months" simple chart.
    public class MonthlyOrderCountViewModel
    {
        public string MonthLabel { get; set; }
        public int OrderCount { get; set; }
        public decimal BarPercentage { get; set; }
    }

    // Carries every number and list the Reports page needs, in one object -
    // built entirely from real data in AdminReportController, never hardcoded.
    public class AdminReportViewModel
    {
        // ----- Sales Report -----
        public decimal TotalRevenue { get; set; }
        public decimal TodayRevenue { get; set; }
        public decimal MonthlyRevenue { get; set; }
        public decimal YearlyRevenue { get; set; }
        public int TotalOrdersCount { get; set; }
        public decimal AverageOrderValue { get; set; }

        // ----- Product Report -----
        public List<ReportProductRowViewModel> TopSellingProducts { get; set; }
        public List<ReportProductRowViewModel> LowestSellingProducts { get; set; }
        public int OutOfStockCount { get; set; }
        public int LowStockCount { get; set; }
        public int InactiveProductCount { get; set; }

        // ----- Category Report -----
        public List<ReportCategoryRowViewModel> Categories { get; set; }

        // ----- Customer Report -----
        public int TotalCustomers { get; set; }
        public int ActiveCustomers { get; set; }
        public int InactiveCustomers { get; set; }
        public List<ReportCustomerRowViewModel> LatestCustomers { get; set; }
        public List<ReportCustomerRowViewModel> TopCustomersByPurchase { get; set; }

        // ----- Order Report -----
        public int PendingCount { get; set; }
        public int ConfirmedCount { get; set; }
        public int PackedCount { get; set; }
        public int ShippedCount { get; set; }
        public int DeliveredCount { get; set; }
        public int CancelledCount { get; set; }
        public List<MonthlyOrderCountViewModel> MonthlyOrders { get; set; }
    }
}
