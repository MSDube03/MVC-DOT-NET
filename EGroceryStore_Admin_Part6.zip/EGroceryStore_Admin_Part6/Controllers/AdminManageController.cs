using System;
using System.Linq;
using System.Web.Mvc;
using EGroceryStore.Helpers;
using EGroceryStore.Models;
using EGroceryStore.ViewModels;

namespace EGroceryStore.Controllers
{
    // Manages OTHER Admin accounts (view/add/edit/activate/deactivate/reset
    // password). Deliberately separate from AdminProfileController (Part 5),
    // which only ever manages the CURRENTLY LOGGED IN Admin's own profile.
    public class AdminManageController : Controller
    {
        private EGroceryStoreDBEntities db = new EGroceryStoreDBEntities();
        private const int PageSize = 10;

        // GET: AdminManage/Index
        public ActionResult Index(string searchTerm, string statusFilter, string sortBy, int page = 1)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                TempData["ErrorMessage"] = "Your session has expired. Please login again.";
                return RedirectToAction("Login", "Account");
            }

            int currentAdminId = SessionHelper.GetCurrentUserId(Session);

            var query = db.Users.Where(u => u.Role == "Admin").AsQueryable();

            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                string term = searchTerm.ToLower();
                query = query.Where(u =>
                    u.FirstName.ToLower().Contains(term) ||
                    u.LastName.ToLower().Contains(term) ||
                    u.Email.ToLower().Contains(term));
            }

            if (statusFilter == "Active") query = query.Where(u => u.IsActive == true);
            else if (statusFilter == "Inactive") query = query.Where(u => u.IsActive != true);

            var admins = query.ToList();

            var rows = admins.Select(u => new AdminRowViewModel
            {
                UserId = u.UserId,
                FullName = u.FirstName + " " + u.LastName,
                Email = u.Email,
                MobileNumber = u.MobileNumber,
                RegisteredDate = u.CreatedDate,
                IsActive = u.IsActive == true,
                IsCurrentlyLoggedInAdmin = u.UserId == currentAdminId
            }).ToList();

            switch (sortBy)
            {
                case "NameDesc": rows = rows.OrderByDescending(r => r.FullName).ToList(); break;
                case "Newest": rows = rows.OrderByDescending(r => r.RegisteredDate).ToList(); break;
                default: rows = rows.OrderBy(r => r.FullName).ToList(); break;
            }

            int totalPages = (int)Math.Ceiling((double)rows.Count / PageSize);
            if (page < 1) page = 1;
            var pagedRows = rows.Skip((page - 1) * PageSize).Take(PageSize).ToList();

            var model = new AdminManageListViewModel
            {
                Admins = pagedRows,
                SearchTerm = searchTerm,
                StatusFilter = statusFilter,
                SortBy = sortBy,
                CurrentPage = page,
                TotalPages = totalPages
            };

            return View(model);
        }

        // GET: AdminManage/Add
        public ActionResult Add()
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }
            return View(new AdminAddViewModel());
        }

        // POST: AdminManage/Add
        [HttpPost]
        public ActionResult Add(AdminAddViewModel model)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // Duplicate checks - Email AND Mobile Number, per the spec's
            // explicit Admin Business Rules.
            bool emailExists = db.Users.Any(u => u.Email.ToLower() == model.Email.ToLower());
            if (emailExists)
            {
                ModelState.AddModelError("Email", "This email is already registered.");
                return View(model);
            }

            bool mobileExists = db.Users.Any(u => u.MobileNumber == model.MobileNumber);
            if (mobileExists)
            {
                ModelState.AddModelError("MobileNumber", "This mobile number is already registered.");
                return View(model);
            }

            try
            {
                var newAdmin = new User
                {
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    Email = model.Email,
                    MobileNumber = model.MobileNumber,
                    PasswordHash = PasswordHasher.HashText(model.Password),
                    SecurityQuestion = model.SecurityQuestion,
                    SecurityAnswer = PasswordHasher.HashText(model.SecurityAnswer),
                    Role = "Admin",
                    IsActive = true,
                    CreatedDate = DateTime.Now
                };

                db.Users.Add(newAdmin);
                db.SaveChanges();

                TempData["SuccessMessage"] = "New Admin account created successfully.";
                return RedirectToAction("Index");
            }
            catch (Exception)
            {
                ModelState.AddModelError("", "Something went wrong while creating the account. Please try again.");
                return View(model);
            }
        }

        // GET: AdminManage/Edit/5
        public ActionResult Edit(int id)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            var admin = db.Users.FirstOrDefault(u => u.UserId == id && u.Role == "Admin");
            if (admin == null)
            {
                TempData["ErrorMessage"] = "Admin not found.";
                return RedirectToAction("Index");
            }

            var model = new AdminEditViewModel
            {
                UserId = admin.UserId,
                FirstName = admin.FirstName,
                LastName = admin.LastName,
                MobileNumber = admin.MobileNumber
            };

            return View(model);
        }

        // POST: AdminManage/Edit/5
        [HttpPost]
        public ActionResult Edit(AdminEditViewModel model)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var admin = db.Users.FirstOrDefault(u => u.UserId == model.UserId && u.Role == "Admin");
            if (admin == null)
            {
                TempData["ErrorMessage"] = "Admin not found.";
                return RedirectToAction("Index");
            }

            bool mobileExists = db.Users.Any(u => u.MobileNumber == model.MobileNumber && u.UserId != model.UserId);
            if (mobileExists)
            {
                ModelState.AddModelError("MobileNumber", "This mobile number is already registered to another account.");
                return View(model);
            }

            admin.FirstName = model.FirstName;
            admin.LastName = model.LastName;
            admin.MobileNumber = model.MobileNumber;
            db.SaveChanges();

            // If the Admin edited their OWN account, keep the navbar name in sync.
            int currentAdminId = SessionHelper.GetCurrentUserId(Session);
            if (admin.UserId == currentAdminId)
            {
                Session["UserName"] = admin.FirstName + " " + admin.LastName;
            }

            TempData["SuccessMessage"] = "Admin account updated successfully.";
            return RedirectToAction("Index");
        }

        // POST: AdminManage/ToggleStatus
        [HttpPost]
        public ActionResult ToggleStatus(int id)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            int currentAdminId = SessionHelper.GetCurrentUserId(Session);

            // BUSINESS RULE: an Admin can never deactivate their OWN account -
            // otherwise a single careless click could lock every Admin out of
            // the entire panel at once, with nobody left able to undo it.
            if (id == currentAdminId)
            {
                TempData["ErrorMessage"] = "You cannot deactivate your own account.";
                return RedirectToAction("Index");
            }

            var admin = db.Users.FirstOrDefault(u => u.UserId == id && u.Role == "Admin");
            if (admin == null)
            {
                TempData["ErrorMessage"] = "Admin not found.";
                return RedirectToAction("Index");
            }

            bool isCurrentlyActive = admin.IsActive == true;

            // BUSINESS RULE: never allow the LAST active Admin account to be
            // deactivated - that would leave nobody able to log into the
            // Admin panel at all, not even to fix the mistake.
            if (isCurrentlyActive)
            {
                int activeAdminCount = db.Users.Count(u => u.Role == "Admin" && u.IsActive == true);
                if (activeAdminCount <= 1)
                {
                    TempData["ErrorMessage"] = "Cannot deactivate the last active Admin account.";
                    return RedirectToAction("Index");
                }
            }

            admin.IsActive = !isCurrentlyActive;
            db.SaveChanges();

            TempData["SuccessMessage"] = (admin.IsActive == true)
                ? "Admin account activated."
                : "Admin account deactivated.";

            return RedirectToAction("Index");
        }

        // GET: AdminManage/ResetPassword/5
        public ActionResult ResetPassword(int id)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            var admin = db.Users.FirstOrDefault(u => u.UserId == id && u.Role == "Admin");
            if (admin == null)
            {
                TempData["ErrorMessage"] = "Admin not found.";
                return RedirectToAction("Index");
            }

            var model = new AdminResetPasswordViewModel
            {
                UserId = admin.UserId,
                AdminName = admin.FirstName + " " + admin.LastName
            };

            return View(model);
        }

        // POST: AdminManage/ResetPassword
        [HttpPost]
        public ActionResult ResetPassword(AdminResetPasswordViewModel model)
        {
            if (!SessionHelper.IsAdminLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var admin = db.Users.FirstOrDefault(u => u.UserId == model.UserId && u.Role == "Admin");
            if (admin == null)
            {
                TempData["ErrorMessage"] = "Admin not found.";
                return RedirectToAction("Index");
            }

            // Password is hashed immediately, exactly like every other
            // password operation in this project - never stored or compared
            // as plain text at any point.
            admin.PasswordHash = PasswordHasher.HashText(model.NewPassword);
            db.SaveChanges();

            TempData["SuccessMessage"] = "Password reset successfully for " + admin.FirstName + " " + admin.LastName + ".";
            return RedirectToAction("Index");
        }

        // NOTE: there is deliberately no Delete action here. Same reasoning
        // as Products (business rule from Part 6's spec: never permanently
        // delete something that has real history attached) - an Admin
        // account can have created Categories, Products, updated Orders,
        // etc. Deactivate preserves that history; Delete would not.
    }
}
