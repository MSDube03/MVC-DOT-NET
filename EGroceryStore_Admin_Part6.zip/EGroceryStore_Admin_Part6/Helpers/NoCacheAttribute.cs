using System;
using System.Web;
using System.Web.Mvc;

namespace EGroceryStore.Helpers
{
    /// <summary>
    /// ⚠ ADVANCED CONCEPT - a "Global Action Filter".
    ///
    /// WHAT IT IS: a small class that MVC automatically runs around every
    /// single Controller action, without needing to add anything inside
    /// each Controller individually. It's registered once, in FilterConfig.cs.
    ///
    /// WHY IT'S NEEDED HERE: after an Admin (or Customer) clicks Logout,
    /// pressing the browser's Back button can sometimes show a CACHED
    /// version of a protected page - even though Session has already been
    /// cleared - because the browser saved a copy of that page's HTML
    /// before Logout happened. This filter tells the browser "never cache
    /// this page at all", so pressing Back always asks the server fresh,
    /// which then correctly redirects to Login since Session is gone.
    ///
    /// BEGINNER-FRIENDLY ALTERNATIVE: without this filter, you would have
    /// to add the same 3 lines of cache-control code to the TOP of every
    /// single action in every Controller - dozens of places, easy to miss
    /// one. A Global Filter is the standard, safer way to guarantee it
    /// applies everywhere automatically.
    /// </summary>
    public class NoCacheAttribute : ActionFilterAttribute
    {
        public override void OnResultExecuting(ResultExecutingContext filterContext)
        {
            filterContext.HttpContext.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            filterContext.HttpContext.Response.Cache.SetNoStore();
            filterContext.HttpContext.Response.Cache.SetExpires(DateTime.UtcNow.AddDays(-1));
            base.OnResultExecuting(filterContext);
        }
    }
}
