namespace EGroceryStore.Helpers
{
    /// <summary>
    /// Centralizes "which Bootstrap badge color for which status" in one
    /// place, instead of repeating the same if/switch logic inside every
    /// View that shows an Order Status or Stock Status. Used by Order
    /// Management, the Dashboard's Recent Orders table, and Reports.
    /// </summary>
    public static class StatusHelper
    {
        /// <summary>
        /// Returns the Bootstrap label CSS class for a given Order Status.
        /// NOTE: the spec asked for "Shipped = Dark", but this project uses
        /// Bootstrap 3, which has no "label-dark" class (that's a Bootstrap 4+
        /// class) - label-default is the closest equivalent available.
        /// </summary>
        public static string GetOrderStatusBadgeClass(string orderStatus)
        {
            switch (orderStatus)
            {
                case "Pending": return "label-warning";
                case "Placed": return "label-warning"; // backward-compatible with pre-Part4 test orders
                case "Confirmed": return "label-primary";
                case "Packed": return "label-info";
                case "Shipped": return "label-default";
                case "Delivered": return "label-success";
                case "Cancelled": return "label-danger";
                default: return "label-default";
            }
        }

        /// <summary>
        /// Returns the Bootstrap label CSS class for a product's stock level.
        /// </summary>
        public static string GetStockBadgeClass(int stockQuantity, int lowStockThreshold)
        {
            if (stockQuantity == 0) return "label-danger";
            if (stockQuantity <= lowStockThreshold) return "label-warning";
            return "label-success";
        }

        /// <summary>
        /// Returns a human-readable stock status label.
        /// </summary>
        public static string GetStockBadgeText(int stockQuantity, int lowStockThreshold)
        {
            if (stockQuantity == 0) return "Out Of Stock";
            if (stockQuantity <= lowStockThreshold) return "Low Stock";
            return "Available";
        }

        /// <summary>
        /// Returns the overall display status for a Product, combining its
        /// IsActive flag and current stock - both existing columns, no new
        /// ones needed. See README for why "Discontinued"/"Coming Soon" are
        /// NOT separate stored states in this project.
        /// </summary>
        public static string GetProductStatusText(bool isActive, int stockQuantity)
        {
            if (!isActive) return "Inactive";
            if (stockQuantity == 0) return "Out Of Stock";
            return "Available";
        }

        public static string GetProductStatusBadgeClass(bool isActive, int stockQuantity)
        {
            if (!isActive) return "label-default";
            if (stockQuantity == 0) return "label-danger";
            return "label-success";
        }
    }
}
