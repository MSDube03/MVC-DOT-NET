# E-Grocery Store — Admin Module, Part 6 (FINAL): Role Management, Security, Analytics

This is the last part. It adds Admin Role Management (the most important
new feature here), a handful of security/professionalism upgrades, and
extended Reports analytics — plus a full project wrap-up: what conflicts
with your fixed database schema (and why), complete testing/deployment
checklists, and interview-prep material.

**Read Section 5 before you build anything** — it lists every spec item
from Part 6 that genuinely cannot be implemented without changing your
database schema, which the project rules never allowed. Better to know
this upfront than discover it mid-build.

---

## 0. Exact order of steps

1. Confirm Parts 1–5 all still work before starting.
2. Copy in: `Helpers/StatusHelper.cs`, `Helpers/NoCacheAttribute.cs`,
   `ViewModels/` (4 new files), `Controllers/AdminManageController.cs`,
   `Views/AdminManage/` (4 views).
3. Apply the 8 existing-file changes, **in this order**:
   1. `App_Start/FilterConfig.cs` — register the NoCache filter
   2. `Views/Shared/_AdminSidebar.cshtml` — add the Admins link
   3. `ViewModels/AdminDashboardViewModel.cs` — add TotalAdmins/AvailableProducts
   4. `Controllers/AdminDashboardController.cs` — calculate those two values
   5. `Views/AdminDashboard/Index.cshtml` — two new cards + StatusHelper on Recent Orders
   6. `Views/AdminOrder/Index.cshtml` and `Details.cshtml` — StatusHelper badges + quick filters
   7. `ViewModels/AdminReportViewModel.cs`, `Controllers/AdminReportController.cs`,
      `Views/AdminReport/Index.cshtml` — extended analytics (do all three together, they depend on each other)
   8. `Controllers/OrderController.cs` (Customer Module) — sequential Order Numbers
4. Build, fix anything red, run, test.

---

## 1. What's in this folder

```
EGroceryStore_Admin_Part6/
├── Helpers/
│   ├── StatusHelper.cs           consistent badge colors, used everywhere
│   └── NoCacheAttribute.cs       ⚠ Advanced Concept - see Section 3
├── ViewModels/
│   ├── AdminAddViewModel.cs
│   ├── AdminEditViewModel.cs
│   ├── AdminResetPasswordViewModel.cs
│   └── AdminManageListViewModel.cs   also contains AdminRowViewModel
├── Controllers/
│   └── AdminManageController.cs
├── Views/AdminManage/
│   ├── Index.cshtml
│   ├── Add.cshtml
│   ├── Edit.cshtml
│   └── ResetPassword.cshtml
├── ExistingFileChanges/
│   ├── FilterConfig.cs.CHANGES.txt
│   ├── _AdminSidebar.cshtml.CHANGES.txt
│   ├── AdminDashboardViewModel.cs.CHANGES.txt
│   ├── AdminDashboardController.cs.CHANGES.txt
│   ├── AdminDashboardIndex.cshtml.CHANGES.txt
│   ├── AdminOrderViews.CHANGES.txt
│   ├── AdminReportViewModel.cs.CHANGES.txt
│   ├── AdminReportController.cs.CHANGES.txt
│   ├── AdminReportIndex.cshtml.CHANGES.txt
│   └── OrderController.cs.CHANGES.txt   (Customer Module)
└── README.md
```

## 2. Admin Role Management — the main new feature

**Full CRUD-minus-Delete for Admin accounts**, reachable only by an
already-logged-in Admin: View, Add, Edit, Activate/Deactivate, Reset
Password, with search/filter/sort/pagination — exactly matching the
spec's list.

**The 3 business rules, and how each is enforced in code:**
- **Cannot delete an Admin at all** — there is no Delete action in
  `AdminManageController`, period. Same reasoning as Products (Part 3/6):
  an Admin account has real history attached (Categories/Products they
  created, Orders they updated) — deleting it would either break that
  history or silently orphan it. Deactivate is the only removal path.
- **Cannot deactivate your own account** — `ToggleStatus` checks
  `if (id == currentAdminId)` before anything else and blocks it with a
  clear message. Without this, one careless click could lock every Admin
  out of the whole panel simultaneously.
- **Cannot deactivate the last active Admin** — before deactivating,
  the code counts how many Admins currently have `IsActive == true`;
  if it's `1` (the one being deactivated), the action is blocked. This
  guarantees at least one working Admin account always exists.

**Reset Password vs Change Password — why two different flows exist:**
`AdminProfileController.ChangePassword` (Part 5) is self-service — it
requires the Current Password to verify it's really you. `AdminManageController.ResetPassword`
is a *different* Admin resetting *someone else's* password — there's no
"current password" to check, because the person resetting it isn't the
account owner. Both still hash the new password identically.

## 3. Security & Professionalism additions

**`NoCacheAttribute` — ⚠ Advanced Concept, explained fully in the file
itself, summarized here:** a Global Action Filter is code MVC runs
automatically around *every* Controller action, registered once in
`FilterConfig.cs`, instead of pasting the same 3 lines into every action
in every Controller. It stops the browser from showing a cached copy of a
protected page after Logout when the Back button is pressed — pressing
Back now always asks the server fresh, which correctly redirects to Login
since Session is already gone. The simpler, beginner alternative would be
adding those 3 lines to every single action by hand — this project chose
the Global Filter specifically to guarantee nothing gets missed.

**`StatusHelper`** — one static class, several small methods, used
everywhere an Order Status or Stock Status needs a colored badge (Order
Management, Dashboard's Recent Orders, Reports). Before this, every badge
showed the same blue color regardless of actual status — now Pending is
yellow, Delivered is green, Cancelled is red, etc., matching the spec's
Status Color Coding table (with one adjustment — see Section 5).

**Sequential Order Numbers (ORD10001, ORD10002, ...)** — built directly
from `OrderId` (a guaranteed-unique, auto-incrementing SQL Server identity
column) rather than a timestamp. The Order row is saved once (so SQL
Server assigns its `OrderId`), then `OrderNumber` is set to
`"ORD" + (10000 + OrderId)` and saved again in the same request. No new
database column needed — pure calculation from data that already exists.

## 4. Extended Reports (this Part's additions on top of Part 5)

- **Product Analytics**: Highest Rated, Most Wishlisted, Never Purchased,
  Recently Added (5 each)
- **Customer Analytics**: Customers Without Orders, Repeat Customers (2+ orders)
- **Revenue By Category**: total revenue per category, calculated from
  `OrderDetails` joined through `Products` to `Categories`
- **Coupon Analytics**: Active count, Expired count, Coupons Expiring
  Within 7 Days (with names) — **not** Most Used or Unused, see Section 5

## 5. What was intentionally NOT implemented, and why

The spec's own rule: *"if any rule conflicts with another module, explain
the conflict before writing code."* Here's every genuine conflict found,
and the reasoning for each — good material to have ready if asked why
something from the original brief isn't there.

**Product Rating submission** (spec: "Only customers who purchased should
be able to rate; AverageRating auto-updates"): **Not implemented.** Your
database has a `Products.AverageRating` column, but no table to store
*individual* ratings (who rated what, and when). Without that, there's no
way to check "did this customer already rate this product" or to
recalculate an average when a new rating comes in — the underlying data
literally doesn't exist to compute from. This would require adding a new
table, which the project rules explicitly forbid ("never redesign my
existing database"). `AverageRating` remains whatever value already sits
in the column.

**"Discontinued" and "Coming Soon" as distinct Product states**: **Not
implemented as separate stored states.** Your schema has exactly one
relevant boolean column, `Products.IsActive` — there's no way to store
"discontinued" as something different from "inactive" with only one
true/false column, short of adding a new one. `StatusHelper` derives
exactly three states from what already exists: Available (`IsActive` +
stock > 0), Out Of Stock (`IsActive` + stock = 0), and Inactive
(`!IsActive`) — covering the two states the schema can actually support.

**Coupon "Most Used" / "Unused"**: **Not implemented**, same reason as
flagged back in Part 4 — the `Orders` table has no `CouponId` column,
so there is no record anywhere of which coupon (if any) was used on a
given order after checkout. "Active Coupons," "Expired Coupons," and
"Expiring Soon" *are* implemented, since those only need the `Coupon`
table itself, not a link to `Orders`.

**Order "Admin Notes" field**: **Not implemented.** The `Orders` table
has no column for it. Adding a free-text notes column would require a
schema change.

**"Shipped = Dark" badge color**: implemented as `label-default` instead.
Bootstrap 3 (what this project uses throughout) has no `label-dark` class
— that's a Bootstrap 4+ addition. `label-default` (grey) is the closest
available equivalent.

**Excel/PDF Export, Audit Trail, Activity Log** (spec's own "Optional
Features" section): **⚠ Advanced Concept, intentionally skipped.** Excel/PDF
export needs a new NuGet package (e.g. EPPlus or ClosedXML) not currently
in the project. Audit Trail / Activity Log need a brand new database table
to store "who changed what, when" — again, a schema change the rules
don't allow. The spec itself marks these as optional and says to flag
them as advanced if skipped — this is that flag.

**Selectable page size (5/10/20 records)**: every list page currently
uses a fixed `PageSize = 10` constant. Making this user-selectable across
5 different Controllers (Category, Product, Customer, Order, Coupon) was
judged lower priority than the items above, given how much testing time
this project has already taken — flagging it here as a legitimate, safe,
small future enhancement rather than building it under time pressure.

## 6. Complete Project Documentation (as the spec asks for, in one place)

**Folder structure — final state:**
```
Controllers/    - one file per resource, EF context per Controller
ViewModels/     - safe, validated shapes for forms and combined-data pages
Views/AdminX/   - one folder per Admin Controller (MVC convention)
Views/X/        - one folder per Customer Controller
Views/Shared/   - _Layout, _AdminLayout, _AdminSidebar, _AdminAlerts, _ProductCard
Helpers/        - PasswordHasher, SessionHelper, ImageUploadHelper, StatusHelper, NoCacheAttribute
Content/CSS/    - Customer.css/Product.css/Cart.css/Order.css/Responsive.css (Customer)
                  Admin.css/Category.css/AdminProduct.css/Reports.css (Admin, deliberately consolidated - see Part 2's README)
Content/Images/ - Banners/, Categories/, Products/
App_Start/      - RouteConfig, BundleConfig, FilterConfig (now includes NoCacheAttribute)
```

**Full navigation flow, Login to Logout:**
```
Account/Login
  → Role=Customer → Home/Index → Category/Product browsing → Cart → Checkout → Order Confirmation
  → Role=Admin    → AdminDashboard/Index → Categories/Products/Customers/Orders/
                     Coupons/Admins/Reports/Profile (every sidebar link now wired)
Logout (either role) → Account/Login, with NoCacheAttribute preventing
                        Back-button access to anything protected
```

**Testing checklist — full project, one list:**
1. Register → Login → Logout (Customer) — Stage 1
2. Login as Admin → redirected to Dashboard, not Customer Home — Stage 1/Part 1
3. Browse/Search/Filter/Sort/Paginate Products, add to Cart/Wishlist — Stage 2
4. Full Checkout with a Coupon → Order Confirmation → Order History — Stage 2
5. Category & Product full CRUD, image upload, deactivate-hides-from-customer — Parts 2/3
6. Customer search/filter, deactivate blocks their login — Part 4
7. Order status updates follow the valid sequence, cancel restores stock — Part 4
8. Coupon full CRUD, expiry/duplicate validation — Part 4
9. Reports numbers match real data; Admin Profile edit/change password — Part 5
10. **New this Part:** Add a second Admin, log in as them, confirm they can manage everything
11. Try to deactivate your own Admin account → blocked
12. Deactivate every other Admin down to one → the last one is protected
13. Reset another Admin's password → log in as them with the new password
14. Place a new Order → confirm its number is `ORD1000X` style, sequential
15. Check Order Status badges are color-coded correctly on Dashboard, Order
    Management list, and Order Details
16. Logout → press Back button → confirm you land on Login, not a cached page

**Deployment checklist:**
- Confirm `Web.config`'s connection string points to the real deployment
  database, not your local dev one
- Run the default-Admin SQL INSERT (Stage 1) if the target database is fresh
- Confirm `Content/Images/` folders exist and are writable (image uploads
  create them automatically on first use, but double-check server
  permissions in a real hosting environment)
- Set `debug="false"` in `Web.config`'s `<compilation>` tag for production
  (currently `true` for development — this project never changed it, worth
  knowing as a real deployment step)

**Common debugging guide (the patterns that came up repeatedly building this):**
- `CS0266 bool? to bool` → a nullable column assigned directly; fix with
  `== true` / `!= true`
- `Unexpected keyword after "@"` → a `using`/`if` nested directly inside
  another code block's `{ }` with no markup in between; remove the `@`
- `The view '...' was not found` → check the Controller class name and
  namespace exactly match the URL/folder — a typo here breaks routing silently
- `Cannot implicitly convert type 'method' to 'double'` and similar odd
  errors far from where you edited → almost always a copy-paste that
  dropped or duplicated a line; safest fix is downloading the exact file
  fresh rather than hand-editing further

**Presentation points for evaluation:**
- Walk through one full feature end-to-end (Add Product is a good one) —
  Controller, ViewModel, View, validation, image upload, database save
- Explain the layered security: hashed passwords, Session + Role checks
  on every protected action, NoCache after logout
- Show the Category→Product deactivation cascade as a real business rule
  you implemented, not just CRUD
- Be upfront about Section 5's conflicts — showing you understood *why*
  something wasn't built (schema limits) is stronger than pretending
  everything in a huge spec got done

**Interview questions to expect** — see the two separate prep documents
already created earlier in this conversation (evaluation Q&A and concept-
identification reference) — they cover this in full detail already.

**Future scope** (honest, real list): Excel/PDF export, an Audit Trail
table, a proper Ratings/Reviews table linking customers to purchases,
linking Coupons to Orders via a new column, AJAX-based cart/wishlist
updates instead of full page reloads, and selectable pagination page sizes.

---

**This completes all 6 Parts of the Admin Module**, on top of the full
Authentication and Customer Modules from earlier. The project is done —
good luck with the evaluation.
