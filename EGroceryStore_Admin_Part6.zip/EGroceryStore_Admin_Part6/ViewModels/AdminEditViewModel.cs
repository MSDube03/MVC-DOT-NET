using System.ComponentModel.DataAnnotations;

namespace EGroceryStore.ViewModels
{
    // Edit form for an existing Admin account - deliberately does NOT
    // include Email (never editable, same rule as every Profile in this
    // project) or Password (that goes through the separate Reset Password
    // flow instead, which has its own audit-friendly, single-purpose action).
    public class AdminEditViewModel
    {
        public int UserId { get; set; }

        [Required(ErrorMessage = "First name is required")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Last name is required")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Mobile number is required")]
        [RegularExpression(@"^\d{10}$", ErrorMessage = "Mobile number must be exactly 10 digits")]
        public string MobileNumber { get; set; }
    }
}
