using System;
using System.Collections.Generic;

namespace EGroceryStore.ViewModels
{
    // One row in the Manage Admins table.
    public class AdminRowViewModel
    {
        public int UserId { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public string MobileNumber { get; set; }
        public DateTime? RegisteredDate { get; set; }
        public bool IsActive { get; set; }

        // True only for the row representing whoever is CURRENTLY logged
        // in and viewing this page - used to hide the Deactivate button on
        // their own row, since an Admin can never deactivate themselves.
        public bool IsCurrentlyLoggedInAdmin { get; set; }
    }

    public class AdminManageListViewModel
    {
        public List<AdminRowViewModel> Admins { get; set; }
        public string SearchTerm { get; set; }
        public string StatusFilter { get; set; }
        public string SortBy { get; set; }
        public int CurrentPage { get; set; }
        public int TotalPages { get; set; }
    }
}
