using System.ComponentModel.DataAnnotations;

namespace EGroceryStore.ViewModels
{
    // Different from ChangePasswordViewModel (used for self-service password
    // changes in Customer/Admin Profile) - this one has NO "Current Password"
    // field, because a DIFFERENT Admin is the one performing the reset here,
    // not the account owner themselves.
    public class AdminResetPasswordViewModel
    {
        public int UserId { get; set; }

        // Display only - not bound from the form, just shown so the Admin
        // performing the reset can see whose password they're changing.
        public string AdminName { get; set; }

        [Required(ErrorMessage = "New password is required")]
        [StringLength(100, MinimumLength = 6, ErrorMessage = "Password must be at least 6 characters")]
        [DataType(DataType.Password)]
        public string NewPassword { get; set; }

        [Required(ErrorMessage = "Please confirm the new password")]
        [DataType(DataType.Password)]
        [Compare("NewPassword", ErrorMessage = "Passwords do not match")]
        public string ConfirmPassword { get; set; }
    }
}
