using System;
using System.Linq;
using System.Web.Mvc;
using EGroceryStore.Helpers;
using EGroceryStore.Models;       // namespace where your EDMX-generated Users class lives — RENAME if different
using EGroceryStore.ViewModels;

namespace EGroceryStore.Controllers
{
    public class AccountController : Controller
    {
        // This is the EDMX-generated database context.
        // Replace "GroceryDbEntities" with whatever name your .edmx actually generated
        // (check Model1.Context.cs inside your Models folder to confirm the exact class name).
        private GroceryDbEntities db = new GroceryDbEntities();

        // ================= REGISTER =================

        // GET: Account/Register
        // Called when user clicks "Register" link. Simply shows the empty form.
        public ActionResult Register()
        {
            return View();
        }

        // POST: Account/Register
        // Called when user submits the Register form.
        [HttpPost]
        public ActionResult Register(RegisterViewModel model)
        {
            // ModelState.IsValid checks all the [Required], [EmailAddress], [Compare] etc.
            // attributes we placed on RegisterViewModel. If any fail, we return the same
            // view so validation messages show up next to the relevant fields.
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            try
            {
                // Duplicate email check — FirstOrDefault() runs a SQL query that returns
                // the first matching row, or null if nothing matches.
                var existingUser = db.Users.FirstOrDefault(u => u.Email == model.Email);
                if (existingUser != null)
                {
                    ModelState.AddModelError("Email", "This email is already registered");
                    return View(model);
                }

                // Create a new Users entity (the EDMX-generated class) and copy over
                // only the fields we trust — we set Role and IsActive ourselves,
                // the user never gets to choose these.
                Users newUser = new Users
                {
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    Email = model.Email,
                    MobileNumber = model.MobileNumber,
                    PasswordHash = PasswordHasher.HashText(model.Password),
                    SecurityQuestion = model.SecurityQuestion,
                    SecurityAnswer = PasswordHasher.HashText(model.SecurityAnswer),
                    Role = "Customer",
                    IsActive = true,
                    CreatedDate = DateTime.Now
                };

                // Add() stages the new entity in memory (tracked by EF, not yet in the DB).
                db.Users.Add(newUser);

                // SaveChanges() is what actually runs the SQL INSERT and commits it.
                db.SaveChanges();

                TempData["SuccessMessage"] = "Registration successful. Please login.";
                return RedirectToAction("Login");
            }
            catch (Exception)
            {
                // Catches anything unexpected (e.g. DB connection lost) so the user
                // sees a friendly message instead of a raw error/stack trace page.
                ModelState.AddModelError("", "Something went wrong while registering. Please try again.");
                return View(model);
            }
        }

        // ================= LOGIN =================

        // GET: Account/Login
        public ActionResult Login()
        {
            return View();
        }

        // POST: Account/Login
        [HttpPost]
        public ActionResult Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            try
            {
                var user = db.Users.FirstOrDefault(u => u.Email == model.Email);

                // We check user == null AND password match in one step, but only
                // AFTER confirming the user exists (to avoid a null reference error).
                if (user == null || !PasswordHasher.VerifyText(model.Password, user.PasswordHash))
                {
                    ModelState.AddModelError("", "Invalid email or password");
                    return View(model);
                }

                if (!user.IsActive)
                {
                    ModelState.AddModelError("", "Your account has been deactivated. Contact support.");
                    return View(model);
                }

                // Login successful — create the Session.
                // Session is a server-side storage box, unique per visitor, that survives
                // across page requests until the browser closes or it times out (default 20 min).
                Session["UserId"] = user.UserId;
                Session["UserName"] = user.FirstName + " " + user.LastName;
                Session["Role"] = user.Role;

                if (user.Role == "Admin")
                {
                    return RedirectToAction("Index", "AdminDashboard"); // create this controller when you reach Stage 2
                }
                else
                {
                    return RedirectToAction("Index", "Home");
                }
            }
            catch (Exception)
            {
                ModelState.AddModelError("", "Something went wrong while logging in. Please try again.");
                return View(model);
            }
        }

        // ================= LOGOUT =================

        // GET: Account/Logout
        public ActionResult Logout()
        {
            // Session.Abandon() destroys the entire session box immediately —
            // UserId, UserName, Role are all wiped, so protected pages will
            // redirect back to Login.
            Session.Abandon();
            return RedirectToAction("Login");
        }

        // ================= FORGOT PASSWORD (Step 1: Email) =================

        // GET: Account/ForgotPassword
        public ActionResult ForgotPassword()
        {
            return View();
        }

        // POST: Account/ForgotPassword
        [HttpPost]
        public ActionResult ForgotPassword(ForgotPasswordViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var user = db.Users.FirstOrDefault(u => u.Email == model.Email);
            if (user == null)
            {
                ModelState.AddModelError("Email", "No account found with this email");
                return View(model);
            }

            // TempData survives exactly one redirect — perfect for carrying the
            // UserId from this step into the next step's GET action.
            TempData["ResetUserId"] = user.UserId;

            return RedirectToAction("VerifySecurityAnswer");
        }

        // ================= FORGOT PASSWORD (Step 2: Security Question) =================

        // GET: Account/VerifySecurityAnswer
        public ActionResult VerifySecurityAnswer()
        {
            if (TempData["ResetUserId"] == null)
            {
                // Someone navigated here directly without going through Step 1 — send them back.
                return RedirectToAction("ForgotPassword");
            }

            int userId = (int)TempData["ResetUserId"];
            TempData.Keep("ResetUserId"); // re-flag it so it survives into the POST below

            var user = db.Users.FirstOrDefault(u => u.UserId == userId);
            if (user == null)
            {
                return RedirectToAction("ForgotPassword");
            }

            var model = new VerifySecurityAnswerViewModel
            {
                UserId = user.UserId,
                SecurityQuestion = user.SecurityQuestion
            };

            return View(model);
        }

        // POST: Account/VerifySecurityAnswer
        [HttpPost]
        public ActionResult VerifySecurityAnswer(VerifySecurityAnswerViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var user = db.Users.FirstOrDefault(u => u.UserId == model.UserId);
            if (user == null || !PasswordHasher.VerifyText(model.SecurityAnswer, user.SecurityAnswer))
            {
                ModelState.AddModelError("SecurityAnswer", "Incorrect answer");
                model.SecurityQuestion = user?.SecurityQuestion;
                return View(model);
            }

            TempData["ResetUserId"] = user.UserId;
            return RedirectToAction("ResetPassword");
        }

        // ================= FORGOT PASSWORD (Step 3: New Password) =================

        // GET: Account/ResetPassword
        public ActionResult ResetPassword()
        {
            if (TempData["ResetUserId"] == null)
            {
                return RedirectToAction("ForgotPassword");
            }

            int userId = (int)TempData["ResetUserId"];
            TempData.Keep("ResetUserId");

            return View(new ResetPasswordViewModel { UserId = userId });
        }

        // POST: Account/ResetPassword
        [HttpPost]
        public ActionResult ResetPassword(ResetPasswordViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            try
            {
                var user = db.Users.FirstOrDefault(u => u.UserId == model.UserId);
                if (user == null)
                {
                    ModelState.AddModelError("", "Something went wrong. Please restart the process.");
                    return View(model);
                }

                // We only ever WRITE a new hash — we never read or display the old password.
                user.PasswordHash = PasswordHasher.HashText(model.NewPassword);
                db.SaveChanges();

                TempData["SuccessMessage"] = "Password reset successful. Please login with your new password.";
                return RedirectToAction("Login");
            }
            catch (Exception)
            {
                ModelState.AddModelError("", "Something went wrong while resetting your password.");
                return View(model);
            }
        }
    }
}
