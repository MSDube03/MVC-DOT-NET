using System;
using System.Security.Cryptography;
using System.Text;

namespace EGroceryStore.Helpers
{
    /// <summary>
    /// This helper class is responsible for converting plain text
    /// (like a password or a security answer) into a "hash" —
    /// a scrambled, one-way version of the text that cannot be
    /// reversed back into the original text.
    ///
    /// We use this instead of storing plain text so that even if
    /// someone gets access to our database, they cannot read the
    /// real passwords.
    /// </summary>
    public static class PasswordHasher
    {
        /// <summary>
        /// Converts plain text into a SHA256 hash string.
        /// Used for: Password during Registration, Security Answer during
        /// Registration, New Password during Reset Password.
        /// </summary>
        /// <param name="plainText">The original text typed by the user (e.g. "MyPassword123")</param>
        /// <returns>A long, scrambled string representing the hash (e.g. "5e884898da28...")</returns>
        public static string HashText(string plainText)
        {
            // SHA256 is a built-in .NET class that performs the hashing math.
            // "using" makes sure it is properly disposed (cleaned up) after use.
            using (SHA256 sha256 = SHA256.Create())
            {
                // Computers don't hash "text" directly — they hash bytes.
                // So we first convert our string into a byte array.
                byte[] inputBytes = Encoding.UTF8.GetBytes(plainText);

                // This is the actual hashing step. It always produces a
                // fixed-length scrambled byte array, no matter how long
                // the input was.
                byte[] hashBytes = sha256.ComputeHash(inputBytes);

                // Convert the scrambled bytes into a readable string
                // (like "5e884898da28...") so we can store it in a
                // normal NVARCHAR column in SQL Server.
                StringBuilder builder = new StringBuilder();
                foreach (byte b in hashBytes)
                {
                    // "x2" means: show this byte as 2-digit hexadecimal (e.g. "5e")
                    builder.Append(b.ToString("x2"));
                }

                return builder.ToString();
            }
        }

        /// <summary>
        /// Checks whether the plain text entered by the user (e.g. at Login)
        /// matches the hash that is already stored in the database.
        /// </summary>
        /// <param name="enteredPlainText">What the user just typed (e.g. entered password)</param>
        /// <param name="storedHash">The hash already saved in the Users table</param>
        /// <returns>true if they match, false if they don't</returns>
        public static bool VerifyText(string enteredPlainText, string storedHash)
        {
            // We hash whatever the user just typed, using the exact same
            // method as above, then simply compare the two hash strings.
            string enteredHash = HashText(enteredPlainText);

            // StringComparison.Ordinal means: compare character by character,
            // case-sensitive, no culture-specific rules. This is the correct
            // and safest way to compare hash values.
            return string.Equals(enteredHash, storedHash, StringComparison.Ordinal);
        }
    }
}
