# E-Grocery Store — Stage 1: Authentication Module

This folder contains the complete Authentication Module (Login, Register, Forgot Password,
Reset Password, Logout) ready to drop into your existing ASP.NET MVC 5 project.

---

## 0. Exact order of steps, starting from where you are right now

Your current project state: SQL Server database created, EDMX generated and added to the
project, and NOTHING else written yet. That is exactly the right starting point — do the
following in this exact order, and nothing is skipped:

1. Open your project in Visual Studio 2015. Confirm it still builds (Ctrl+Shift+B) with
   zero errors before you add anything — this proves your EDMX/DB connection is healthy.
2. Find your project's real namespace: open any existing file (e.g. `Controllers/HomeController.cs`,
   created automatically by the MVC template) and read its `namespace ...` line at the top.
   Write it down — you'll need it in step 6.
3. Open your `.edmx`-generated context file (Solution Explorer → Models → expand the `.edmx`
   → find the file ending in `.Context.cs` or `.Designer.cs`). Note two things: (a) its
   `namespace` line, (b) the class name that inherits from `DbContext` (this is your
   `GroceryDbEntities`-equivalent). Write both down.
4. Copy in the new folders/files from this package: `ViewModels/`, `Helpers/`, and
   `Views/Account/` (see section 2 below for exact copy steps).
5. Copy in `Controllers/AccountController.cs`.
6. Find & Replace `EGroceryStore` → your real namespace (from step 2) across every `.cs`
   file you just copied in (Controllers, ViewModels, Helpers). Use Visual Studio's
   Edit → Find and Replace → Replace in Files, scoped to Entire Solution, so you don't miss one.
7. In `AccountController.cs`, replace the two placeholders from step 3:
   `using EGroceryStore.Models;` → your real EDMX namespace, and
   `GroceryDbEntities db = new GroceryDbEntities();` → your real context class name.
8. Build the solution (Ctrl+Shift+B). Fix any red errors now — they'll almost always be a
   leftover namespace or class-name mismatch from steps 6–7. Do not move to step 9 until
   this is a clean build.
9. Make the two existing-file changes in `ExistingFileChanges/` (`_Layout.cshtml` is required;
   `Web.config` is optional).
10. Run the project (F5). Manually test Register → Login → Logout once before touching
    Forgot Password or Admin, so you isolate problems early.
11. Generate the Admin password hash and run the SQL insert (section 4 below).
12. Run the full testing checklist (section 5 below).

That's the complete path — no other file needs a single line touched before Stage 1 works.

---

## 1. What's in this folder

```
EGroceryStore_Auth/
├── Controllers/
│   └── AccountController.cs
├── ViewModels/
│   ├── RegisterViewModel.cs
│   ├── LoginViewModel.cs
│   ├── ForgotPasswordViewModel.cs
│   ├── VerifySecurityAnswerViewModel.cs
│   └── ResetPasswordViewModel.cs
├── Helpers/
│   └── PasswordHasher.cs
├── Views/
│   └── Account/
│       ├── Register.cshtml
│       ├── Login.cshtml
│       ├── ForgotPassword.cshtml
│       ├── VerifySecurityAnswer.cshtml
│       └── ResetPassword.cshtml
├── ExistingFileChanges/
│   ├── _Layout.cshtml.CHANGES.txt   ← exact Old Code / New Code for your existing layout
│   └── Web.config.CHANGES.txt       ← optional session timeout change
├── SQL/
│   └── DefaultAdmin.sql             ← INSERT statement for the one default Admin account
└── README.md                        ← this file
```

## 2. Copying files into your real project

1. In **Visual Studio 2015**, with your project open, copy:
   - `Controllers/AccountController.cs` → your project's `Controllers/` folder
   - `ViewModels/*.cs` (all 5 files) → a new `ViewModels/` folder in your project (right-click project → Add → New Folder → `ViewModels`, then Add → Existing Item for each file)
   - `Helpers/PasswordHasher.cs` → a new `Helpers/` folder
   - `Views/Account/*.cshtml` (all 5 files) → a new `Views/Account/` folder

2. **Rename the namespace.** Every `.cs` file here uses `EGroceryStore` as a placeholder namespace (e.g. `namespace EGroceryStore.Controllers`). Open any existing file in your project (like `HomeController.cs`) and check its actual `namespace` line — then Find & Replace `EGroceryStore` with your real project namespace across all the files you just copied in.

3. **Fix the EF context reference.** In `AccountController.cs`:
   ```csharp
   using EGroceryStore.Models;
   ...
   private GroceryDbEntities db = new GroceryDbEntities();
   ```
   Replace `EGroceryStore.Models` with the actual namespace of your `.edmx`-generated model, and replace `GroceryDbEntities` with your actual context class name. Both are visible inside your `Model1.Context.cs` file (or similarly named file) under your Models folder.

## 3. Existing files you need to modify

Do NOT skip this — see the exact Old Code / New Code in:
- `ExistingFileChanges/_Layout.cshtml.CHANGES.txt` (required — adds Login/Register/Logout links to your navbar)
- `ExistingFileChanges/Web.config.CHANGES.txt` (optional — longer session timeout)

No changes are needed to `RouteConfig.cs`, `BundleConfig.cs`, `FilterConfig.cs`, or `Global.asax` for this module.

**Client-side validation:** each Account view now ends with a `@section Scripts { @Scripts.Render("~/bundles/jqueryval") }` block, which pulls in live validation (red messages as you type, before you even submit). This works automatically with the default MVC 5 template's `_Layout.cshtml`, because it already contains `@RenderSection("scripts", required: false)` near the bottom — you don't need to add anything for this to work, just don't delete that line if you ever edit `_Layout.cshtml`.

## 4. Creating the default Admin account

1. Temporarily add this throwaway action anywhere (e.g. in `AccountController.cs`) to generate hash values:
   ```csharp
   public ActionResult TestHash()
   {
       return Content(PasswordHasher.HashText("Admin@123"));
   }
   ```
2. Run the project, browse to `/Account/TestHash`, copy the hash string shown.
3. Change the text `"Admin@123"` to your chosen security answer (e.g. `"Pizza"`), rerun, copy that hash too.
4. Open `SQL/DefaultAdmin.sql`, paste the two hashes in place of `<PASTE_HASHED_PASSWORD_HERE>` and `<PASTE_HASHED_SECURITY_ANSWER_HERE>`.
5. Run the completed script in **SQL Server Management Studio (SSMS)**, connected to your project's database, in a New Query window.
6. **Delete the `TestHash` action** from your Controller — it must not exist in your final submitted project.

The Admin logs in through the exact same `/Account/Login` page as any customer — `AccountController` checks `Role == "Admin"` after a successful password check and redirects to `AdminDashboard` instead of `Home`.

## 5. Testing checklist

1. Register a new user → redirected to Login with a success message.
2. Register the same email again → "already registered" error.
3. Login with correct credentials → redirected to Home (Customer) or AdminDashboard (Admin).
4. Login with wrong password → "Invalid email or password".
5. Forgot Password → enter email → see your security question → answer correctly → set new password → login with the new password works, old one fails.
6. Logout → navbar reverts to Login/Register, Session is cleared.

## 6. Common errors

| Error | Cause | Fix |
|---|---|---|
| `The type or namespace 'Users' could not be found` | Wrong `using` namespace for your EDMX models | Match the namespace used in your `.edmx`-generated `.cs` file |
| `GroceryDbEntities does not exist` | Your context class has a different name | Check `Model1.Context.cs`, update `AccountController.cs` accordingly |
| Validation messages only appear after a full page refresh (no live client-side validation) | jQuery validation bundle not rendered on this page | Confirm `_Layout.cshtml` includes `@Scripts.Render("~/bundles/jqueryval")` (present by default in the MVC 5 template) |
| `Session["UserId"]` is null right after login | Redirect happened before Session assignment, or browser blocking cookies | Confirm the `Session[...] = ...` lines run before `RedirectToAction` in `Login()` |
| `AdminDashboard` controller not found | Stage 2 hasn't been built yet | Temporarily change that redirect to `RedirectToAction("Index", "Home")` until Stage 2 exists |

## 7. Known Stage-1 simplification (flag this if asked during evaluation)

The Forgot Password flow carries the `UserId` through `TempData` between steps rather than
a signed, expiring database token — the schema you gave has no token table, and adding one
would violate the "don't modify the database" rule for this stage. This is fine for a
training project; a production system would normally use a time-limited, unguessable reset
token instead.

---

**Next step (Stage 2):** Category & Product management (Admin side), and Home/Product listing (Customer side) — say the word when you're ready and I'll continue in the same one-file-at-a-time, fully-explained format.
