-- =========================================================
-- Default Admin Account — run in SQL Server Management Studio (SSMS)
-- connected to your project's database, in a New Query window.
--
-- IMPORTANT: You must replace the two placeholders below with REAL
-- hashed values BEFORE running this. See "How to generate the hash"
-- in README.md.
-- =========================================================

INSERT INTO Users
    (FirstName, LastName, Email, PasswordHash, MobileNumber, Role,
     SecurityQuestion, SecurityAnswer, Adress, City, State, Pincode, IsActive, CreatedDate)
VALUES
    ('System', 'Admin', 'admin@egrocery.com',
     '<PASTE_HASHED_PASSWORD_HERE>',
     '9999999999', 'Admin',
     'What is your favourite food?',
     '<PASTE_HASHED_SECURITY_ANSWER_HERE>',
     NULL, NULL, NULL, NULL, 1, GETDATE());
