using System.ComponentModel.DataAnnotations;

namespace EGroceryStore.ViewModels
{
    // Step 1 of Forgot Password: just collect the email to look up the user.
    public class ForgotPasswordViewModel
    {
        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Enter a valid email address")]
        public string Email { get; set; }
    }
}
