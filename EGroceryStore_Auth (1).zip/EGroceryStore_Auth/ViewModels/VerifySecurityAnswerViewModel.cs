using System.ComponentModel.DataAnnotations;

namespace EGroceryStore.ViewModels
{
    // Step 2 of Forgot Password: show the stored question, collect the answer.
    // UserId travels along as a hidden field so the Controller knows whose answer to check.
    public class VerifySecurityAnswerViewModel
    {
        public int UserId { get; set; }

        public string SecurityQuestion { get; set; }

        [Required(ErrorMessage = "Security answer is required")]
        public string SecurityAnswer { get; set; }
    }
}
