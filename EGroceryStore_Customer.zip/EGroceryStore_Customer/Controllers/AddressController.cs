using System;
using System.Linq;
using System.Web.Mvc;
using EGroceryStore.Helpers;
using EGroceryStore.Models;
using EGroceryStore.ViewModels;

namespace EGroceryStore.Controllers
{
    public class AddressController : Controller
    {
        private GroceryDbEntities db = new GroceryDbEntities();

        // GET: Address/Index
        public ActionResult Index()
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }
            int userId = SessionHelper.GetCurrentUserId(Session);
            ViewBag.ActiveMenu = "Addresses";

            var addresses = db.Adresses.Where(a => a.UserId == userId).OrderByDescending(a => a.IsDefault).ToList();
            return View(addresses);
        }

        // GET: Address/Add
        public ActionResult Add()
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }
            // Default the dropdown to "Home" for convenience.
            return View(new AddressViewModel { AdressType = "Home" });
        }

        // POST: Address/Add
        [HttpPost]
        public ActionResult Add(AddressViewModel model)
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            int userId = SessionHelper.GetCurrentUserId(Session);

            var newAddress = new Adresses
            {
                UserId = userId,
                FullName = model.FullName,
                MobileNumber = model.MobileNumber,
                AdressLine1 = model.AdressLine1,
                AdressLine2 = model.AdressLine2,
                Landmark = model.Landmark,
                City = model.City,
                State = model.State,
                Pincode = model.Pincode,
                AdressType = model.AdressType,
                IsDefault = model.IsDefault,
                CreatedDate = DateTime.Now
            };

            // If this is the customer's very first address, make it Default automatically.
            bool hasAnyAddress = db.Adresses.Any(a => a.UserId == userId);
            if (!hasAnyAddress)
            {
                newAddress.IsDefault = true;
            }

            // Only one Default Address should ever exist. If this new address is
            // being marked Default, remove Default status from every other one first.
            if (newAddress.IsDefault)
            {
                var currentDefaults = db.Adresses.Where(a => a.UserId == userId && a.IsDefault == true).ToList();
                foreach (var addr in currentDefaults)
                {
                    addr.IsDefault = false;
                }
            }

            db.Adresses.Add(newAddress);
            db.SaveChanges();

            TempData["SuccessMessage"] = "Address added successfully.";
            return RedirectToAction("Index");
        }

        // GET: Address/Edit/5
        public ActionResult Edit(int id)
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }
            int userId = SessionHelper.GetCurrentUserId(Session);

            // Also check UserId, so a customer cannot edit someone else's address
            // just by guessing an AdressId in the URL.
            var address = db.Adresses.FirstOrDefault(a => a.AdressId == id && a.UserId == userId);
            if (address == null)
            {
                return HttpNotFound();
            }

            var model = new AddressViewModel
            {
                AdressId = address.AdressId,
                FullName = address.FullName,
                MobileNumber = address.MobileNumber,
                AdressLine1 = address.AdressLine1,
                AdressLine2 = address.AdressLine2,
                Landmark = address.Landmark,
                City = address.City,
                State = address.State,
                Pincode = address.Pincode,
                AdressType = address.AdressType,
                IsDefault = address.IsDefault
            };

            return View(model);
        }

        // POST: Address/Edit/5
        [HttpPost]
        public ActionResult Edit(AddressViewModel model)
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            int userId = SessionHelper.GetCurrentUserId(Session);
            var existing = db.Adresses.FirstOrDefault(a => a.AdressId == model.AdressId && a.UserId == userId);
            if (existing == null)
            {
                return HttpNotFound();
            }

            existing.FullName = model.FullName;
            existing.MobileNumber = model.MobileNumber;
            existing.AdressLine1 = model.AdressLine1;
            existing.AdressLine2 = model.AdressLine2;
            existing.Landmark = model.Landmark;
            existing.City = model.City;
            existing.State = model.State;
            existing.Pincode = model.Pincode;
            existing.AdressType = model.AdressType;

            if (model.IsDefault && !existing.IsDefault)
            {
                var currentDefaults = db.Adresses.Where(a => a.UserId == userId && a.IsDefault == true).ToList();
                foreach (var addr in currentDefaults)
                {
                    addr.IsDefault = false;
                }
                existing.IsDefault = true;
            }

            db.SaveChanges();
            TempData["SuccessMessage"] = "Address updated successfully.";
            return RedirectToAction("Index");
        }

        // POST: Address/Delete
        [HttpPost]
        public ActionResult Delete(int id)
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }
            int userId = SessionHelper.GetCurrentUserId(Session);

            var address = db.Adresses.FirstOrDefault(a => a.AdressId == id && a.UserId == userId);
            if (address != null)
            {
                bool wasDefault = address.IsDefault;
                db.Adresses.Remove(address);
                db.SaveChanges();

                // If the deleted address was the Default one, promote another
                // remaining address automatically so the customer is never left
                // with zero Default addresses.
                if (wasDefault)
                {
                    var anotherAddress = db.Adresses.FirstOrDefault(a => a.UserId == userId);
                    if (anotherAddress != null)
                    {
                        anotherAddress.IsDefault = true;
                        db.SaveChanges();
                    }
                }

                TempData["SuccessMessage"] = "Address deleted successfully.";
            }

            return RedirectToAction("Index");
        }

        // POST: Address/SetDefault
        [HttpPost]
        public ActionResult SetDefault(int id)
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }
            int userId = SessionHelper.GetCurrentUserId(Session);

            // Loop through every address this customer owns: mark the chosen one
            // Default = true, and every other one Default = false. This guarantees
            // only one Default Address can ever exist at a time.
            var allAddresses = db.Adresses.Where(a => a.UserId == userId).ToList();
            foreach (var addr in allAddresses)
            {
                addr.IsDefault = (addr.AdressId == id);
            }

            db.SaveChanges();
            TempData["SuccessMessage"] = "Default address updated.";
            return RedirectToAction("Index");
        }
    }
}
