using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using EGroceryStore.Helpers;
using EGroceryStore.Models;
using EGroceryStore.ViewModels;

namespace EGroceryStore.Controllers
{
    public class CartController : Controller
    {
        private GroceryDbEntities db = new GroceryDbEntities();

        // GET: Cart/Index
        public ActionResult Index()
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }
            int userId = SessionHelper.GetCurrentUserId(Session);
            ViewBag.ActiveMenu = "Cart";

            var cartRows = db.Cart.Where(c => c.UserId == userId).ToList();

            var items = new List<CartItemViewModel>();
            decimal grandTotal = 0;

            foreach (var row in cartRows)
            {
                var product = db.Products.FirstOrDefault(p => p.ProductId == row.ProductId);
                if (product == null) continue;

                decimal subtotal = product.Price * row.Quantity;
                grandTotal += subtotal;

                items.Add(new CartItemViewModel
                {
                    CartId = row.CartId,
                    ProductId = product.ProductId,
                    ProductName = product.ProductName,
                    ImagePath = product.ImagePath,
                    Price = product.Price,
                    Quantity = row.Quantity,
                    StockQuantity = product.StockQuantity,
                    Subtotal = subtotal
                });
            }

            ViewBag.GrandTotal = grandTotal;
            ViewBag.TotalItems = items.Count;

            return View(items);
        }

        // POST: Cart/Add
        [HttpPost]
        public ActionResult Add(int productId)
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }
            int userId = SessionHelper.GetCurrentUserId(Session);
            string backUrl = Request.UrlReferrer != null ? Request.UrlReferrer.ToString() : Url.Action("Index", "Home");

            var product = db.Products.FirstOrDefault(p => p.ProductId == productId && p.IsActive == true);
            if (product == null)
            {
                TempData["ErrorMessage"] = "Product not found.";
                return Redirect(backUrl);
            }

            if (product.StockQuantity <= 0)
            {
                TempData["ErrorMessage"] = "This product is out of stock.";
                return Redirect(backUrl);
            }

            var existingItem = db.Cart.FirstOrDefault(c => c.UserId == userId && c.ProductId == productId);
            if (existingItem != null)
            {
                // Quantity in cart should never exceed available stock.
                if (existingItem.Quantity + 1 > product.StockQuantity)
                {
                    TempData["ErrorMessage"] = "Cannot add more - not enough stock available.";
                    return Redirect(backUrl);
                }
                existingItem.Quantity += 1;
            }
            else
            {
                db.Cart.Add(new Cart { UserId = userId, ProductId = productId, Quantity = 1, AddedDate = DateTime.Now });
            }

            db.SaveChanges();
            TempData["SuccessMessage"] = "Product added to Cart.";
            return Redirect(backUrl);
        }

        // POST: Cart/Increase
        [HttpPost]
        public ActionResult Increase(int cartId)
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            var item = db.Cart.FirstOrDefault(c => c.CartId == cartId);
            if (item != null)
            {
                var product = db.Products.FirstOrDefault(p => p.ProductId == item.ProductId);
                if (product != null && item.Quantity < product.StockQuantity)
                {
                    item.Quantity += 1;
                    db.SaveChanges();
                }
                else
                {
                    TempData["ErrorMessage"] = "Cannot add more - not enough stock available.";
                }
            }

            return RedirectToAction("Index");
        }

        // POST: Cart/Decrease
        [HttpPost]
        public ActionResult Decrease(int cartId)
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            var item = db.Cart.FirstOrDefault(c => c.CartId == cartId);
            if (item != null)
            {
                if (item.Quantity > 1)
                {
                    item.Quantity -= 1;
                    db.SaveChanges();
                }
                else
                {
                    // Quantity should never become zero - remove the row instead.
                    db.Cart.Remove(item);
                    db.SaveChanges();
                }
            }

            return RedirectToAction("Index");
        }

        // POST: Cart/Remove
        [HttpPost]
        public ActionResult Remove(int cartId)
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            var item = db.Cart.FirstOrDefault(c => c.CartId == cartId);
            if (item != null)
            {
                db.Cart.Remove(item);
                db.SaveChanges();
                TempData["SuccessMessage"] = "Product removed from Cart.";
            }

            return RedirectToAction("Index");
        }
    }
}
