using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using EGroceryStore.Helpers;
using EGroceryStore.Models;

namespace EGroceryStore.Controllers
{
    public class CategoryController : Controller
    {
        private GroceryDbEntities db = new GroceryDbEntities();

        // GET: Category/Index
        // Shows every active category as a card. Clicking a card opens the
        // Product List page filtered to that category.
        public ActionResult Index()
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            ViewBag.ActiveMenu = "Categories";

            var categories = db.Categories.Where(c => c.IsActive == true).ToList();

            // "Number Of Products" on each card - counted per category using a
            // simple dictionary lookup, instead of a more advanced join query.
            var productCounts = new Dictionary<int, int>();
            foreach (var category in categories)
            {
                productCounts[category.CategoryId] =
                    db.Products.Count(p => p.CategoryId == category.CategoryId && p.IsActive == true);
            }
            ViewBag.ProductCounts = productCounts;

            return View(categories);
        }
    }
}
