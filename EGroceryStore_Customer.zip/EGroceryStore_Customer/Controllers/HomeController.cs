using System;
using System.Linq;
using System.Web.Mvc;
using EGroceryStore.Helpers;
using EGroceryStore.Models;

namespace EGroceryStore.Controllers
{
    // This is the Customer Dashboard - the landing page shown right after login.
    public class HomeController : Controller
    {
        private GroceryDbEntities db = new GroceryDbEntities();

        // GET: Home/Index
        public ActionResult Index()
        {
            // Protect this page - only logged in customers can see the dashboard.
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            // Used by _Layout.cshtml to highlight "Home" in the navbar.
            ViewBag.ActiveMenu = "Home";

            // 1. Categories section - only active categories, straight from SQL Server.
            ViewBag.Categories = db.Categories.Where(c => c.IsActive == true).ToList();

            // 2. Featured Products - for a trainee-level project, we treat the
            //    highest rated active products as "Featured".
            ViewBag.FeaturedProducts = db.Products
                .Where(p => p.IsActive == true)
                .OrderByDescending(p => p.AverageRating)
                .Take(8)
                .ToList();

            // 3. Recently Added Products - newest first, using CreatedDate.
            ViewBag.RecentProducts = db.Products
                .Where(p => p.IsActive == true)
                .OrderByDescending(p => p.CreatedDate)
                .Take(8)
                .ToList();

            // 4. Best Selling Products - based on how many times each product has
            //    actually been ordered (OrderDetails table), not a guess.
            //    GroupBy(od => od.ProductId) groups every OrderDetails row by
            //    ProductId, then Sum(x => x.Quantity) adds up how many units of
            //    that product were sold across all orders.
            var bestSellingIds = db.OrderDetails
                .GroupBy(od => od.ProductId)
                .Select(g => new { ProductId = g.Key, TotalSold = g.Sum(x => x.Quantity) })
                .OrderByDescending(x => x.TotalSold)
                .Take(8)
                .Select(x => x.ProductId)
                .ToList();

            ViewBag.BestSellingProducts = db.Products
                .Where(p => bestSellingIds.Contains(p.ProductId) && p.IsActive == true)
                .ToList();

            // 5. Active, non-expired Coupons - for the Special Offers banner.
            ViewBag.ActiveCoupons = db.Coupon
                .Where(c => c.IsActive == true && c.ExpiryDate >= DateTime.Now)
                .ToList();

            return View();
        }
    }
}
