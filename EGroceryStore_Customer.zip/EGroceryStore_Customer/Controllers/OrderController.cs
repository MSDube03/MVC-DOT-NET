using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using EGroceryStore.Helpers;
using EGroceryStore.Models;
using EGroceryStore.ViewModels;

namespace EGroceryStore.Controllers
{
    public class OrderController : Controller
    {
        private GroceryDbEntities db = new GroceryDbEntities();

        // GET: Order/Checkout
        public ActionResult Checkout()
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }
            int userId = SessionHelper.GetCurrentUserId(Session);
            ViewBag.ActiveMenu = "Orders";

            var cartRows = db.Cart.Where(c => c.UserId == userId).ToList();
            if (cartRows.Count == 0)
            {
                TempData["ErrorMessage"] = "Your cart is empty.";
                return RedirectToAction("Index", "Cart");
            }

            var cartItems = new List<CartItemViewModel>();
            decimal subtotal = 0;
            foreach (var row in cartRows)
            {
                var product = db.Products.FirstOrDefault(p => p.ProductId == row.ProductId);
                if (product == null) continue;

                decimal lineTotal = product.Price * row.Quantity;
                subtotal += lineTotal;

                cartItems.Add(new CartItemViewModel
                {
                    CartId = row.CartId,
                    ProductId = product.ProductId,
                    ProductName = product.ProductName,
                    ImagePath = product.ImagePath,
                    Price = product.Price,
                    Quantity = row.Quantity,
                    StockQuantity = product.StockQuantity,
                    Subtotal = lineTotal
                });
            }

            var addresses = db.Adresses.Where(a => a.UserId == userId).OrderByDescending(a => a.IsDefault).ToList();

            // If a coupon was already applied earlier in this Session, keep showing it.
            decimal discount = Session["AppliedDiscount"] != null ? Convert.ToDecimal(Session["AppliedDiscount"]) : 0;
            string couponCode = Session["AppliedCouponCode"] as string;

            var model = new CheckoutViewModel
            {
                CartItems = cartItems,
                Addresses = addresses,
                SelectedAddressId = addresses.Count > 0 ? addresses[0].AdressId : 0,
                CouponCode = couponCode,
                Discount = discount,
                Subtotal = subtotal,
                GrandTotal = subtotal - discount
            };

            return View(model);
        }

        // POST: Order/ApplyCoupon
        [HttpPost]
        public ActionResult ApplyCoupon(string couponCode)
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            var coupon = db.Coupon.FirstOrDefault(c => c.CouponCode == couponCode);

            if (coupon == null)
            {
                TempData["ErrorMessage"] = "Invalid coupon code.";
            }
            else if (coupon.IsActive != true)
            {
                TempData["ErrorMessage"] = "This coupon is no longer active.";
            }
            else if (coupon.ExpiryDate < DateTime.Now)
            {
                TempData["ErrorMessage"] = "This coupon has expired.";
            }
            else
            {
                int userId = SessionHelper.GetCurrentUserId(Session);
                var cartRows = db.Cart.Where(c => c.UserId == userId).ToList();

                decimal subtotal = 0;
                foreach (var row in cartRows)
                {
                    var product = db.Products.FirstOrDefault(p => p.ProductId == row.ProductId);
                    if (product != null) subtotal += product.Price * row.Quantity;
                }

                decimal discount;
                if (coupon.DiscountType == "Percentage")
                {
                    discount = subtotal * (coupon.DiscountValue / 100);
                }
                else // "Flat"
                {
                    discount = coupon.DiscountValue;
                }

                // Discount can never be larger than the order itself.
                if (discount > subtotal) discount = subtotal;

                Session["AppliedCouponCode"] = coupon.CouponCode;
                Session["AppliedDiscount"] = discount;

                TempData["SuccessMessage"] = "Coupon applied successfully.";
            }

            return RedirectToAction("Checkout");
        }

        // POST: Order/RemoveCoupon
        [HttpPost]
        public ActionResult RemoveCoupon()
        {
            Session["AppliedCouponCode"] = null;
            Session["AppliedDiscount"] = null;
            return RedirectToAction("Checkout");
        }

        // POST: Order/PlaceOrder
        [HttpPost]
        public ActionResult PlaceOrder(int selectedAddressId, string paymentMethod)
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }
            int userId = SessionHelper.GetCurrentUserId(Session);

            // Step 1: Validate Cart is not empty.
            var cartRows = db.Cart.Where(c => c.UserId == userId).ToList();
            if (cartRows.Count == 0)
            {
                TempData["ErrorMessage"] = "Your cart is empty.";
                return RedirectToAction("Index", "Cart");
            }

            // Step 2: Validate the selected Address belongs to this customer.
            var address = db.Adresses.FirstOrDefault(a => a.AdressId == selectedAddressId && a.UserId == userId);
            if (address == null)
            {
                TempData["ErrorMessage"] = "Please select a valid delivery address.";
                return RedirectToAction("Checkout");
            }

            // Step 3: Validate Stock for every item before placing the order.
            foreach (var row in cartRows)
            {
                var product = db.Products.FirstOrDefault(p => p.ProductId == row.ProductId);
                if (product == null || product.StockQuantity < row.Quantity)
                {
                    TempData["ErrorMessage"] = "One or more items in your cart are no longer available in the requested quantity.";
                    return RedirectToAction("Index", "Cart");
                }
            }

            // Step 4: Work out the discount from any coupon applied earlier (stored in Session).
            decimal discount = Session["AppliedDiscount"] != null ? Convert.ToDecimal(Session["AppliedDiscount"]) : 0;

            decimal subtotal = 0;
            foreach (var row in cartRows)
            {
                var product = db.Products.FirstOrDefault(p => p.ProductId == row.ProductId);
                subtotal += product.Price * row.Quantity;
            }
            decimal grandTotal = subtotal - discount;

            // Step 5: Create the Order record.
            // Order Number = "ORD" + current date and time down to the second.
            // This is unique enough for a trainee-level project, without needing
            // a database sequence or a GUID.
            string orderNumber = "ORD" + DateTime.Now.ToString("yyyyMMddHHmmss");

            string fullDeliveryAddress = address.AdressLine1 +
                (string.IsNullOrEmpty(address.AdressLine2) ? "" : ", " + address.AdressLine2) +
                ", " + address.City + ", " + address.State + " - " + address.Pincode;

            var newOrder = new Orders
            {
                OrderNumber = orderNumber,
                UserId = userId,
                OrderDate = DateTime.Now,
                TotalAmount = grandTotal,
                PaymentMethod = paymentMethod,
                PaymentStatus = "Pending",   // No real payment gateway - always starts as Pending.
                OrderStatus = "Placed",
                DeliveryAdress = fullDeliveryAddress
            };

            db.Orders.Add(newOrder);
            // Save now so SQL Server generates newOrder.OrderId (identity column)
            // before we use it below to create the OrderDetails rows.
            db.SaveChanges();

            // Step 6: Create one OrderDetails row per cart item.
            // Step 7: Reduce stock for each product at the same time.
            foreach (var row in cartRows)
            {
                var product = db.Products.FirstOrDefault(p => p.ProductId == row.ProductId);

                db.OrderDetails.Add(new OrderDetails
                {
                    OrderId = newOrder.OrderId,
                    ProductId = row.ProductId,
                    Quantity = row.Quantity,
                    Price = product.Price,
                    SubTotal = product.Price * row.Quantity
                });

                product.StockQuantity -= row.Quantity;
                if (product.StockQuantity < 0) product.StockQuantity = 0; // extra safety
            }

            // Step 8: Clear the customer's Cart.
            db.Cart.RemoveRange(cartRows);

            db.SaveChanges();

            // Coupon was for this order only - clear it from Session now.
            Session["AppliedCouponCode"] = null;
            Session["AppliedDiscount"] = null;

            // Step 9: Redirect to Order Confirmation.
            TempData["SuccessMessage"] = "Order placed successfully!";
            return RedirectToAction("Confirmation", new { id = newOrder.OrderId });
        }

        // Builds the combined ViewModel used by BOTH the Confirmation page and
        // the Order Details page, so we do not write the same lookup logic twice.
        private OrderDetailsViewModel BuildOrderDetailsViewModel(int orderId, int userId)
        {
            var order = db.Orders.FirstOrDefault(o => o.OrderId == orderId && o.UserId == userId);
            if (order == null)
            {
                return null;
            }

            var orderDetailRows = db.OrderDetails.Where(od => od.OrderId == order.OrderId).ToList();
            var items = new List<OrderDetailItemViewModel>();
            foreach (var row in orderDetailRows)
            {
                var product = db.Products.FirstOrDefault(p => p.ProductId == row.ProductId);
                items.Add(new OrderDetailItemViewModel
                {
                    ProductName = product != null ? product.ProductName : "Product",
                    ImagePath = product != null ? product.ImagePath : "",
                    Quantity = row.Quantity,
                    Price = row.Price,
                    SubTotal = row.SubTotal
                });
            }

            return new OrderDetailsViewModel
            {
                OrderId = order.OrderId,
                OrderNumber = order.OrderNumber,
                OrderDate = order.OrderDate,
                DeliveryAdress = order.DeliveryAdress,
                PaymentMethod = order.PaymentMethod,
                OrderStatus = order.OrderStatus,
                PaymentStatus = order.PaymentStatus,
                TotalAmount = order.TotalAmount,
                Items = items
            };
        }

        // GET: Order/Confirmation/5
        public ActionResult Confirmation(int id)
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }
            ViewBag.ActiveMenu = "Orders";

            int userId = SessionHelper.GetCurrentUserId(Session);
            var model = BuildOrderDetailsViewModel(id, userId);
            if (model == null) return HttpNotFound();

            return View(model);
        }

        // GET: Order/History
        public ActionResult History()
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }
            int userId = SessionHelper.GetCurrentUserId(Session);
            ViewBag.ActiveMenu = "Orders";

            var orders = db.Orders.Where(o => o.UserId == userId).OrderByDescending(o => o.OrderDate).ToList();
            return View(orders);
        }

        // GET: Order/Details/5
        public ActionResult Details(int id)
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }
            ViewBag.ActiveMenu = "Orders";

            int userId = SessionHelper.GetCurrentUserId(Session);
            var model = BuildOrderDetailsViewModel(id, userId);
            if (model == null) return HttpNotFound();

            return View(model);
        }
    }
}
