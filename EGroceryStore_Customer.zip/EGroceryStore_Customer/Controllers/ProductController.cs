using System;
using System.Linq;
using System.Web.Mvc;
using EGroceryStore.Helpers;
using EGroceryStore.Models;
using EGroceryStore.ViewModels;

namespace EGroceryStore.Controllers
{
    public class ProductController : Controller
    {
        private GroceryDbEntities db = new GroceryDbEntities();

        // How many products are shown on one page of results.
        private const int PageSize = 8;

        // GET: Product/List
        // Handles browsing, category filtering, searching, filtering, sorting and
        // pagination - all in one action, all backed by SQL Server via Entity Framework.
        public ActionResult List(int? categoryId, string searchTerm, decimal? minPrice, decimal? maxPrice,
            string availability, int? minRating, string sortBy, int page = 1)
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            ViewBag.ActiveMenu = "Products";

            // Start with all active products. This builds an IQueryable, which is
            // just a "query plan" - nothing is sent to SQL Server yet. We keep
            // attaching conditions below; the final SQL is generated only once,
            // at query.Count() and .ToList().
            var query = db.Products.Where(p => p.IsActive == true);

            // ----- Category Filter -----
            if (categoryId.HasValue)
            {
                query = query.Where(p => p.CategoryId == categoryId.Value);
            }

            // ----- Search (Product Name, Description, and Category Name) -----
            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                var matchingCategoryIds = db.Categories
                    .Where(c => c.CategoryName.Contains(searchTerm))
                    .Select(c => c.CategoryId)
                    .ToList();

                query = query.Where(p =>
                    p.ProductName.Contains(searchTerm) ||
                    p.Description.Contains(searchTerm) ||
                    matchingCategoryIds.Contains(p.CategoryId));
            }

            // ----- Price Filter -----
            if (minPrice.HasValue) query = query.Where(p => p.Price >= minPrice.Value);
            if (maxPrice.HasValue) query = query.Where(p => p.Price <= maxPrice.Value);

            // ----- Availability Filter -----
            if (availability == "InStock") query = query.Where(p => p.StockQuantity > 0);
            else if (availability == "OutOfStock") query = query.Where(p => p.StockQuantity == 0);

            // ----- Rating Filter -----
            if (minRating.HasValue) query = query.Where(p => p.AverageRating >= minRating.Value);

            // ----- Sorting -----
            switch (sortBy)
            {
                case "PriceLowToHigh": query = query.OrderBy(p => p.Price); break;
                case "PriceHighToLow": query = query.OrderByDescending(p => p.Price); break;
                case "Newest": query = query.OrderByDescending(p => p.CreatedDate); break;
                case "Rating": query = query.OrderByDescending(p => p.AverageRating); break;
                case "Alphabetical": query = query.OrderBy(p => p.ProductName); break;
                default: query = query.OrderByDescending(p => p.CreatedDate); break;
            }

            // ----- Pagination -----
            // Count() runs "SELECT COUNT(*)" with all filters already applied.
            int totalProducts = query.Count();
            int totalPages = (int)Math.Ceiling((double)totalProducts / PageSize);
            if (page < 1) page = 1;

            // Skip() jumps over products from earlier pages, Take() grabs only
            // this page's worth. SQL equivalent: OFFSET / FETCH NEXT.
            var pagedProducts = query.Skip((page - 1) * PageSize).Take(PageSize).ToList();

            var model = new ProductListViewModel
            {
                Products = pagedProducts,
                Categories = db.Categories.Where(c => c.IsActive == true).ToList(),
                SearchTerm = searchTerm,
                SelectedCategoryId = categoryId,
                MinPrice = minPrice,
                MaxPrice = maxPrice,
                Availability = availability,
                MinRating = minRating,
                SortBy = sortBy,
                CurrentPage = page,
                TotalPages = totalPages
            };

            return View(model);
        }

        // GET: Product/Details/5
        public ActionResult Details(int id)
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            ViewBag.ActiveMenu = "Products";

            var product = db.Products.FirstOrDefault(p => p.ProductId == id && p.IsActive == true);
            if (product == null)
            {
                return HttpNotFound("Product not found.");
            }

            // Related Products - other active products from the same category.
            ViewBag.RelatedProducts = db.Products
                .Where(p => p.CategoryId == product.CategoryId && p.ProductId != product.ProductId && p.IsActive == true)
                .Take(4)
                .ToList();

            ViewBag.Category = db.Categories.FirstOrDefault(c => c.CategoryId == product.CategoryId);

            return View(product);
        }
    }
}
