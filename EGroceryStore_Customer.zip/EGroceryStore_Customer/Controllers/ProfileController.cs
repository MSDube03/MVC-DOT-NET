using System.Linq;
using System.Web.Mvc;
using EGroceryStore.Helpers;
using EGroceryStore.Models;
using EGroceryStore.ViewModels;

namespace EGroceryStore.Controllers
{
    public class ProfileController : Controller
    {
        private GroceryDbEntities db = new GroceryDbEntities();

        // GET: Profile/Index
        public ActionResult Index()
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }
            int userId = SessionHelper.GetCurrentUserId(Session);

            var user = db.Users.FirstOrDefault(u => u.UserId == userId);
            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            return View(user);
        }

        // GET: Profile/Edit
        public ActionResult Edit()
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }
            int userId = SessionHelper.GetCurrentUserId(Session);

            var user = db.Users.FirstOrDefault(u => u.UserId == userId);
            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var model = new EditProfileViewModel
            {
                FirstName = user.FirstName,
                LastName = user.LastName,
                MobileNumber = user.MobileNumber
            };

            return View(model);
        }

        // POST: Profile/Edit
        [HttpPost]
        public ActionResult Edit(EditProfileViewModel model)
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            int userId = SessionHelper.GetCurrentUserId(Session);
            var user = db.Users.FirstOrDefault(u => u.UserId == userId);
            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            // Only these fields can be changed here. Email is intentionally
            // never touched - the customer is not allowed to change it.
            user.FirstName = model.FirstName;
            user.LastName = model.LastName;
            user.MobileNumber = model.MobileNumber;

            db.SaveChanges();

            // Keep the navbar's displayed name in sync with the new name.
            Session["UserName"] = user.FirstName + " " + user.LastName;

            TempData["SuccessMessage"] = "Profile updated successfully.";
            return RedirectToAction("Index");
        }

        // GET: Profile/ChangePassword
        public ActionResult ChangePassword()
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }
            return View();
        }

        // POST: Profile/ChangePassword
        [HttpPost]
        public ActionResult ChangePassword(ChangePasswordViewModel model)
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            int userId = SessionHelper.GetCurrentUserId(Session);
            var user = db.Users.FirstOrDefault(u => u.UserId == userId);
            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            // Verify the current password matches what's stored, before allowing a change.
            if (!PasswordHasher.VerifyText(model.CurrentPassword, user.PasswordHash))
            {
                ModelState.AddModelError("CurrentPassword", "Current password is incorrect.");
                return View(model);
            }

            user.PasswordHash = PasswordHasher.HashText(model.NewPassword);
            db.SaveChanges();

            TempData["SuccessMessage"] = "Password changed successfully. Please login again.";
            Session.Abandon();
            return RedirectToAction("Login", "Account");
        }
    }
}
