using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using EGroceryStore.Helpers;
using EGroceryStore.Models;
using EGroceryStore.ViewModels;

namespace EGroceryStore.Controllers
{
    public class WishlistController : Controller
    {
        private GroceryDbEntities db = new GroceryDbEntities();

        // GET: Wishlist/Index
        public ActionResult Index()
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }
            int userId = SessionHelper.GetCurrentUserId(Session);
            ViewBag.ActiveMenu = "Wishlist";

            var wishlistRows = db.Wishlist.Where(w => w.UserId == userId).ToList();

            // Wishlist only stores ProductId - we look up each product's display
            // details manually. Simple and explicit, and does not depend on
            // guessing EF navigation property names.
            var items = new List<WishlistItemViewModel>();
            foreach (var row in wishlistRows)
            {
                var product = db.Products.FirstOrDefault(p => p.ProductId == row.ProductId);
                if (product == null) continue; // product may have been removed/deactivated since

                items.Add(new WishlistItemViewModel
                {
                    WishlistId = row.WishlistId,
                    ProductId = product.ProductId,
                    ProductName = product.ProductName,
                    ImagePath = product.ImagePath,
                    Price = product.Price,
                    AverageRating = product.AverageRating,
                    StockQuantity = product.StockQuantity
                });
            }

            return View(items);
        }

        // POST: Wishlist/Add
        [HttpPost]
        public ActionResult Add(int productId)
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }
            int userId = SessionHelper.GetCurrentUserId(Session);

            bool alreadyExists = db.Wishlist.Any(w => w.UserId == userId && w.ProductId == productId);

            if (alreadyExists)
            {
                TempData["ErrorMessage"] = "Product already exists in Wishlist.";
            }
            else
            {
                db.Wishlist.Add(new Wishlist { UserId = userId, ProductId = productId, AddedDate = DateTime.Now });
                db.SaveChanges();
                TempData["SuccessMessage"] = "Product added to Wishlist.";
            }

            // Send the customer back to whichever page they clicked the heart icon on.
            return Redirect(Request.UrlReferrer != null ? Request.UrlReferrer.ToString() : Url.Action("Index", "Home"));
        }

        // POST: Wishlist/Remove
        [HttpPost]
        public ActionResult Remove(int wishlistId)
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }

            var item = db.Wishlist.FirstOrDefault(w => w.WishlistId == wishlistId);
            if (item != null)
            {
                db.Wishlist.Remove(item);
                db.SaveChanges();
                TempData["SuccessMessage"] = "Product removed from Wishlist.";
            }

            return RedirectToAction("Index");
        }

        // POST: Wishlist/MoveToCart
        [HttpPost]
        public ActionResult MoveToCart(int wishlistId, int productId)
        {
            if (!SessionHelper.IsCustomerLoggedIn(Session))
            {
                return RedirectToAction("Login", "Account");
            }
            int userId = SessionHelper.GetCurrentUserId(Session);

            // Step 1: Add to Cart (or increase quantity if already there).
            var existingCartItem = db.Cart.FirstOrDefault(c => c.UserId == userId && c.ProductId == productId);
            if (existingCartItem != null)
            {
                existingCartItem.Quantity += 1;
            }
            else
            {
                db.Cart.Add(new Cart { UserId = userId, ProductId = productId, Quantity = 1, AddedDate = DateTime.Now });
            }

            // Step 2: Remove from Wishlist.
            var wishlistItem = db.Wishlist.FirstOrDefault(w => w.WishlistId == wishlistId);
            if (wishlistItem != null)
            {
                db.Wishlist.Remove(wishlistItem);
            }

            db.SaveChanges();

            TempData["SuccessMessage"] = "Product moved to Cart.";
            return RedirectToAction("Index");
        }
    }
}
