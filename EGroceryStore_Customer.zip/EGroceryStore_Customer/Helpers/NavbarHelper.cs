using System.Linq;
using EGroceryStore.Models; // replace with your real EDMX models namespace

namespace EGroceryStore.Helpers
{
    /// <summary>
    /// Small reusable helper used by the shared Layout to show
    /// live Wishlist and Cart counts next to the icons in the navbar.
    /// We keep this separate from any Controller because the navbar
    /// is shared across every page - every Controller would otherwise
    /// need to repeat this same query.
    /// </summary>
    public static class NavbarHelper
    {
        /// <summary>
        /// Counts how many products this customer has saved in their Wishlist.
        /// </summary>
        public static int GetWishlistCount(int userId)
        {
            using (var db = new GroceryDbEntities())
            {
                // Count() with a condition = SQL: SELECT COUNT(*) FROM Wishlist WHERE UserId = @userId
                return db.Wishlist.Count(w => w.UserId == userId);
            }
        }

        /// <summary>
        /// Counts how many distinct products this customer currently has in their Cart.
        /// </summary>
        public static int GetCartCount(int userId)
        {
            using (var db = new GroceryDbEntities())
            {
                // SQL equivalent: SELECT COUNT(*) FROM Cart WHERE UserId = @userId
                return db.Cart.Count(c => c.UserId == userId);
            }
        }
    }
}
