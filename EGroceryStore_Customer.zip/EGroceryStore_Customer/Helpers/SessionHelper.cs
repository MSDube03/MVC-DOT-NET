using System;
using System.Web.SessionState;

namespace EGroceryStore.Helpers
{
    /// <summary>
    /// Every Customer page (Wishlist, Cart, Address, Checkout, Orders, Profile) must
    /// check "is someone logged in?" before doing anything. Instead of repeating the
    /// same 3 lines of Session-checking code inside 8 different Controllers, we write
    /// it once here and call it everywhere. This is a plain static helper class -
    /// NOT Dependency Injection, NOT a Service Layer - just a reusable method.
    /// Reused from the pattern established in the Authentication Module.
    /// </summary>
    public static class SessionHelper
    {
        /// <summary>
        /// Returns true if a customer is currently logged in
        /// (i.e. AccountController's Login action has set Session["UserId"]).
        /// </summary>
        public static bool IsCustomerLoggedIn(HttpSessionStateBase session)
        {
            return session["UserId"] != null;
        }

        /// <summary>
        /// Returns the logged-in customer's UserId.
        /// IMPORTANT: only call this AFTER checking IsCustomerLoggedIn() is true,
        /// otherwise this will throw an error because Session["UserId"] would be empty.
        /// </summary>
        public static int GetCurrentUserId(HttpSessionStateBase session)
        {
            return Convert.ToInt32(session["UserId"]);
        }

        /// <summary>
        /// Returns the logged-in customer's display name (set during Login).
        /// </summary>
        public static string GetCurrentUserName(HttpSessionStateBase session)
        {
            return session["UserName"] as string;
        }
    }
}
