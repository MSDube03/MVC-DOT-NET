# E-Grocery Store — Stage 2: Customer Module

This is the complete Customer Module: Home Dashboard, Categories, Products
(search/filter/sort/pagination), Product Details, Wishlist, Cart, Addresses,
Checkout, Coupons, Order Placement, Order History/Details, and Profile.
Everything reads and writes real data through Entity Framework — nothing
hardcoded.

**This package assumes the Authentication Module (Stage 1) is already
copied into your project and working** — Login, Register, Session creation,
and `Helpers/PasswordHasher.cs` must already exist. Stage 2 builds directly
on top of that; it does not duplicate or replace anything from it.

---

## 0. Exact order of steps, starting from where you are right now

1. Confirm Stage 1 is fully working first — you should be able to Register,
   Login, and see the (currently plain) Home page before touching anything
   here. If Login doesn't work yet, fix that before starting Stage 2.
2. Copy in the new folders/files from this package: `ViewModels/`,
   `Helpers/` (2 new files — see note below), `Controllers/` (8 new files),
   `Content/CSS/`, `Content/Images/`, and every folder under `Views/`.
3. Find & Replace `EGroceryStore` → your real project namespace across every
   `.cs` and `.cshtml` file you just copied in (Edit → Find and Replace →
   Replace in Files, scoped to Entire Solution).
4. Fix the EF context reference in every Controller — same two placeholders
   as Stage 1 (`EGroceryStore.Models` and `GroceryDbEntities`).
5. Build the solution (Ctrl+Shift+B). Fix any red errors now — see the
   Common Errors table near the bottom before asking for help elsewhere.
6. Replace `Views/Shared/_Layout.cshtml` — see
   `ExistingFileChanges/_Layout.cshtml.CHANGES.txt` for the exact steps.
   This is required; nothing will look right without it.
7. Build again. Should be clean now.
8. Run the project, log in as a customer, and walk the Testing Checklist
   below in order — Home → Categories → Products → Wishlist → Cart →
   Address → Checkout → Order History.

---

## 1. What's in this folder

```
EGroceryStore_Customer/
├── Controllers/
│   ├── HomeController.cs        Customer Dashboard
│   ├── CategoryController.cs    Category listing
│   ├── ProductController.cs     Search / Filter / Sort / Pagination / Details
│   ├── WishlistController.cs
│   ├── CartController.cs
│   ├── AddressController.cs
│   ├── OrderController.cs       Checkout / Coupon / Place Order / History / Details
│   └── ProfileController.cs
├── ViewModels/
│   ├── ProductListViewModel.cs
│   ├── AddressViewModel.cs
│   ├── EditProfileViewModel.cs
│   ├── ChangePasswordViewModel.cs
│   ├── CheckoutViewModel.cs
│   ├── CartItemViewModel.cs
│   ├── WishlistItemViewModel.cs
│   ├── OrderDetailsViewModel.cs
│   └── OrderDetailItemViewModel.cs
├── Helpers/
│   ├── NavbarHelper.cs           NEW — live Wishlist/Cart counts for the navbar
│   └── SessionHelper.cs          NEW — reused by every Controller below instead
│                                  of repeating "if (Session[...] == null)" checks
├── Views/
│   ├── Shared/_Layout.cshtml     Full replacement — see ExistingFileChanges/
│   ├── Shared/_ProductCard.cshtml  Reusable product card partial
│   ├── Home/Index.cshtml
│   ├── Category/Index.cshtml
│   ├── Product/List.cshtml, Details.cshtml
│   ├── Wishlist/Index.cshtml
│   ├── Cart/Index.cshtml
│   ├── Address/Index.cshtml, Add.cshtml, Edit.cshtml
│   ├── Order/Checkout.cshtml, Confirmation.cshtml, History.cshtml, Details.cshtml
│   └── Profile/Index.cshtml, Edit.cshtml, ChangePassword.cshtml
├── Content/
│   ├── CSS/Customer.css, Product.css, Cart.css, Order.css, Responsive.css
│   └── Images/Banners/ (5 placeholder banners), Categories/, Products/
├── ExistingFileChanges/
│   └── _Layout.cshtml.CHANGES.txt
└── README.md
```

## 2. Copying files into your real project

Same process as Stage 1:
1. Copy each folder's contents into the matching folder in your real
   project (create `ViewModels/` if Stage 1 didn't already leave one there).
2. `Helpers/NavbarHelper.cs` and `Helpers/SessionHelper.cs` are **new** —
   copy both in alongside your existing `Helpers/PasswordHasher.cs`.
3. Find & Replace `EGroceryStore` with your real namespace everywhere.
4. Fix `GroceryDbEntities` / `EGroceryStore.Models` in every new Controller,
   same as you did for `AccountController.cs` in Stage 1.

## 3. Why `SessionHelper` and `AddressViewModel` matter here

**`SessionHelper.cs`** — every single Customer page (Wishlist, Cart,
Address, Checkout, Orders, Profile) needs to check "is someone logged in?"
before doing anything. Instead of repeating the same 3 lines in 8 different
Controllers, that check lives in one place and every action calls
`SessionHelper.IsCustomerLoggedIn(Session)` / `SessionHelper.GetCurrentUserId(Session)`.
This is a plain static helper class — **not** Dependency Injection, **not**
a Service Layer — just a reusable method, matching your "no advanced
architecture" rule.

**`AddressViewModel.cs`** — the reason this exists instead of using the
`Adresses` EF entity directly in the Add/Edit forms: EF Database First
entities don't carry `[Required]`/validation attributes (those live in your
SQL Server column definitions, not in C#), so binding a form straight to
`Adresses` would give you no red validation messages at all. `AddressViewModel`
also deliberately leaves out `UserId` — the customer should never be able to
set that themselves via a hidden field (that would let someone edit another
customer's address). The Controller sets `UserId` itself, from `Session`,
after validation passes.

## 4. Key design decisions explained

**Search/Filter/Sort/Pagination in one Controller action (`ProductController.List`)** —
rather than four separate endpoints, everything lives in one action with
optional parameters. This mirrors how a real product listing page works
(one URL, many optional query-string filters) and avoids duplicating the
same "build a query" logic four times.

**`GroupBy` for Best Selling Products** — `OrderDetails.GroupBy(od => od.ProductId)`
groups every order line by product, then `.Sum(x => x.Quantity)` adds up
how many units of each product were actually sold across every order ever
placed. This is real sales data, not a guess.

**`Skip()` / `Take()` for Pagination** — `Skip((page - 1) * PageSize)` jumps
over products from earlier pages, `Take(PageSize)` grabs only the current
page's worth. SQL Server equivalent: `OFFSET ... FETCH NEXT ... ROWS ONLY`.

**Manual `foreach` lookups instead of EF navigation properties** — `Cart`,
`Wishlist`, and `OrderDetails` only store `ProductId`, not the product's
name/price/image. Rather than relying on EF-generated navigation properties
(whose exact names can vary depending on how your specific EDMX was
generated), every Controller manually looks up the matching `Products` row
with `db.Products.FirstOrDefault(p => p.ProductId == row.ProductId)`. It's a
few more lines, but it's explicit, always works regardless of your EDMX's
naming, and is easy to explain during evaluation.

**Coupon stored in `Session`, not the database, during Checkout** — your
schema has no "cart-level discount" or reset-token-style table, and adding
one would violate the "don't modify the database" rule. So the applied
coupon code and discount amount live in `Session["AppliedCouponCode"]` /
`Session["AppliedDiscount"]` only while the customer is on the Checkout
page, and are cleared the moment the order is placed (or if they remove it).

**Order Number generation** — `"ORD" + DateTime.Now.ToString("yyyyMMddHHmmss")`.
Unique enough for a trainee-level project without needing a database
sequence, GUID, or any advanced concept.

**Active menu highlighting** — each Controller action sets
`ViewBag.ActiveMenu = "Products";` (etc.) before returning its View.
`_Layout.cshtml` checks that value on every navbar link and adds the
`active` CSS class when it matches. No routing magic, no filters — just a
ViewBag value your Controller sets and your Layout reads.

**⚠ Advanced Concept — deliberately NOT used:** live-updating navbar counts
via AJAX every time you Add to Cart/Wishlist. A normal full-page redirect
after every Add/Remove action already refreshes the whole page (and
therefore the navbar) automatically, so the counts stay correct with zero
extra JavaScript. This is simpler and easier for you to explain than
wiring up AJAX + a JSON endpoint, and your brief says to avoid AJAX unless
absolutely necessary.

**Payment methods** — Cash On Delivery, UPI, Debit Card, Credit Card,
Internet Banking are shown as radio buttons and the chosen value is simply
saved into `Orders.PaymentMethod`. There is no real payment gateway
integration — `PaymentStatus` is always set to `"Pending"` when an order is
placed, exactly as instructed for a trainee-level implementation.

## 5. Images — read this before you run the project

No internet access was available while generating this package, so real
photographs could not be included. Instead:
- `Content/Images/Banners/` contains 5 simple colored placeholder SVG
  banners (`banner-fruits.svg`, `banner-vegetables.svg`, `banner-organic.svg`,
  `banner-dairy.svg`, `banner-essentials.svg`) so the carousel works
  out of the box. **Replace these with real photos** before your evaluation
  — same filenames, or update the `<img src="...">` paths in `Home/Index.cshtml`.
- `Content/Images/Categories/` and `Content/Images/Products/` each contain
  one `placeholder.svg` only. Your actual Category/Product images are
  **data-driven** — whatever filename is stored in the `ImagePath` column
  for each row is what the page will try to load from these folders. Until
  you upload real images with matching filenames, you'll see a broken image
  icon for each category/product — **this is expected, not a bug.**
  Naming convention: save the file with the exact same text that's stored
  in that row's `ImagePath` column (e.g. if `ImagePath = "apple.jpg"` for a
  product, save your image as `Content/Images/Products/apple.jpg`).

## 6. Testing checklist (test in this order)

1. **Home** — log in, confirm you land on the Dashboard (not directly on
   Products). Carousel auto-rotates, Categories/Featured/Recent/Best
   Selling sections show real data (empty sections are fine if you have no
   Products/Orders yet).
2. **Categories** — click a category card → opens Product List filtered to
   that category only.
3. **Search** — type a product or category name in the navbar search box →
   confirm only matching products show.
4. **Filters/Sort/Pagination** — try Price Range, Availability, Rating, and
   each Sort option; add enough products (9+) to confirm pagination links
   appear and work.
5. **Product Details** — click a product → confirm price/stock/rating show
   correctly, Related Products appears, Add to Cart and Add to Wishlist
   both work.
6. **Wishlist** — add a product twice → second attempt shows "already
   exists" message, not a duplicate row. Move to Cart removes it from
   Wishlist and adds it to Cart.
7. **Cart** — increase/decrease quantity, confirm it never exceeds stock or
   goes below 1 (drops to Remove instead of 0), confirm Grand Total updates.
8. **Address** — add your first address → confirm it's automatically
   Default. Add a second and mark it Default → confirm the first one loses
   Default status automatically.
9. **Checkout → Coupon** — apply a valid, active, non-expired coupon (check
   your `Coupon` table) → confirm discount shows in the summary. Try an
   invalid/expired code → confirm the correct error message.
10. **Place Order** — confirm stock reduces on the Products table, Cart
    empties, and you land on Order Confirmation with correct totals.
11. **Order History / Details** — confirm the new order appears, and
    "View Details" shows the same information as the Confirmation page did.
12. **Profile** — edit name/mobile (confirm Email field is not editable),
    then Change Password, confirm you're logged out and can log back in
    with the new password.

## 7. Common errors

| Error | Cause | Fix |
|---|---|---|
| `The type or namespace 'X' could not be found` | Namespace not replaced in a copied file | Re-run Find & Replace across the whole solution |
| `'GroceryDbEntities' does not contain a definition for 'Adresses'` | Your DbSet property has a different name | Open your `.Context.cs` file, check the exact property name, update the Controller |
| Category/Product images show broken icon | Expected — see Section 5 above | Upload real images with filenames matching each row's `ImagePath` |
| `AverageRating` compile error (`.HasValue`/`.Value` not found) | Your `AverageRating` column is a non-nullable type in your EDMX | Remove `.HasValue`/`.Value` calls in `_ProductCard.cshtml` and `Product/Details.cshtml`, use the value directly |
| Filters/Sort reset when you click a pagination page number | A filter dropdown's `name` attribute doesn't match the Controller's parameter name | Check `Product/List.cshtml` input `name="..."` attributes match `ProductController.List(...)` parameters exactly |
| Checkout page shows "no addresses" even after adding one | Address was added under a different `UserId` (e.g. you logged in as a different test account) | Confirm `Session["UserId"]` matches the address's `UserId` in your database |
| "Place Order" button does nothing | Browser doesn't support the HTML5 `form="placeOrderForm"` button attribute (rare, older browsers only) | Move the `<button type="submit">` physically inside the `@using (Html.BeginForm(...))` block in `Order/Checkout.cshtml` instead of using the `form` attribute |

## 8. Known Stage-2 simplifications (flag these if asked during evaluation)

- **Coupon is applied per-checkout-session (via `Session`), not stored
  against the Cart in the database** — your schema has no table for this,
  and adding one would violate "don't modify the database."
- **`Orders.DeliveryAdress` stores the address as one denormalized text
  string** at the moment of order placement, rather than a foreign key to
  `Adresses` — this matches your schema exactly (`DeliveryAdress` is a
  single column, not a relationship), and has the side benefit that the
  order's delivery address stays correct even if the customer edits or
  deletes that saved address later.
- **No real payment gateway** — `PaymentStatus` is always `"Pending"` after
  placing an order; a production system would update it via a payment
  provider's webhook.
- **Navbar Cart count shows distinct products, not total quantity** — e.g.
  3 different products in cart shows "3", even if quantities add up to 10.
  Easy one-line change in `NavbarHelper.GetCartCount` if you'd rather show
  total quantity — see the comment in that file.

---

**Next step (Stage 3):** Admin Module — Category/Product management, Order
status updates, Coupon management, and the Admin Dashboard. Say the word
when you're ready.
