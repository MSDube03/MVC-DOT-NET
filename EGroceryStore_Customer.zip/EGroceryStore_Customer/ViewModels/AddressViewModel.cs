using System.ComponentModel.DataAnnotations;

namespace EGroceryStore.ViewModels
{
    // WHY THIS VIEWMODEL IS NEEDED (instead of using the "Adresses" EF entity directly):
    // The EF entity generated from your EDMX does not automatically carry
    // [Required] / validation rules that MVC can check - those come from
    // your SQL Server column definitions, not from C# attributes. Also, the
    // Adresses table has AdressId and UserId columns which the customer should
    // NEVER be able to set themselves through a form (that would let someone
    // edit another customer's address just by changing a hidden field).
    // This ViewModel only exposes exactly the fields the customer should fill in.
    public class AddressViewModel
    {
        // 0 when adding a new address. Set to the real AdressId when editing.
        public int AdressId { get; set; }

        [Required(ErrorMessage = "Full name is required")]
        [StringLength(100)]
        public string FullName { get; set; }

        [Required(ErrorMessage = "Mobile number is required")]
        [RegularExpression(@"^\d{10}$", ErrorMessage = "Mobile number must be exactly 10 digits")]
        public string MobileNumber { get; set; }

        [Required(ErrorMessage = "Address line 1 is required")]
        [StringLength(200)]
        public string AdressLine1 { get; set; }

        [StringLength(200)]
        public string AdressLine2 { get; set; }

        [StringLength(100)]
        public string Landmark { get; set; }

        [Required(ErrorMessage = "City is required")]
        [StringLength(50)]
        public string City { get; set; }

        [Required(ErrorMessage = "State is required")]
        [StringLength(50)]
        public string State { get; set; }

        [Required(ErrorMessage = "Pincode is required")]
        [RegularExpression(@"^\d{6}$", ErrorMessage = "Pincode must be exactly 6 digits")]
        public string Pincode { get; set; }

        [Required(ErrorMessage = "Please select an address type")]
        public string AdressType { get; set; } // "Home", "Work", "Other"

        public bool IsDefault { get; set; }
    }
}
