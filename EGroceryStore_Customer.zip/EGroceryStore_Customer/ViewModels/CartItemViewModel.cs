namespace EGroceryStore.ViewModels
{
    // Combines a Cart row with the Product details needed to display it -
    // the Cart table itself only stores ProductId, not name/price/image.
    public class CartItemViewModel
    {
        public int CartId { get; set; }
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string ImagePath { get; set; }
        public decimal Price { get; set; }
        public int Quantity { get; set; }
        public int StockQuantity { get; set; }
        public decimal Subtotal { get; set; }
    }
}
