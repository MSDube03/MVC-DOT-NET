using System.Collections.Generic;
using EGroceryStore.Models;

namespace EGroceryStore.ViewModels
{
    public class CheckoutViewModel
    {
        public List<CartItemViewModel> CartItems { get; set; }
        public List<Adresses> Addresses { get; set; }
        public int SelectedAddressId { get; set; }
        public string CouponCode { get; set; }
        public decimal Discount { get; set; }
        public decimal Subtotal { get; set; }
        public decimal GrandTotal { get; set; }
    }
}
