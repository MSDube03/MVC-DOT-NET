using System.ComponentModel.DataAnnotations;

namespace EGroceryStore.ViewModels
{
    // "Safe form" for Edit Profile - only fields the customer is allowed to change.
    // Email, Role, IsActive, PasswordHash stay untouched on the real Users entity.
    public class EditProfileViewModel
    {
        [Required(ErrorMessage = "First name is required")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Last name is required")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Mobile number is required")]
        [RegularExpression(@"^\d{10}$", ErrorMessage = "Mobile number must be exactly 10 digits")]
        public string MobileNumber { get; set; }
    }
}
