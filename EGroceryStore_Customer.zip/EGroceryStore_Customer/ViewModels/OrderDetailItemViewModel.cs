namespace EGroceryStore.ViewModels
{
    public class OrderDetailItemViewModel
    {
        public string ProductName { get; set; }
        public string ImagePath { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
        public decimal SubTotal { get; set; }
    }
}
