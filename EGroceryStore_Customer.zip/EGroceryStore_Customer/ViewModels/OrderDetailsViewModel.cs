using System;
using System.Collections.Generic;

namespace EGroceryStore.ViewModels
{
    public class OrderDetailsViewModel
    {
        public int OrderId { get; set; }
        public string OrderNumber { get; set; }
        public DateTime OrderDate { get; set; }
        public string DeliveryAdress { get; set; }
        public string PaymentMethod { get; set; }
        public string OrderStatus { get; set; }
        public string PaymentStatus { get; set; }
        public decimal TotalAmount { get; set; }
        public List<OrderDetailItemViewModel> Items { get; set; }
    }
}
