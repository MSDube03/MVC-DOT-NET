using System.Collections.Generic;
using EGroceryStore.Models;

namespace EGroceryStore.ViewModels
{
    // Carries the product list AND the current filter/sort/page values together,
    // so the Product List view can re-display exactly what the customer selected.
    public class ProductListViewModel
    {
        public List<Products> Products { get; set; }
        public List<Categories> Categories { get; set; }

        public string SearchTerm { get; set; }
        public int? SelectedCategoryId { get; set; }
        public decimal? MinPrice { get; set; }
        public decimal? MaxPrice { get; set; }
        public string Availability { get; set; }
        public int? MinRating { get; set; }
        public string SortBy { get; set; }

        public int CurrentPage { get; set; }
        public int TotalPages { get; set; }
    }
}
