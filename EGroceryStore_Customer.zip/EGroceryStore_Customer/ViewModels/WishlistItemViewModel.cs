namespace EGroceryStore.ViewModels
{
    public class WishlistItemViewModel
    {
        public int WishlistId { get; set; }
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string ImagePath { get; set; }
        public decimal Price { get; set; }
        public decimal? AverageRating { get; set; }
        public int StockQuantity { get; set; }
    }
}
