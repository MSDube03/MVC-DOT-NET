# EGrocery — Home Page (CORRECTED — matches actual HomeController)

Yeh pichle "Home Page" fix ko poori tarah **replace** karta hai. Ab
`@model` bilkul nahi hai — seedha `ViewBag` se data aata hai, exactly
jaisa tumhare `HomeController.Index()` mein likha hai (screenshot se
confirm kiya).

**Zero Controller change** — is baar sach mein zero, kyunki Controller
already sab kuch de raha hai jo chahiye.

---

## Confirmed field names (screenshot se)

| ViewBag Property | Kya hai |
|---|---|
| `ViewBag.Categories` | `List<Category>` |
| `ViewBag.FeaturedProducts` | `List<Product>` — highest rated |
| `ViewBag.RecentProducts` | `List<Product>` — newest pehle |
| `ViewBag.BestSellingProducts` | `List<Product>` — sabse zyada bike hue |
| `ViewBag.ActiveCoupons` | `List<Coupon>` |
| **Banners** | **Exist hi nahi karta** — banner images static files hain, database se nahi aatin |

---

## ⚠️ Do cheezein verify karni hain, apply karne se pehle

### 1. Banner image file ka extension — `.jpg` ya `.svg`?

Bahut pehle humne 5 static banner files banayi thi (`banner-fruits`,
`banner-vegetables`, `banner-organic`, `banner-dairy`, `banner-essentials`)
`.svg` format mein, phir tumne real photos se replace karne ka plan
banaya tha (`.jpg` mein) — lekin confirm nahi hai ki woh step complete
hua ya nahi.

**Maine `.jpg` maan ke likha hai.** Agar tumhare `Content/Images/Banners/`
folder mein abhi bhi `.svg` files hain (`.jpg` nahi), toh Home page pe
banner **broken image icon** dikhega.

**Turant check karo:** Solution Explorer mein `Content/Images/Banners/`
folder kholo, dekho files ka extension kya hai. Agar `.svg` hai, Ctrl+H
(Find & Replace) se is `Home/Index.cshtml` file mein `.jpg` ko `.svg` se
badal do (5 jagah).

### 2. `_ProductCard.cshtml` ko raw `Product` chahiye ya ViewModel?

`FeaturedProducts` wagera `List<Product>` hain (raw database entity,
ViewModel nahi). Maine seedha `Product` object `_ProductCard.cshtml`
partial ko pass kiya hai. Agar tumhara `_ProductCard.cshtml` `@model
EGroceryStore.Models.Product` expect karta hai, sab sahi chalega. Agar
woh kisi ViewModel (jaise `ProductCardViewModel`) ki expect karta hai,
error aayega — **turant `_ProductCard.cshtml` ki pehli line bhej dena**
(`@model ...` wali line), main 1-second mein confirm kar dunga.

---

## Execution Steps

1. `Views/Home/Index.cshtml` — replace
2. Upar diye dono points check karo
3. Rebuild, run

## Testing Checklist

1. `/Home/Index` kholo — koi error na aaye (yeh sabse important hai)
2. Banner carousel dikhe, images poori (broken icon na ho)
3. Sidebar mein categories dikhein
4. Shop by Category icons dikhein
5. Agar koi active coupon hai, Special Offers bar dikhe
6. Featured / Recently Added / Best Selling — teeno sections products
   ke saath dikhein

Agar koi error aaye, uska **poora exact text** copy-paste kar dena
(screenshot ya text dono chalega) — is baar bahut kareeb pahunch gaye
hain sahi cheez tak.
