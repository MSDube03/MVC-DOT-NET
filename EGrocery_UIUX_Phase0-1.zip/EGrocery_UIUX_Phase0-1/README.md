# EGrocery UI/UX Transformation — Phase 0 (Foundation) + Phase 1 (Auth Pages)

Per your instructions, **stopping here for review** — Phase 2 (Customer
Module) will not begin until Phase 1 is approved.

**Nothing in this package touches a Controller's business logic, the
database, the `.edmx`, or Entity Framework mappings.** The only C# file
included is a tiny, presentation-only `EmptyStateViewModel` (5 string
properties, no database access) used purely to feed the reusable empty-
state partial.

---

## 1. New Files

| File | Folder | Purpose |
|---|---|---|
| `variables.css` | `Content/CSS/` | Design tokens — every color/spacing/radius/shadow used anywhere |
| `typography.css` | `Content/CSS/` | Heading font (Poppins) + body font (system stack) |
| `utilities.css` | `Content/CSS/` | Spacing/text utility classes from the spacing scale |
| `buttons.css` | `Content/CSS/` | Branded button styles, additive to existing Bootstrap classes |
| `cards.css` | `Content/CSS/` | Card component + badges + empty-state styling |
| `forms.css` | `Content/CSS/` | Floating labels, input icons, password toggle, strength meter |
| `navbar.css` | `Content/CSS/` | Base navbar tokens (full redesign is Phase 2) |
| `footer.css` | `Content/CSS/` | Ties existing footer color to the shared secondary token |
| `tables.css` | `Content/CSS/` | Admin table refinement (used starting Phase 3) |
| `modal.css` | `Content/CSS/` | Bootstrap 3 modal visual refinement |
| `animations.css` | `Content/CSS/` | Simple fade/slide-in keyframes |
| `ui-responsive.css` | `Content/CSS/` | Shared responsive helpers — **not** named `responsive.css`, see Section 4 |
| `auth.css` | `Content/CSS/` | Phase 1 — Auth card/wrapper/brand styling |
| `Site.css` | `Content/` | **Replaces** existing default MVC boilerplate — see Section 4 |
| `auth.js` | `Scripts/Custom/` | Password show/hide toggle + strength meter (vanilla JS) |
| `_AuthLayout.cshtml` | `Views/Shared/` | New minimal, centered, branded layout for all 5 Auth pages |
| `_EmptyState.cshtml` | `Views/Shared/` | Reusable empty-state partial (Phase 2/3 will use this too) |
| `EmptyStateViewModel.cs` | `ViewModels/` | Presentation-only data carrier for the partial above |

## 2. Existing Files Modified

| File | What changed | Why |
|---|---|---|
| `Views/Shared/_Layout.cshtml` | Added new CSS links + Bootstrap Icons CDN; restyled the TempData alert block | Foundation wiring + consistent alert look. Navbar/footer HTML untouched — Phase 2 |
| `Views/Shared/_AdminLayout.cshtml` | Same — new CSS links + Icons CDN | Same reasoning. Sidebar HTML untouched — Phase 3 |
| `Views/Shared/_AdminAlerts.cshtml` | Restyled with icons + new classes | Matches the new alert look everywhere, logic (`TempData` checks) unchanged |
| `Views/Account/Login.cshtml` | **Complete redesign** | Card via `_AuthLayout`, icon-in-input fields, password show/hide |
| `Views/Account/Register.cshtml` | **Complete redesign** | Card, floating labels, password strength meter, styled dropdown |
| `Views/Account/ForgotPassword.cshtml` | **Complete redesign** | Card, branding, back-to-login link |
| `Views/Account/VerifySecurityAnswer.cshtml` | **Complete redesign** | Card, consistent styling with the rest of Auth |
| `Views/Account/ResetPassword.cshtml` | **Complete redesign** | Card, password toggle + strength meter |

Exact Old Code / New Code / paste location for every existing-file change
is in `ExistingFileChanges/` — one `.txt` per file, per your File
Generation Rule.

---

## 3. Execution Guide

**Step 1 — Foundation CSS/JS**
Copy all 14 new `Content/CSS/*` and `Content/`/`Scripts/Custom/*` files
into your project's matching folders.
Build (Ctrl+Shift+B) — should still succeed, nothing references them yet.

**Step 2 — Reusable partial + ViewModel**
Copy `Views/Shared/_EmptyState.cshtml` and `ViewModels/EmptyStateViewModel.cs`
in. Not called from anywhere yet in this Phase (it will be, in Phase 2/3) —
this just makes it available.

**Step 3 — New Auth Layout**
Copy `Views/Shared/_AuthLayout.cshtml` in.

**Step 4 — Apply the 3 existing-file changes**
Apply `_Layout.cshtml`, `_AdminLayout.cshtml`, and `_AdminAlerts.cshtml`
changes from `ExistingFileChanges/`, in that order. Build again.

**Step 5 — Replace the 5 Auth views**
Copy in `Login.cshtml`, `Register.cshtml`, `ForgotPassword.cshtml`,
`VerifySecurityAnswer.cshtml`, `ResetPassword.cshtml` — full replacements
of what's in `Views/Account/` today.

**Step 6 — Build and run**
Ctrl+Shift+B, then F5. Navigate to `/Account/Login` first.

---

## 4. Naming & Collision Notes (read before copying files in)

- **`ui-responsive.css`**, not `responsive.css` — your Customer Module
  already has `Content/CSS/Responsive.css` from Stage 2. Windows treats
  filenames as case-insensitive, so a new lowercase `responsive.css`
  would silently overwrite it. Same reasoning as `AdminProduct.css` vs
  `Product.css` earlier in this project.
- **`Content/Site.css`** — this file already exists in your project as
  unused default MVC 5 template boilerplate (Visual Studio creates it
  automatically and it's typically empty or near-empty). We are
  intentionally replacing its content — there was nothing of yours in it.
- **CSS link order matters** — in both Layout changes, the new
  `variables.css`/`typography.css`/etc. files are linked **before** your
  existing `Customer.css`/`Admin.css`/etc. This isn't arbitrary: once
  Phase 2/3 restyle those existing files to use `var(--color-primary)`
  and similar tokens, those tokens need to already be defined by the time
  the browser reads them.

## 5. Techniques Used Beyond Basic Bootstrap (per your reminder in Section 0.4)

**CSS Custom Properties (`--variable-name`, `var(...)`)** — a native CSS
feature, not Bootstrap. Lets every color/spacing value be defined once in
`variables.css` and reused everywhere via `var(--color-primary)`, so
changing the brand color later means editing one line, not hunting
through a dozen files. **Optional** — the simpler alternative is retyping
the hex code everywhere; more typing, harder to maintain, but zero new
syntax.

**CSS Floating Labels** (`forms.css`) — the label sits inside the input
like a placeholder, then animates up once you focus or fill the field.
Built with the CSS `:not(:placeholder-shown)` selector, not JavaScript —
requires every input to have `placeholder=" "` (a single space) and the
`<label>` to come **after** the input in the HTML (CSS can't select a
previous sibling). **Optional and fully explained inline in `forms.css`** —
skip the `eg-form-group` wrapper class and use a plain label-above-input
`form-group` instead for the simpler, non-animated version (exactly like
Stage 1's original Register page).

**Password Strength Meter** (`auth.js`) — a small vanilla JS function that
checks length + character variety and colors a bar accordingly. This is a
friendly visual nudge only — the actual required rule (6+ characters,
enforced via `[StringLength]` on the ViewModel) is unchanged and still
does the real server-side validation.

**CSS `@keyframes` animations** (`animations.css`) — smooth fade/slide-in
on cards and alerts when they appear. **Optional** — don't add the
`eg-animate-in` class and elements appear instantly, equally correct.

**Bootstrap Icons via CDN** — one `<link>` tag, class-based icons
(`<i class="bi bi-cart"></i>`), no JavaScript, no build step. Chosen over
Font Awesome specifically because it needs the least setup for a beginner
project — Font Awesome's free tier typically wants a JS kit or a more
involved integration.

---

## 6. Testing Checklist — Phase 0 + Phase 1

**Validation (unchanged logic, confirm it still works):**
1. Login with wrong password → red error message shows, styled correctly
2. Register with a duplicate email → error shows under the Email field
3. Register with mismatched passwords → Compare validation fires
4. Forgot Password → wrong/nonexistent email → error shows
5. Security Question → wrong answer → error shows
6. Reset Password → mismatched confirm → error shows

**New visual/interactive behavior:**
7. Every Auth page shows the EGrocery logo + tagline centered above the card
8. Labels float up smoothly when you click into or fill any text field
9. Password fields: clicking the eye icon toggles between hidden/visible text
10. Register + Reset Password: typing a password moves the strength bar
    and updates the Weak/Medium/Strong label live as you type
11. Security Question page shows the actual question in a highlighted box,
    not just plain text
12. Every page has a working "Back to Login" or "Create an account" link

**Responsive (resize the browser, or use DevTools device toolbar):**
13. Auth card stays centered and readable at 375px (phone), 768px
    (tablet), and 1200px+ (desktop) widths
14. First Name / Last Name fields stack full-width below ~480px instead
    of staying cramped side-by-side

**Cross-page consistency:**
15. All 5 Auth pages use the exact same card shadow, radius, and button style
16. Success/Error alerts (Customer `_Layout.cshtml` and Admin
    `_AdminAlerts.cshtml`) now show an icon and match the Auth pages' alert style
17. Existing Customer Home, Cart, Wishlist, etc. pages still render
    normally — Phase 0's Layout changes were link-only, no structural change

**Hover/animation states:**
18. Buttons lift slightly and darken on hover
19. Cards/alerts fade in smoothly on page load (not an abrupt pop-in)

---

## 7. What's Deliberately NOT Done Yet (by design, not oversight)

- Customer navbar redesign (icons, cart/wishlist badges, sticky behavior,
  hamburger menu) — **Phase 2**
- Home page hero/category/product section redesign, replacing the literal
  placeholder banner text — **Phase 2**
- Admin sidebar, Dashboard stat cards, Category/Product filter toolbars —
  **Phase 3**
- Wiring `_EmptyState.cshtml` into any actual page (Wishlist, Cart,
  Orders, Admin lists) — **Phase 2/3**, the partial exists now but nothing
  calls it yet

Waiting for your review before starting Phase 2.
