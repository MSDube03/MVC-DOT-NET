// =========================================================
// Auth pages - password show/hide toggle + password strength
// meter. Plain vanilla JavaScript, no jQuery plugin, no
// library. These two small functions are called directly from
// onclick/oninput attributes in the Auth Views - see Login.cshtml,
// Register.cshtml, and ResetPassword.cshtml for usage.
// =========================================================

// Toggles a password field between hidden (dots) and visible
// (plain text), and swaps the eye icon to match.
function egTogglePassword(inputId, iconId) {
    var input = document.getElementById(inputId);
    var icon = document.getElementById(iconId);
    if (!input || !icon) return;

    if (input.type === "password") {
        input.type = "text";
        icon.classList.remove("bi-eye");
        icon.classList.add("bi-eye-slash");
    } else {
        input.type = "password";
        icon.classList.remove("bi-eye-slash");
        icon.classList.add("bi-eye");
    }
}

// Very simple password strength check - counts how many of these
// 4 things are true: length >= 8, has a lowercase letter, has an
// uppercase letter OR a number, has a special character. This is
// NOT a cryptographic strength calculation, just a friendly visual
// nudge for the user - the real, required rule (minimum 6
// characters) is still enforced separately server-side via the
// [StringLength] Data Annotation on the ViewModel, same as before.
function egCheckPasswordStrength(inputId, fillId, labelId) {
    var input = document.getElementById(inputId);
    var fill = document.getElementById(fillId);
    var label = document.getElementById(labelId);
    if (!input || !fill || !label) return;

    var value = input.value;
    var score = 0;

    if (value.length >= 8) score++;
    if (/[a-z]/.test(value)) score++;
    if (/[A-Z]/.test(value) || /[0-9]/.test(value)) score++;
    if (/[^A-Za-z0-9]/.test(value)) score++;

    var percent = (score / 4) * 100;
    var color = "#C94F4F"; // danger - weak
    var text = "Weak";

    if (value.length === 0) {
        percent = 0;
        text = "";
    } else if (score >= 4) {
        color = "#1B7A43"; // strong
        text = "Strong";
    } else if (score >= 2) {
        color = "#D9A441"; // medium
        text = "Medium";
    }

    fill.style.width = percent + "%";
    fill.style.backgroundColor = color;
    label.textContent = text;
}
