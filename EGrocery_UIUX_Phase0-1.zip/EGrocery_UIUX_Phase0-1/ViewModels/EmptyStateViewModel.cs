namespace EGroceryStore.ViewModels
{
    // Presentation-only data carrier for the reusable _EmptyState.cshtml
    // partial - no business logic, no database access. Used wherever a
    // list page needs to show "nothing here yet" (Wishlist, Cart, Orders,
    // Admin Categories, Admin Products, and any future empty list) with
    // one consistent look instead of a plain text sentence.
    public class EmptyStateViewModel
    {
        // A Bootstrap Icons class name, e.g. "bi-cart-x" - see
        // https://icons.getbootstrap.com for the full icon list.
        public string IconClass { get; set; }

        public string Title { get; set; }
        public string Message { get; set; }

        // Both optional - if ActionUrl is left null/empty, no button renders.
        public string ActionText { get; set; }
        public string ActionUrl { get; set; }
    }
}
