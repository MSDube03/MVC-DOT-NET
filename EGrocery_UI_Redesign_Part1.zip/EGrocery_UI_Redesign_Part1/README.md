# EGrocery UI Redesign — Part 1: Header, Footer, Buttons

Poori site pe impact karne wala hissa — sabse pehle isliye kiya, kyunki
har page isi Layout ko use karta hai.

**Zero Controller change. Zero database change. Zero functionality change.**
Sirf `_Layout.cshtml` ka structure aur `Customer.css` mein naya CSS block —
sab links, sab actions, sab checks pehle jaise hi hain.

---

## Is Part mein kya hai

| File | Type | Kya kiya |
|---|---|---|
| `Views/Shared/_Layout.cshtml` | **Poori file replace** | Header 2 rows mein: (1) Logo + centered search + user dropdown, (2) Category/page links bar niche. Footer ab "sticky" (page chhoti ho toh bhi bottom pe rahega). Wishlist/Cart ab icon-pill ke roop mein dikhte hain (❤ 2, 🛒 1 jaisa), text-wale links ki jagah. |
| `Content/CSS/Customer.css` | **Sirf ADD karna hai end mein** (`ExistingFileChanges/Customer.css.CHANGES.txt` dekho) | Sticky footer ka CSS, header ki nayi styling, aur **har button pe hover effect** (halka upar uthna + shadow) — poori site mein consistent |

---

## Execution Steps

1. `Views/Shared/_Layout.cshtml` — poori file isi zip ki file se **replace** karo
2. `Content/CSS/Customer.css` — apni existing file kholo, `ExistingFileChanges/Customer.css.CHANGES.txt` mein diya hua poora block copy karke **file ke bilkul end mein paste** karo (upar wala kuch delete mat karna)
3. Rebuild (Ctrl+Shift+B)
4. Run (F5), koi bhi Customer page kholo

## Testing Checklist

1. Login karke Home page kholo — header 2 rows mein dikhna chahiye: upar logo+search+account, niche Home/Categories/Products/Orders/Addresses
2. Search box **center mein** hona chahiye (desktop screen pe)
3. Wishlist/Cart mein kuch add karo — icon ke paas number turant update hona chahiye
4. Kisi bhi chhoti page (jaise Login ya khaali Cart) pe jao — **footer neeche hi rahe**, beech screen mein floating na dikhe
5. Kisi bhi button pe mouse le jao (Add to Cart, Login, wagera) — halka upar uthega + shadow aayega
6. Phone-width pe browser resize karo — hamburger menu se navbar khulna chahiye jaisa pehle khulta tha

---

## ⚠️ Pending — tumhare jawab ka wait hai

**My Profile → Edit / Change Password ko "modal" banana hai** — maine 2 tareeke bataye the:
- **(A)** Real popup (Bootstrap Modal — page change nahi hota, box upar khulta hai)
- **(B)** Register jaisa chhota compact page (naya page, lekin chhota/centered)

Jab tak yeh confirm nahi hota, main is hisse pe kaam start nahi karunga — galat guess karne se dobara kaam karna padega.

## Aage kya baaki hai (agle Parts mein aayega)

Yeh sab tumhare original message mein maanga gaya tha, abhi tak nahi kiya:

1. **Home page** — sab ek screen mein fit ho, "Special Offers" highlight ho, sidebar-jaisi category list (reference image ke structure jaisi)
2. **Product List page** — filters ko proper styled boxes mein daalna, Rating filter hatana, duplicate search box hatana
3. **Wishlist page** — cards ko Product card jaisa hi chhota/consistent banana
4. **Profile Edit/Change Password** — modal (jaise upar confirm hoga)
5. **Admin Dashboard** — declutter karna, sirf important cheezein, ek screen mein fit
6. **Admin Product/Category** — pagination lagana
7. **Admin filters** — proper styling, unnecessary filters hatana
8. **Admin Reports** — sirf 2-3 sabse relevant stats rakhna, ek page mein fit

**In sab ko main alag-alag chhote Parts mein karunga** (jaise poore project mein humesha kiya hai) — ek saath sab kar diya toh galti hone ka risk zyada hota hai, aur tumne khud kaha tha "functionality 0.1% bhi na tootey."

**Modal wala jawab (A ya B) de do, phir agla Part shuru karta hoon.**
