# EGrocery UI Redesign — Part 2: Profile Edit + Change Password as Modals

**Zero Controller change. Zero ViewModel change. Zero functionality change.**
`Edit` aur `ChangePassword` — dono POST actions bilkul waise hi hain jaise
pehle the. Sirf form ab ek popup (Bootstrap Modal) ke andar hai, alag page
pe navigate nahi karta.

---

## Execution Steps

1. `Views/Profile/Index.cshtml` — poori file isse **replace** karo
2. Rebuild (Ctrl+Shift+B)
3. Run, `/Profile/Index` kholo

**Note:** `Views/Profile/Edit.cshtml` aur `Views/Profile/ChangePassword.cshtml`
files ko **delete mat karna** — agar kabhi validation fail ho aur koi edge
case ho jahan modal na khule, yeh dono ab bhi kaam karte hain backup ke
roop mein. Koi nuksan nahi hai inko rakhne mein.

## Testing Checklist

1. `/Profile/Index` kholo — Name/Email/Mobile table mein dikhna chahiye,
   niche 2 buttons: "Edit Profile" aur "Change Password"
2. **Edit Profile** dabao — popup khulna chahiye (page change nahi hona
   chahiye), First Name/Last Name/Mobile pehle se bhare hue dikhein
3. Kuch change karo, **Save Changes** dabao — popup band ho, page reload
   ho, "Profile updated successfully" message dikhe, table mein naya data
   dikhe
4. **Change Password** dabao — popup khule, 3 fields khaali dikhein
5. Galat Current Password daal ke submit karo — popup **dubara khud khul
   jaye** (JS ne yeh handle kiya hai), error message dikhe
6. Sahi Current Password + matching New/Confirm daal ke submit karo →
   "Password changed successfully" ke saath Logout ho jaye (jaisa pehle
   hota tha)
7. Popup ke andar **Cancel** button dabao — popup band ho jaye, koi data
   save na ho

---

## Aage kya baaki hai

Ab Part 3 shuru karta hoon: **Product List filters** (proper styled boxes,
Rating filter hatana, duplicate search box hatana) aur **Wishlist cards**
(Product card jaisi chhoti/consistent). Batao jab is Part ko test kar liya ho.
